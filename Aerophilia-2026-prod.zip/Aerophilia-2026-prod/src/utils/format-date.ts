/**
 * Aerophilia 2026 — Date & Time Utility Functions
 */

/**
 * Formats start and end times into a clean time span string.
 * @example formatTimeSpan("09:00 AM", "10:30 AM") => "09:00 AM - 10:30 AM"
 */
export function formatTimeSpan(startTime: string, endTime: string): string {
  if (!startTime) return "";
  if (!endTime) return startTime;
  return `${startTime} - ${endTime}`;
}

/**
 * Generates human-readable Day Badge label.
 * @example formatDayLabel(1, "Nov 13, 2026") => "Day 1 • Nov 13"
 */
export function formatDayLabel(dayNumber: number, dateString: string): string {
  const shortDate = dateString.split(",")[0]; // "Nov 13"
  return `Day ${dayNumber} • ${shortDate}`;
}
