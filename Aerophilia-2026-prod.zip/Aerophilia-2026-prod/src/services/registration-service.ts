import type {
  WorkshopRegistrationData,
  RegistrationResult,
} from "@/types/Registration-Types";

/**
 * Aerophilia 2026 — Registration Service Layer
 *
 * Handles client-to-API communication for workshop registrations.
 */
export class RegistrationService {
  /**
   * Submits a workshop registration to the API route, which writes to Firestore.
   */
  static async submit(
    data: WorkshopRegistrationData,
  ): Promise<RegistrationResult> {
    try {
      const response = await fetch("/api/v1/workshops/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const json = await response.json();

      if (!response.ok) {
        return {
          success: false,
          errors:
            json.errors ??
            json.error ??
            "Registration failed. Please try again.",
          message: json.message,
        };
      }

      return { success: true, registrationId: json.registrationId };
    } catch (err) {
      console.error("[RegistrationService] submit error:", err);
      return {
        success: false,
        errors: "Network error. Please check your connection and try again.",
      };
    }
  }
}
