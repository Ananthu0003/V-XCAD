import { z } from "zod";

export const validateRegistrationService = z.object({
  name: z
    .string()
    .min(3, { message: "Name should be at least 3 characters" })
    .max(100, { message: "Name can be at most 100 characters" })
    .trim()
    .describe("Please enter your name"),
  email: z
    .string()
    .email({ message: "Invalid email address" })
    .trim()
    .toLowerCase()
    .describe("Please enter your email"),
  phone: z
    .string()
    .regex(/^\d{10}$/, { message: "Number should be exactly 10 digits" })
    .trim()
    .describe("Please enter your valid phone number"),
  college: z
    .string()
    .min(1, { message: "School / institution name is required" })
    .max(100, { message: "Please provide a valid institution name" })
    .trim()
    .describe("Please enter the school or institution name"),
  year: z
    .string()
    .min(1, { message: "Please select or enter your class / standard" })
    .max(100, { message: "Class / standard description is too long" })
    .trim()
    .describe("Please enter your class / standard"),
  department: z
    .string()
    .trim()
    .optional()
    .default("General")
    .describe("Please enter your stream or section"),
  usn: z
    .string()
    .nullable()
    .optional()
    .describe("Please enter student ID or roll number"),
  eventId: z
    .string()
    .min(1, { message: "Event ID is required" })
    .describe("Please provide the valid event ID"),
  eventName: z
    .string()
    .min(1, { message: "Event name is required" })
    .describe("Please enter the valid event name"),
});

export type RegistrationSchemaType = z.infer<
  typeof validateRegistrationService
>;
