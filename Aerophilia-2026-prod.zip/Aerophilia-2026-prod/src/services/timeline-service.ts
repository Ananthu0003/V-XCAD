import { TimelineEvent, TimelineEventCategory } from "@/types/timeline";
import {
  AEROPHILIA_TIMELINE_EVENTS,
  TIMELINE_CATEGORIES,
} from "@/data/timeline";

/**
 * Aerophilia 2026 — Timeline Service Layer
 *
 * Separates data operations from UI components following SOLID principles.
 */
export class TimelineService {
  /**
   * Retrieves all registered timeline events.
   */
  static getEvents(): TimelineEvent[] {
    return AEROPHILIA_TIMELINE_EVENTS;
  }

  /**
   * Retrieves category list metadata with dynamic event counts.
   */
  static getCategories(): Array<{
    id: TimelineEventCategory;
    label: string;
    count: number;
  }> {
    const events = AEROPHILIA_TIMELINE_EVENTS;
    return TIMELINE_CATEGORIES.map((cat) => {
      const count =
        cat.id === "all"
          ? events.length
          : events.filter((e) => e.category === cat.id).length;
      return { ...cat, count };
    });
  }

  /**
   * Filters events by category, day, status, and text search query.
   */
  static filterEvents(params: {
    events?: TimelineEvent[];
    category: TimelineEventCategory;
    day: 1 | 2 | 3 | "all";
    searchQuery: string;
  }): TimelineEvent[] {
    const list = params.events || AEROPHILIA_TIMELINE_EVENTS;
    const query = params.searchQuery.toLowerCase().trim();

    return list.filter((item) => {
      // Category match
      const categoryMatch =
        params.category === "all" || item.category === params.category;

      // Day match
      const dayMatch = params.day === "all" || item.dayNumber === params.day;

      // Text search match across title, description, and tags
      const searchMatch =
        !query ||
        item.title.toLowerCase().includes(query) ||
        item.subtitle.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.tags.some((t) => t.toLowerCase().includes(query)) ||
        item.location.toLowerCase().includes(query);

      return categoryMatch && dayMatch && searchMatch;
    });
  }
}
