"use client";

import { useState, useMemo } from "react";
import { TimelineEvent, TimelineEventCategory } from "@/types/timeline";
import { TimelineService } from "@/services/timeline-service";

/**
 * Aerophilia 2026 — Custom Hook for Timeline Filter State
 */
export function useTimelineFilter(initialEvents?: TimelineEvent[]) {
  const allEvents = useMemo(
    () => initialEvents || TimelineService.getEvents(),
    [initialEvents],
  );
  const categories = useMemo(() => TimelineService.getCategories(), []);

  const [activeCategory, setActiveCategory] =
    useState<TimelineEventCategory>("all");
  const [selectedDay, setSelectedDay] = useState<1 | 2 | 3 | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeEventId, setActiveEventId] = useState<string | null>(null);

  const filteredEvents = useMemo(() => {
    return TimelineService.filterEvents({
      events: allEvents,
      category: activeCategory,
      day: selectedDay,
      searchQuery,
    });
  }, [allEvents, activeCategory, selectedDay, searchQuery]);

  const toggleEventExpand = (id: string) => {
    setActiveEventId((prev) => (prev === id ? null : id));
  };

  return {
    categories,
    activeCategory,
    setActiveCategory,
    selectedDay,
    setSelectedDay,
    searchQuery,
    setSearchQuery,
    filteredEvents,
    activeEventId,
    setActiveEventId,
    toggleEventExpand,
    totalCount: allEvents.length,
    filteredCount: filteredEvents.length,
  };
}
