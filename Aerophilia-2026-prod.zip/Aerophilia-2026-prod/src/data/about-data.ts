import { type PhotoSlide } from "@/types/about";

export const PHOTO_SLIDES: PhotoSlide[] = [
  {
    id: "memory-1",
    title: "Where It All Began",
    description: "The energy, the crowd, and the passion that sparked it all.",
    src: "/assets/images/carousel/memory-1.webp",
    alt: "Aerophilia opening moment",
  },
  {
    id: "memory-2",
    title: "Wings in the Sky",
    description:
      "RC planes cutting through the air in breathtaking aerial displays.",
    src: "/assets/images/carousel/memory-2.webp",
    alt: "RC aeromodelling display",
  },
  {
    id: "memory-3",
    title: "The Makers & Builders",
    description: "Students bringing their drone ideas to life from scratch.",
    src: "/assets/images/carousel/memory-3.webp",
    alt: "Students building drones",
  },
  {
    id: "memory-4",
    title: "Speed. Precision. Thrill.",
    description: "FPV pilots navigating tight courses at full throttle.",
    src: "/assets/images/carousel/memory-4.webp",
    alt: "FPV drone racing",
  },
  {
    id: "memory-5",
    title: "A Community United by Flight",
    description:
      "Beyond competitions — the bonds formed and memories that last.",
    src: "/assets/images/carousel/memory-5.webp",
    alt: "Aerophilia community moments",
  },
  {
    id: "memory-6",
    title: "Rhythm & Energy",
    description:
      "The crowd, the moves, the moment — pure celebration of talent.",
    src: "/assets/images/carousel/memory-6.webp",
    alt: "Dance performance at Aerophilia",
    objectPosition: "center",
  },
  {
    id: "memory-7",
    title: "Moments Worth Remembering",
    description:
      "Every frame tells a story of passion, innovation, and flight.",
    src: "/assets/images/carousel/memory-7.webp",
    alt: "Aerophilia memories",
  },
];

/** Static stats shown on the About page */
export const ABOUT_STATS = [
  { value: 500, suffix: "+", label: "Participants" },
  { value: 10, suffix: "+", label: "Events" },
  { value: 3, suffix: "", label: "Days" },
  { value: 20, suffix: "+", label: "Colleges" },
] as const;
