import type { EventDetailData } from "@/types/Event-Types";

export const aeromodelingWorkshopEvent: EventDetailData = {
  id: "aeromodeling-workshop",
  name: "Aeromodeling Workshop",
  date: "14 Nov 2026 • 10:00 AM",
  time: "10:00 AM",
  venue: "Skill Lab ",
  description:
    "A beginner-friendly, interactive workshop introducing participants to the fundamentals of aeromodelling, RC aircraft, drones, aircraft structures, and flight electronics. Participants willunderstand how an RC aircraft is designed, how its components work together, how basic design calculations are performed, and how simulation can be used to understand and predict flight behaviour",
  detailedDescription:
    "A comprehensive, hands-on masterclass led by aerospace engineers and aeromodelling veterans. Participants will learn the core fundamentals of aerodynamics, airfoil selection, CAD airframe design, RC electronics integration, and receiver-transmitter pairing.\n\n• AEROMODELLING FUNDAMENTALS — Understanding the four basic principles of flight — Lift, Weight, Thrust, and Drag, along with basic aerodynamics, airfoils, stability, center of gravity (CG), and control surfaces.\n• AIRCRAFT & DRONE STRUCTURE — Introduction to the basic structure of an RC plane and drone, including fuselage, wings, tail, control surfaces, frame, propeller, and motor mounting. Components will be demonstrated using actual RC aircraft and drone structures.\n• DESIGN & BASIC CALCULATIONS — Learn how designers select basic aircraft parameters such as wing size, aspect ratio, weight, thrust, propeller, and center of gravity, with simple calculations and practical design examples.\n• ELECTRONICS & CONTROL — Interactive demonstration of RC transmitter/receiver, brushless motor, ESC, servo motors, Li-Po battery, flight controller, and other essential electronics, explaining how signals and power flow through the system.\n• SIMULATION & FLIGHT — Understand how an RC aircraft can be tested virtually before flying. Participants will explore aircraft simulation, control inputs, take-off, turning, landing, stability, and flight behaviour through an interactive simulation session.",
  tag: "HANDS-ON",
  rulebookUrl: "",
  category: "Workshops",
  image: "/assets/images/events/aeromodelling-workshop.webp",
  registrationUrl: "/events/aeromodeling-workshop/register",
  teamSize: "Individual",
  eligibility:
    "Open to all students, beginners, and aeromodelling/drone enthusiasts. No prior aeromodelling xperience is required",
  rules: [
    "This workshop is only open to students who are not part of Sahyadri Science Talent Hunt (SSTH)",
    "No team formation is required. The workshop is open for individual participation",
    "No prior aeromodelling, RC aircraft, or drone experience is required. Beginners are welcome",
    "The workshop is primarily demonstration, theory, and simulation based. Participants are not required to build or fabricate an aircraft",
    "Participants will be introduced to RC aircraft, drone structures, flight electronics, basic calculations, design concepts, and simulation through interactive demonstrations and discussions",
    "Participants must attend the scheduled workshop sessions to receive the official certificate of participation/completion",
  ],
  coordinators: [
    { name: "Sharanya PB", phone: "+91 73069 87720" },
    { name: "Dhanushree", phone: "+91 79752 91855" },
  ],
};
