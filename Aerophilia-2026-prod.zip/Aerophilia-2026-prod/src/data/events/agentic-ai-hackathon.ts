import type { EventDetailData } from "@/types/Event-Types";

export const agenticAiHackathonEvent: EventDetailData = {
  id: "ai-agent-showcase",
  name: "Agentic AI Hackathon",
  date: "14 Nov 2026 • 10:00 AM",
  time: "10:00 AM",
  rulebookUrl: "/assets/rulebooks/agentic-hackathon-rulebook.pdf",
  venue: "CSE Central Lab",
  description:
    "Design and build autonomous AI agents that plan, use tools, and complete multi-step objectives across real-world industry problem tracks.",
  detailedDescription:
    "The Agentic AI Hackathon challenges student teams to design and build autonomous AI agents that can plan, use tools, and act toward a real objective - not just answer prompts. Teams pick one problem track, architect an agent that reasons, calls tools, and completes multi-step tasks with minimal human hand-holding, and demo it live to a panel of judges.\n\n\n\nProblem Tracks (Select ONE):\n\n• Claims Triage Agent (Insurance) — Reads incident/claim submissions and returns severity, coverage, and fraud-risk assessments, routing to the right handler.\n• Client Intake Agent (Legal/Professional Services) — Runs structured intake conversations, screens against criteria, and books qualified consultations.\n• On-Call Incident Agent (Engineering) — Investigates alerts using logs/deploys/traces and proposes a diagnosis and fix for human approval.\n• Shopping Assist Agent (Retail) — Answers pre-purchase questions (fit, compatibility, stock) using product data rather than marketing copy.\n• Portfolio Health Monitor (Wealth/Investing) — Tracks holdings against news/filings and flags changes with supporting evidence without giving trade advice.\n\nJudging criteria, scoring rubrics, and detailed guidelines are provided in the official rulebook.",
  tag: "COMPETITION",
  category: "Technical",
  image: "/assets/images/events/agent-showcase.webp",
  registrationUrl:
    "https://unstop.com/p/agentic-ai-hackathon-aerophilia-sahyadri-college-of-engineering-management-scem-mangaluru-1746976?lb=QaN9yoJV&utm_medium=Share&utm_source=online_coding_challenge&utm_campaign=Sparss7776",
  prizePool: "₹15,000",
  teamSize: "2–4 Members",
  eligibility:
    "Open to all college students with a valid college ID. Teams must designate one captain for all official communication.",
  registrationFee: "₹400 per team",
  rules: [
    "Each team must consist of 2 to 4 members with a designated team captain. Open to all college students with a valid college ID.",
    "Teams must build their agent around ONE of the five official problem tracks using mock or sample data only (no real customer/financial data).",
    "The submission must demonstrate an autonomous planning → tool-use → action loop with at least one external tool or API call.",
    "Any framework is permitted (LangChain, LangGraph, CrewAI, AutoGen, Claude Agent SDK, OpenAI Agents SDK, or custom).",
    "All code must be written during the event window. Pre-built projects, plagiarism, or unauthorized code sharing will result in disqualification.",
    "Teams must submit a public GitHub repo with README and a 2-3 minute fallback demo video. Live demos are 5 minutes + 3 minutes judge Q&A.",
    "Registration fee is ₹400 per team, payable at the time of confirmation.",
    "Judging criteria: Agentic Architecture (30%), Technical Execution (25%), Problem Fit & Impact (20%), Innovation (15%), Presentation (10%).",
  ],
  coordinators: [
    { name: "Naren S J", phone: "+91 82968 33381" },
    { name: "Tharun Rai", phone: "+91 63608 29990" },
  ],
};
