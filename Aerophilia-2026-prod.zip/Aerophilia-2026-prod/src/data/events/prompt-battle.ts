import type { EventDetailData } from "@/types/Event-Types";

export const promptBattleEvent: EventDetailData = {
  id: "prompt-battle",
  name: "Prompt Battle",
  date: "13 Nov 2026 • 10:00 AM",
  time: "10:00 AM",
  venue: "CSE Central Lab",
  description:
    "Fast-paced, AI-powered development and prompt-engineering competition where teams design, build, and showcase functional solutions under real-world surprise hurdles.",
  detailedDescription:
    "Prompt Battle is a fast-paced, AI-powered development and prompt-engineering competition where participants are presented with a problem statement at the start of the event. Teams must use prompt engineering and AI-assisted tools to design, build, and showcase a functional solution within the given time.\n\nTo simulate real-world development, organizers may introduce surprise hurdles, such as changing requirements or additional feature requests, during the competition. Participants are free to use any AI models, coding assistants, frameworks, programming languages, or development platforms. The focus is on creativity, problem-solving, effective use of AI, and the quality of the final solution rather than the technology stack used.\n\n\n\n• Competition Format — Problem Statement → Build Phase → Surprise Hurdle → Final Submission → Live Showcase → Judge Q&A.\n• Agent & Prompt Log — Every participant/team must maintain a real-time Agent Log throughout the competition, recording AI models used, exact prompts, iterations, outputs, and refinements. Prompts must be recorded as they are used and not reconstructed after the competition.\n• Allowed Technologies — Participants are free to use ChatGPT/OpenAI, Google Gemini, Claude, Microsoft Copilot, Grok, Perplexity, Cursor, Antigravity, GitHub Copilot, and multimodal generative AI platforms using their own subscriptions and access.\n\nJudging criteria, evaluation rubrics, and penalty guidelines are detailed in the official rulebook.",
  tag: "COMPETITION",
  category: "Technical",
  image: "/assets/images/events/prompt-battle.webp",
  registrationUrl:
    "https://unstop.com/p/prompt-battle-aerophilia-sahyadri-college-of-engineering-management-scem-mangaluru-1746171?lb=QaN9yoJV&utm_medium=Share&utm_source=online_coding_challenge&utm_campaign=Sparss7776",
  rulebookUrl: "/assets/rulebooks/prompt-battle-rulebook.pdf",
  prizePool: "₹15,000",
  teamSize: "1-4 Members",
  eligibility:
    "Open to all students, developers, and AI enthusiasts (individual or teams of 2–4). Valid photo ID required upon request.",
  registrationFee: "₹400 per team",
  rules: [
    "Participation may be individual or in teams of 2 to 4 members. Each participant may be a member of only one team.",
    "Each team must bring their own laptops and accessories. Organizers will not provide laptops, accessories, AI subscriptions, API credits, or keys.",
    "Participants are free to use any publicly available AI tools, LLMs, and AI-assisted IDEs (ChatGPT, Gemini, Claude, Cursor, Antigravity, etc.) using their own accounts.",
    "Competition format follows: Problem Statement → Build Phase → Surprise Hurdle → Final Submission → Live Showcase → Judge Q&A.",
    "Every team must maintain a real-time Agent Log recording AI models, prompts, iterations, and outputs. Failure to provide it may result in penalties or disqualification.",
    "The final solution must be created during the event. Plagiarism, unauthorized external collaboration, or automated bots replacing participants is strictly prohibited.",
    "Registration fee is ₹400 per team, paid and confirmed prior to the event.",
    "Judging criteria and detailed rules are outlined in the official rulebook.",
  ],
  coordinators: [
    { name: "Tharun Rai", phone: "+91 6360829990" },
    { name: "Naren SJ", phone: "+91 82968 33381" },
  ],
};
