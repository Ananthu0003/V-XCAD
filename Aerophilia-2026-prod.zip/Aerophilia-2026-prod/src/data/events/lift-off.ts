import type { EventDetailData } from "@/types/Event-Types";

export const liftOffEvent: EventDetailData = {
  id: "drone-race",
  name: "Lift Off",
  date: "13 & 14 Nov 2026 • 10:00 AM",
  time: "10:00 AM",
  venue: "Back Ground",
  description:
    "Premier, fast-paced multirotor racing tournament testing pilot responsiveness, vehicle control, speed, and agility across obstacle courses, Figure-8 time attacks, and tactical challenges.",
  detailedDescription:
    "LIFT OFF is a premier, fast-paced multirotor racing tournament designed to test pilot responsiveness, vehicle control, speed, and hardware agility under highly competitive flight conditions. The event demands a synthesis of engineering capability and acute reflexes.\n\nPilots operate their custom-built multirotors through a rigorous obstacle circuit, an intense Figure-8 time attack, and a tactical special challenge that evaluates on-the-spot adaptability. With every round, the margins for error shrink, requiring pilots to maintain extreme focus and precision.\n\nEach team must clearly designate roles to ensure organized communication with event staff:\n\n• Team Captain — The sole point of contact for the team. Only the captain may approach officials for clarifications or to lodge formal protests.\n• Designated Pilot — The only individual permitted to hold and operate the radio transmitter during an official scoring heat.\n• Spotter / Pit Crew — Assists the pilot with visual tracking, battery management, and technical troubleshooting on the flight line.\n\nAircraft & hardware specifications, disqualification & administration policies, point scoring & penalty systems are detailed in the official rulebook.",
  tag: "COMPETITION",
  category: "Aeromodelling",
  image: "/assets/images/events/drone-race.webp",
  registrationUrl:
    "https://unstop.com/p/lift-off-aerophilia-sahyadri-college-of-engineering-management-scem-mangaluru-1746225",
  rulebookUrl: "/assets/rulebooks/lift-off-rulebook.pdf",
  prizePool: "₹50,000",
  teamSize: "1-3 Members",
  eligibility:
    "Open to all — hobbyists, school students, and university students. Valid photo ID (college ID, driver's license, or Aadhar card) required on event day.",
  registrationFee: "₹1,000 per team",
  rules: [
    "Each team must consist of 1 to 3 members with clearly designated roles: Captain, Pilot, and Spotter/Pit Crew.",
    "Teams must pay an entry fee of ₹1,000 per team. Registration is confirmed only once payment is verified.",
    "Only the designated pilot is permitted to operate the radio transmitter during official scoring heats.",
    "Only the team captain may approach officials for clarifications or formal protests.",
    "Every participant must present valid photo identification during reporting — access to the flight line and pit area is denied without it.",
    "Aircraft & hardware specifications, disqualification policies, and scoring systems are detailed in the official rulebook.",
  ],
  coordinators: [
    { name: "Ashwin", phone: "+91 7019760303" },
    { name: "Neil", phone: "+91 7760861967" },
  ],
};
