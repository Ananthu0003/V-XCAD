import type { EventDetailData } from "@/types/Event-Types";
import { skyDiveEvent } from "./sky-dive";
import { liftOffEvent } from "./lift-off";
import { agenticAiHackathonEvent } from "./agentic-ai-hackathon";
import { promptBattleEvent } from "./prompt-battle";
import { aeromodelingWorkshopEvent } from "./aeromodeling-workshop";
import { lineFollowerWorkshopEvent } from "./line-follower-workshop";

/* Re-export as EventData for backwards compatibility */
export type EventData = EventDetailData;

/* All events in the official Aerophilia 2026 showcase */
export const ALL_EVENTS: EventData[] = [
  skyDiveEvent,
  liftOffEvent,
  agenticAiHackathonEvent,
  promptBattleEvent,
  aeromodelingWorkshopEvent,
  lineFollowerWorkshopEvent,
];

/* Re-export SAMPLE_EVENTS for backwards compatibility with existing components */
export const SAMPLE_EVENTS = ALL_EVENTS;

/* Event Categories for Filtering */
export const CATEGORIES = ["All", "Aeromodelling", "Technical", "Workshops"];

export type EVENT_CATEGORIES =
  "All" | "Aeromodelling" | "Technical" | "Workshops";

/* Individual Event Exports */
export {
  skyDiveEvent,
  liftOffEvent,
  agenticAiHackathonEvent,
  promptBattleEvent,
  aeromodelingWorkshopEvent,
  lineFollowerWorkshopEvent,
};
