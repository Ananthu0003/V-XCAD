import type { EventDetailData } from "@/types/Event-Types";

export const skyDiveEvent: EventDetailData = {
  id: "aeromodelling",
  name: "Sky-Dive",
  date: "13 & 14 Nov 2026 • 10:00 AM",
  time: "10:00 AM",
  venue: "College Back-ground",
  description:
    "Design, build and fly an unmanned, electric, radio-controlled aircraft across two missions: a stunt round and a gate course with precision landing. Rewards a balanced design — good handling and affordable manufacturing.",
  detailedDescription:
    "Design, build and fly an unmanned, electric, radio-controlled aircraft across two competitive missions: a stunt round and a gate course with precision landing. The event rewards a balanced aerodynamic design — good handling and affordable manufacturing.\n\nTotal Score: 100 Points — Mission 1 (50 Points) + Mission 2 (50 Points).\n\nPrize Pool: ₹80,000 — Champion · 1st Runner-up · 2nd Runner-up.\n\nMandatory Technical Abstract:\nEvery team must submit a short technical abstract. It is mandatory and judged pass/fail — it carries no marks, but a team that does not submit one does not compete. The abstract must be sent to the official Challengers email (challengers@sahyadri.edu.in). Detailed abstract guidelines and formatting specifications are provided in the official rulebook.\n\nEach team must clearly designate roles to ensure organized communication with event staff:\n\n• Team Captain — Sole point of contact for the team and the only person who may raise an official protest.\n• Designated Pilot — The only individual permitted to fly for that team. May be changed only before technical inspection with the Chief Judge's approval (no guest, borrowed or external pilots permitted).\n• Spotter — Assists the pilot with visual line-of-sight tracking and flight line communication.\n\nAircraft requirements, safety protocols, technical inspection parameters, and mission scoring systems are detailed in the official rulebook.",
  tag: "COMPETITION",
  category: "Aeromodelling",
  image: "/assets/images/events/aeromodelling.webp",
  registrationUrl:
    "https://unstop.com/p/sky-dive-aerophilia-sahyadri-college-of-engineering-management-scem-mangaluru-1746226?lb=QaN9yoJV&utm_medium=Share&utm_source=competitions&utm_campaign=Sparss7776",
  rulebookUrl: "/assets/rulebooks/sky-dive-rulebook.pdf",
  prizePool: "₹80,000",
  teamSize: "Max 5 Members",
  eligibility:
    "Open to everyone — no age limit, no requirement to be a student (colleges, schools, makerspaces, flying clubs, or independent friends). Participants under 18 must submit a guardian consent form. Valid photo ID required for flight line access.",
  registrationFee: "₹1,800 per team",
  rules: [
    "Every team must submit a short technical abstract. It is mandatory and judged pass/fail — it carries no marks, but a team that does not submit one does not compete. The abstract should be sent to challengers@sahyadri.edu.in (abstract details are provided in the rulebook).",
    "Maximum 5 members per team. An individual may be in only one team.",
    "Each team may nominate a Captain (sole point of contact & protest representative), a Pilot, and a Spotter.",
    "The nominated Pilot is the only person who may fly for that team. Changes are allowed only before technical inspection with Chief Judge approval. Guest, borrowed, and external pilots are not permitted.",
    "Every participant must carry a valid photo ID and produce it at reporting. No ID, no flight line access.",
    "Participants under 18 must submit a signed guardian consent form.",
    "Registration fee is ₹1,800 per team, paid along with the abstract (non-refundable once participation is confirmed).",
    "Aircraft requirements, safety regulations, technical inspections, and mission rules are detailed in the official rulebook.",
  ],
  coordinators: [
    { name: "Sanath A Poojary", phone: "+91 7618744269" },
    { name: "Pratham N", phone: "+91 6362364611" },
  ],
};
