import type { EventDetailData } from "@/types/Event-Types";

export const lineFollowerWorkshopEvent: EventDetailData = {
  id: "line-follower-workshop",
  name: "Line Follower Workshop",
  date: "13 Nov 2026 • 02:30 PM",
  time: "02:30 PM",
  venue: "Ground Seminar Hall",
  description:
    "Hands-on Line Follower workshop covering component understanding, assembly, wiring, calibration and testing.",
  detailedDescription:
    "A hands-on robotics workshop focused on understanding, assembling, and testing an autonomous Line Follower. Participants will work with a provided Line Follower kit and learn how the major components work together to detect a line and control the movement of the robot.\n\nThe workshop will cover the basics of optical sensing, motor control, mechanical assembly, circuit connections, sensor calibration, and practical track testing. Participants will build the robot step by step and test the completed system on a line-following track. No prior programming or robotics experience is required.\n\n• WORKING PRINCIPLES & ARCHITECTURE — Understand how a Line Follower detects and responds to a track, including optical IR sensing, sensor arrays, motor drivers, motors, power supply, and the basic control flow between the components.\n• MECHANICAL ASSEMBLY & WIRING — Assemble the rover chassis, mount the motors and wheels, position the sensor assembly, and connect the required wiring and power connections using the provided kit.\n• SENSOR CALIBRATION & TRACK TESTING — Calibrate the optical sensors, verify reliable line detection, test the completed rover on a track, and identify common issues affecting movement and line tracking.",
  tag: "ROBOTICS",
  category: "Workshops",
  rulebookUrl: "",
  image: "/assets/images/events/line-follower.webp",
  registrationUrl: "/events/line-follower-workshop/register",
  teamSize: "Teams formed on the day",
  eligibility:
    "Open to all students, beginners, and robotics enthusiasts. No prior experience with robotics, electronics, or line-following robots is required.",
  rules: [
    "This workshop is only open to students who are not part of Sahyadri Science Talent Hunt (SSTH)",
    "The workshop is open for individual participation, no team formation is required",
    "No prior robotics, electronics, or programming experience is required.Beginners are welcome",
    "The workshop is hands - on and focuses on assembling, wiring, calibrating, and testing a Line Follower",
    "Participants must handle kits, tools, batteries, and electronic components carefully and follow the instructionsprovided by the workshop coordinators",
    "Available kits and tools will be shared or allocated based on the number of participants",
    "Participants must attend the scheduled workshop session to receive the official certificate of participation / completion, if certificates are provided",
  ],
  coordinators: [
    { name: "Mitra", phone: "+91 63608 74181" },
    { name: "Sanvil", phone: "+91 831 063 1652" },
  ],
};
