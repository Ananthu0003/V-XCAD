import { type AirShowData } from "@/types/showcasetv";

export const AIRSHOW_FEEDS: AirShowData[] = [
  {
    id: "cam-1",
    label: "AERIAL ACROBATICS",
    channelName: "CAM 01 • JET MANEUVER",
    image: "/assets/images/carousel/memory-2.webp",
    description:
      "Witness breathtaking aerial acrobatics and precision maneuvers performed by national aeromodelling champions.",
  },
  {
    id: "cam-2",
    label: "TURBINE JET FLYBY",
    channelName: "CAM 02 • HIGH SPEED PASS",
    image: "/assets/images/carousel/memory-1.webp",
    description:
      "High-thrust scale turbine jets exceeding 200 km/h across the main flight line.",
  },
  {
    id: "cam-3",
    label: "3D RC FORMATION",
    channelName: "CAM 03 • SYNCHRONIZED FLIGHT",
    image: "/assets/images/carousel/memory-4.webp",
    description:
      "Synchronized aerobatic RC aircraft and scale model demonstrations over campus airspace.",
  },
  {
    id: "cam-4",
    label: "SKY FORMATION GLIDE",
    channelName: "CAM 04 • GLIDER SQUADRON",
    image: "/assets/images/carousel/memory-16.webp",
    description:
      "High-altitude thermal gliders and precision fixed-wing aircraft soaring over Sahyadri.",
  },
  {
    id: "cam-5",
    label: "FPV CHASE VIEW",
    channelName: "CAM 05 • PURSUIT CAM",
    image: "/assets/images/carousel/memory-22.webp",
    description:
      "High-speed pursuit drones capturing aerobatic flight vectors in real-time.",
  },
];
