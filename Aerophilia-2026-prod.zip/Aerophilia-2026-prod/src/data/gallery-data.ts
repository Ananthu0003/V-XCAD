export type GalleryCategory =
  | "All"
  | "Aeromodelling"
  | "Drone Racing"
  | "Hackathon"
  | "Cultural"
  | "Team"
  | "Workshop";

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  title: string;
  category: Exclude<GalleryCategory, "All">;
  span?: "tall" | "wide" | "normal";
}

export const GALLERY_CATEGORIES: GalleryCategory[] = [
  "All",
  "Aeromodelling",
  "Drone Racing",
  "Hackathon",
  "Cultural",
  "Team",
  "Workshop",
];

export const GALLERY_IMAGES: GalleryImage[] = [
  {
    id: "g-1",
    src: "/assets/images/carousel/memory-1.webp",
    alt: "Aerophilia grand opening ceremony",
    title: "Opening Ceremony",
    category: "Cultural",
    span: "wide",
  },
  {
    id: "g-2",
    src: "/assets/images/carousel/memory-2.webp",
    alt: "RC plane aerial flight maneuver",
    title: "Wings in Motion",
    category: "Aeromodelling",
    span: "tall",
  },
  {
    id: "g-3",
    src: "/assets/images/carousel/memory-3.webp",
    alt: "Students building and assembling drones",
    title: "Hands-on Build Session",
    category: "Workshop",
  },
  {
    id: "g-4",
    src: "/assets/images/carousel/memory-4.webp",
    alt: "High-speed FPV drone racing through obstacle course",
    title: "FPV Sprint Championship",
    category: "Drone Racing",
    span: "wide",
  },
  {
    id: "g-5",
    src: "/assets/images/carousel/memory-5.webp",
    alt: "Aerophilia community and attendees gathering",
    title: "United by Flight",
    category: "Cultural",
  },
  {
    id: "g-6",
    src: "/assets/images/carousel/memory-6.webp",
    alt: "Electrifying cultural performance on main stage",
    title: "Stage Moments & Rhythm",
    category: "Cultural",
    span: "tall",
  },
  {
    id: "g-7",
    src: "/assets/images/carousel/memory-7.webp",
    alt: "Aeromodelling showcase and runway exhibition",
    title: "Runway Highlights",
    category: "Aeromodelling",
  },
  {
    id: "g-8",
    src: "/assets/images/carousel/memory-8.webp",
    alt: "Hackathon participants collaborating on code and hardware",
    title: "Code & Hardware Sprint",
    category: "Hackathon",
    span: "wide",
  },
  {
    id: "g-9",
    src: "/assets/images/carousel/memory-9.webp",
    alt: "Mentors demonstrating avionics and circuit assembly",
    title: "Avionics Workshop",
    category: "Workshop",
    span: "wide",
  },
  {
    id: "g-10",
    src: "/assets/images/carousel/memory-10.webp",
    alt: "Challengers organizing committee team photo",
    title: "Team Challengers",
    category: "Team",
  },
  {
    id: "g-11",
    src: "/assets/images/carousel/memory-11.webp",
    alt: "FPV quadcopter high-speed obstacle navigation",
    title: "Neon Race Circuit",
    category: "Drone Racing",
    span: "tall",
  },
  {
    id: "g-12",
    src: "/assets/images/carousel/memory-12.webp",
    alt: "Fixed-wing RC aircraft soaring across open sky",
    title: "Sky High Aerobatics",
    category: "Aeromodelling",
    span: "wide",
  },
  {
    id: "g-13",
    src: "/assets/images/carousel/memory-13.webp",
    alt: "Grand award ceremony and prize distribution",
    title: "Victory & Accolades",
    category: "Cultural",
    span: "wide",
  },
  {
    id: "g-14",
    src: "/assets/images/carousel/memory-14.webp",
    alt: "Innovative team pitching tech prototype to judges",
    title: "Innovation Pitch Deck",
    category: "Hackathon",
  },
  {
    id: "g-15",
    src: "/assets/images/carousel/memory-15.webp",
    alt: "Event coordinators and flight marshals in action",
    title: "Flight Ops Crew",
    category: "Team",
    span: "tall",
  },
  {
    id: "g-16",
    src: "/assets/images/carousel/memory-16.webp",
    alt: "Live soldering and drone telemetry calibration workshop",
    title: "Drone Diagnostics Lab",
    category: "Workshop",
    span: "wide",
  },
  // {
  //   id: "g-17",
  //   src: "/assets/images/carousel/memory-17.webp",
  //   alt: "FPV pilot wearing goggles during intense finals heat",
  //   title: "Goggle View Precision",
  //   category: "Drone Racing",
  // },
  {
    id: "g-18",
    src: "/assets/images/carousel/memory-18.webp",
    alt: "Interactive aerodynamic wind tunnel demo",
    title: "Aerodynamics Lab",
    category: "Workshop",
    span: "tall",
  },
  // {
  //   id: "g-19",
  //   src: "/assets/images/carousel/memory-19.webp",
  //   alt: "Custom balsa wood glider and scale aircraft display",
  //   title: "Custom Craft Showcase",
  //   category: "Aeromodelling",
  //   span: "wide",
  // },
  {
    id: "g-20",
    src: "/assets/images/carousel/memory-20.webp",
    alt: "Developers building AI flight systems late night",
    title: "Overnight Hack Sprint",
    category: "Hackathon",
  },
  {
    id: "g-21",
    src: "/assets/images/carousel/memory-21.webp",
    alt: "Volunteers and technical leads coordinating track setup",
    title: "Ground Control Synergy",
    category: "Team",
    span: "tall",
  },
  {
    id: "g-22",
    src: "/assets/images/carousel/memory-22.webp",
    alt: "Thrilling final lap drone showdown",
    title: "Championship Lap",
    category: "Drone Racing",
    span: "wide",
  },
  {
    id: "g-23",
    src: "/assets/images/carousel/memory-23.webp",
    alt: "Grand finale celebration and closing memories",
    title: "Grand Finale Memories",
    category: "Cultural",
    span: "wide",
  },
];
