import { LegalPageData } from "@/types/legal";

export const PRIVACY_DATA: LegalPageData = {
  title: "Privacy Policy",
  subtitle: "Transparency in How Information is Handled",
  category: "Privacy & Data Notice",
  description:
    "This Privacy Policy outlines how personal information may be handled when you visit the Team Challengers website or interact with Aerophilia 2026 event information and registration channels.",
  lastUpdated: "September 2026",
  version: "1.0",
  sections: [
    {
      id: "introduction",
      number: 1,
      title: "Introduction",
      badge: "Our Commitment",
      lead: "Team Challengers values your privacy and is dedicated to handling personal information with care, integrity, and transparency.",
      paragraphs: [
        "This Privacy Policy describes the practices of Team Challengers regarding information collected or received when users access our official website for Aerophilia 2026 or communicate with the organizing team.",
        "As a student-led technical club website, this platform serves primarily as an informational hub showcasing event timelines, competition rules, campus facilities, and club activities.",
        "Please read this policy to understand our approach toward user privacy and information management.",
      ],
    },
    {
      id: "information-we-may-receive",
      number: 2,
      title: "Information We May Receive",
      badge: "Information Scope",
      lead: "We only receive information that you voluntarily provide to us through direct contact or event inquiries.",
      paragraphs: [
        "The Team Challengers website is designed to be accessible without requiring visitors to create an account, log in, or provide personal credentials on this site. There is no independent user database or backend account management on this website.",
      ],
      bullets: [
        "Voluntary Inquiries: If you contact us via email, phone, or communication channels on our Contact page, we receive the details you choose to share (such as your name, email address, phone number, and inquiry content).",
        "Event Support Details: If you reach out regarding event queries, workshop registrations, or accommodation requests, we receive the operational details needed to resolve your query.",
        "No Sensitive Financial Data: This website does not request, collect, or store banking credentials, debit/credit card numbers, or sensitive financial data.",
      ],
    },
    {
      id: "third-party-registration",
      number: 3,
      title: "Information Collected Through Third-Party Platforms",
      badge: "External Registration Portal",
      lead: "Event registrations and ticketing are facilitated through external partner platforms, primarily Unstop.",
      paragraphs: [
        "Team Challengers relies on established third-party platforms such as Unstop to manage registration rosters, team submissions, fee transactions, and participant ticketing for Aerophilia 2026.",
        "When you register for an event through an external registration link, your interaction occurs directly on that third-party platform.",
      ],
      bullets: [
        "Direct Third-Party Collection: Personal information requested during event registration (such as college name, student ID, team details, and contact details) is collected directly by Unstop under its own systems.",
        "Independent Privacy Policies: Unstop operates under its own Privacy Policy and Terms of Service. We encourage all participants to review Unstop's privacy documentation before submitting personal information.",
        "Limited Organizer Roster: Team Challengers organizers receive participant rosters provided by the platform solely to administer check-ins, verify student eligibility, conduct rounds, and coordinate prize awards.",
        "No Control Over Platform Systems: Team Challengers does not control, supervise, or store the payment processing systems or server infrastructure operated by Unstop.",
      ],
      callout: {
        title: "Registration Data Notice",
        text: "For questions concerning data collected directly by Unstop or account management on their portal, please consult Unstop's official privacy documentation.",
        type: "info",
      },
    },
    {
      id: "how-information-may-be-used",
      number: 4,
      title: "How Information May Be Used",
      badge: "Purpose of Use",
      lead: "Any information received is used exclusively for legitimate club operations and event administration.",
      paragraphs: [
        "Team Challengers uses received information solely for genuine academic, logistical, and communicative purposes related to Aerophilia 2026.",
      ],
      bullets: [
        "Inquiry Resolution: Responding to your questions regarding event rules, workshop requirements, schedules, or festival logistics.",
        "Event Coordination: Verifying team rosters, managing check-ins at entry desks, allocating flight slots, and distributing competition schedules.",
        "Important Announcements: Communicating essential updates such as weather delays, arena changes, or urgent safety instructions to participants.",
        "Club Administration: Compiling internal participation metrics, certificates of participation, and prize distribution records.",
        "Website Security: Maintaining core website integrity, preventing misuse, and ensuring safe browsing for all users.",
      ],
    },
    {
      id: "cookies-and-similar-technologies",
      number: 5,
      title: "Cookies and Similar Technologies",
      badge: "Technical Mechanics",
      lead: "This website does not utilize commercial advertising trackers, persistent user profiling, or marketing cookies.",
      paragraphs: [
        "The Team Challengers website is built using modern static and client-rendered web technologies. We do not operate advertising tracking networks, third-party behavioral pixels (such as Meta Pixel), or invasive commercial profiling tools on this site.",
        "Basic technical mechanisms (such as standard browser cache or transient session states necessary for smooth page transitions and responsive user interface rendering) may operate within your browser environment as standard web behavior.",
        "Where external links or embedded services are accessed, those third parties may deploy technical cookies subject to their respective policies.",
      ],
    },
    {
      id: "third-party-services",
      number: 6,
      title: "Third-Party Services",
      badge: "External Integrations",
      lead: "We interface with selected external services for event ticketing, map navigation, and community outreach.",
      paragraphs: [
        "To provide a complete festival experience, our website references or links to the following external third parties:",
      ],
      bullets: [
        "Unstop: Used as the official external event registration and ticketing partner.",
        "Social Channels: Official profiles on Instagram, YouTube, LinkedIn, and Facebook for media galleries, event highlights, and community updates.",
        "Navigation & Maps: Location indicators directing visitors to Sahyadri Campus, Adyar, Mangaluru.",
      ],
    },
    {
      id: "data-security",
      number: 7,
      title: "Data Security",
      badge: "Protective Measures",
      lead: "We apply reasonable and appropriate administrative and technical measures to protect information.",
      paragraphs: [
        "Team Challengers takes reasonable precautions to safeguard the limited information received through official contact channels against unauthorized access, loss, misuse, or alteration.",
        "Inquiries sent to our official email are handled by authorized student leads and faculty coordinators using institutional email security standards.",
        "While we exercise diligent care, no electronic transmission or internet connection is 100% immune from unforeseen technical risks, and users communicate voluntarily.",
      ],
    },
    {
      id: "data-retention",
      number: 8,
      title: "Data Retention",
      badge: "Retention Standard",
      lead: "Personal information is retained only for as long as reasonably required to fulfill operational purposes.",
      paragraphs: [
        "Contact communications and event coordinator correspondence are retained only for the duration necessary to resolve inquiries, fulfill event logistics, issue certificates, and complete official reporting for Aerophilia 2026.",
        "Following the completion of festival administration and verification requirements, records are reviewed and archived or deleted in accordance with reasonable club administrative practices.",
      ],
    },
    {
      id: "user-rights-and-choices",
      number: 9,
      title: "User Rights and Choices",
      badge: "Your Choices",
      lead: "Users have choices regarding the communications and personal information they share with us.",
      paragraphs: [
        "Depending on applicable legal principles and collegiate standards, you may have rights regarding the personal information you have voluntarily provided to Team Challengers.",
      ],
      bullets: [
        "Information Inquiries: You may contact us at any time to inquire about any contact details you previously provided.",
        "Corrections: If you notice inaccuracies in your team's listed registration information or contact submissions, you may request corrections through event coordinators.",
        "Communication Preferences: You can request to cease non-essential email updates by notifying our team directly.",
      ],
    },
    {
      id: "childrens-privacy",
      number: 10,
      title: "Children's Privacy",
      badge: "Youth & Students",
      lead: "Our website is directed toward college and higher secondary students, educators, and technology enthusiasts.",
      paragraphs: [
        "Aerophilia competitions and workshops are intended for student participants from schools, pre-university colleges, and universities. We do not knowingly solicit or collect personal information directly from young children without school, institutional, or parental awareness.",
        "Where school students participate in events (such as paper plane contests or water rocket competitions), registrations are typically facilitated through institutional coordinators, school teams, or parental oversight.",
      ],
    },
    {
      id: "external-links",
      number: 11,
      title: "External Links",
      badge: "External Web Properties",
      lead: "We are not responsible for the privacy practices or content of linked third-party websites.",
      paragraphs: [
        "Our website contains links to other websites (including social media networks and the Unstop ticketing portal). When you navigate away from this site, this Privacy Policy ceases to govern your activity.",
        "We recommend reviewing the specific privacy statements of every external website you visit to ensure you are comfortable with their data processing standards.",
      ],
    },
    {
      id: "policy-updates",
      number: 12,
      title: "Policy Updates",
      badge: "Revisions",
      lead: "This Privacy Policy may be revised from time to time as our website or event operations evolve.",
      paragraphs: [
        "Team Challengers may periodically review and update this Privacy Policy to reflect technical changes, institutional guidance, or regulatory requirements.",
        "Any updates will be posted directly to this page with an updated 'Last Updated' notice. We encourage users to check this page periodically to stay informed.",
      ],
    },
    {
      id: "contact-us",
      number: 13,
      title: "Contact",
      badge: "Privacy Inquiries",
      lead: "If you have questions or feedback about our privacy practices, please contact Team Challengers.",
      paragraphs: [
        "For any privacy-related inquiries, clarifications, or requests concerning information handled in connection with Aerophilia 2026, please reach out to us:",
      ],
      bullets: [
        "Official Email: challengers@sahyadri.edu.in",
        "Mailing Address: Team Challengers, Sahyadri College of Engineering and Management, Sahyadri Campus, Adyar - 575007, Karnataka",
        "Official Website: challengers.sahyadri.edu.in",
        "Contact Directory: For direct telephone numbers of student heads and event coordinators, visit our Contact page (/contact).",
      ],
    },
  ],
};
