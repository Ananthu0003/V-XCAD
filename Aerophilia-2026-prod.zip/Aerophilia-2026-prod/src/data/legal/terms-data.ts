import { LegalPageData } from "@/types/legal";

export const TERMS_DATA: LegalPageData = {
  title: "Terms & Conditions",
  subtitle: "Rules & Guidelines for Participation and Use",
  category: "Official Legal Notice",
  description:
    "These Terms & Conditions govern your access to and use of the Team Challengers website and your participation in events, workshops, and competitions associated with Aerophilia 2026.",
  lastUpdated: "September 2026",
  version: "1.0",
  sections: [
    {
      id: "acceptance-of-terms",
      number: 1,
      title: "Acceptance of Terms",
      badge: "General Agreement",
      lead: "By accessing or using this website, you acknowledge and agree to comply with and be bound by these Terms & Conditions.",
      paragraphs: [
        "These Terms & Conditions ('Terms') apply to all visitors, attendees, participants, and other individuals who access or use the official Team Challengers Aerophilia website. If you do not agree with any part of these Terms, please refrain from accessing the website or participating in associated club events.",
      ],
      bullets: [
        "Your continued use of the website confirms your acceptance of these Terms in effect at the time of access.",
        "Specific events, workshops, and competitions hosted under Aerophilia may carry additional supplementary rules that apply in conjunction with these general terms.",
      ],
    },
    {
      id: "about-team-challengers",
      number: 2,
      title: "About Team Challengers",
      badge: "Student Organization",
      lead: "Team Challengers is a student-driven technical and aero-design club based at Sahyadri College of Engineering and Management.",
      paragraphs: [
        "Team Challengers is dedicated to inspiring innovation, hands-on engineering, and creative excellence among students across aeromodelling, autonomous drones, aerospace technology, robotics, and software development.",
        "The club organizes 'Aerophilia'—Sahyadri's premier national-level aerospace and technical fest—bringing together students, innovators, and enthusiasts to showcase their technical skills through competitive events, design challenges, and skill-building workshops.",
      ],
    },
    {
      id: "use-of-the-website",
      number: 3,
      title: "Use of the Website",
      badge: "Acceptable Conduct",
      lead: "Users are expected to interact with the website in a lawful, respectful, and responsible manner.",
      paragraphs: [
        "You agree to use this website solely for lawful informational and registration-related purposes in connection with Team Challengers and Aerophilia 2026.",
      ],
      bullets: [
        "Lawful Purpose: You must not use the website for any unlawful, deceptive, fraudulent, or harmful activity.",
        "System Integrity: You agree not to disrupt, impair, compromise, or overburden the website, servers, or connected network infrastructure.",
        "No Unauthorized Access: You may not attempt to gain unauthorized access to any restricted area, administrative interface, server, or underlying codebase.",
        "No Malicious Code: You must not introduce or transmit viruses, worms, trojans, or other harmful or disruptive software materials.",
        "Accurate Submissions: You must not intentionally provide false, misleading, or fraudulent contact or query information.",
      ],
    },
    {
      id: "events-competitions-and-activities",
      number: 4,
      title: "Events, Competitions and Activities",
      badge: "Fest Guidelines",
      lead: "Participation in Aerophilia events is subject to category-specific guidelines, eligibility rules, and organizer instructions.",
      paragraphs: [
        "Aerophilia hosts a diverse range of activities, including RC plane challenges, FPV drone racing, water rocket launches, technical hackathons, paper plane contests, CAD design competitions, robo soccer tournaments, and drone build workshops.",
        "Because competition formats vary substantially, distinct rules apply to individual events.",
      ],
      bullets: [
        "Separate Event Rulebooks: Each competition or workshop carries its own specific eligibility guidelines, scoring criteria, team composition limits, and safety requirements.",
        "Eligibility Verification: Participants may be required to verify their student status by presenting a valid college/institution identification card at the venue.",
        "Organizer Directions: Participants are required to strictly follow on-ground safety directives, flight-line regulations, and instructions issued by event coordinators.",
        "Schedule Adjustments: Organizers reserve the right to modify round timings, slot allocations, or track configurations when operational circumstances or safety considerations warrant.",
      ],
    },
    {
      id: "third-party-registration",
      number: 5,
      title: "Registration Through Third-Party Platforms",
      badge: "External Platform Notice",
      lead: "Event registrations and ticketing for Aerophilia 2026 are conducted through third-party platforms, notably Unstop.",
      paragraphs: [
        "To provide a streamlined, reliable registration and ticketing experience, Team Challengers utilizes external event management platforms such as Unstop for attendee registration.",
        "When clicking registration links on this website, you may be redirected to the external Unstop portal or another designated third-party ticketing interface.",
      ],
      bullets: [
        "Independent Platforms: Unstop is an independent third-party platform not operated, owned, or directly maintained by Team Challengers.",
        "Third-Party Terms: Any account creation, registration submission, or transaction completed on Unstop is governed exclusively by Unstop's own Terms of Service and Privacy Policy.",
        "User Review: Users are encouraged to carefully review Unstop's policies before submitting personal or payment information on their platform.",
        "Platform Policies: Team Challengers does not control, supervise, or assume legal responsibility for the internal processing or policies of third-party platforms.",
      ],
      callout: {
        title: "Important Note on Registrations",
        text: "Team Challengers does not directly process or store payment credentials or credit card data on this website. All registration fee payments occur on the secure infrastructure of external partners such as Unstop.",
        type: "info",
      },
    },
    {
      id: "user-information-and-submissions",
      number: 6,
      title: "User Information and Submissions",
      badge: "Data Integrity",
      lead: "Users are responsible for ensuring that all information submitted through website contact channels is true and accurate.",
      paragraphs: [
        "When contacting Team Challengers via the official email or contact channels on this website, you voluntarily provide contact information such as your name, email address, and inquiry message.",
        "You represent and warrant that any information you submit is accurate, current, and does not misrepresent your identity or college affiliation.",
        "Team Challengers does not collect or solicit sensitive personal financial information through the informational pages of this website.",
      ],
    },
    {
      id: "intellectual-property",
      number: 7,
      title: "Intellectual Property",
      badge: "Proprietary Assets",
      lead: "All original content, visual assets, graphics, and branding displayed on this website are protected by applicable intellectual property laws.",
      paragraphs: [
        "The Team Challengers logo, the Aerophilia name, brand marks, website designs, layouts, visual artwork, custom graphics, event descriptions, and written content are the intellectual property of Team Challengers, Sahyadri College of Engineering and Management, or their respective creators.",
        "Third-party trademarks, sponsor logos, partner marks, and external platform brands (such as Unstop) remain the property of their respective owners.",
      ],
      bullets: [
        "You may view, download, or print informational materials from the website exclusively for personal, non-commercial, and educational use.",
        "Reproduction, redistribution, modification, public display, or commercial exploitation of any site content without prior written permission is strictly prohibited.",
      ],
    },
    {
      id: "third-party-links-and-services",
      number: 8,
      title: "Third-Party Links and Services",
      badge: "External Links",
      lead: "This website may contain links to external third-party websites, platforms, and social media channels.",
      paragraphs: [
        "For the convenience of attendees and visitors, the website provides links to external services such as Unstop (for registrations) as well as official club social channels including Instagram, YouTube, LinkedIn, and Facebook.",
        "Team Challengers does not exercise operational control over the content, uptime, availability, privacy practices, or terms of third-party websites.",
        "The inclusion of any external link does not imply an endorsement or assumption of liability for the practices or services of that third party.",
      ],
    },
    {
      id: "website-availability",
      number: 9,
      title: "Website Availability",
      badge: "Technical Service",
      lead: "While we strive to keep the website accessible and functional, uninterrupted service cannot be guaranteed.",
      paragraphs: [
        "The website is provided on an 'as is' and 'as available' basis. Technical maintenance, server updates, routine improvements, or network disruptions may occasionally cause temporary interruptions or degraded performance.",
        "Team Challengers reserves the right to suspend, restrict, or modify access to the website or any of its sections at any time without prior notice where reasonably required for maintenance or security.",
      ],
    },
    {
      id: "event-changes",
      number: 10,
      title: "Event Changes and Updates",
      badge: "Operational Adjustments",
      lead: "Event schedules, arenas, and event rules may be updated where reasonably required by organizers.",
      paragraphs: [
        "To ensure the safe and optimal execution of Aerophilia 2026, Team Challengers organizers may periodically adjust festival logistics.",
        "Circumstances such as adverse weather conditions (critical for aerial and RC plane competitions), venue availability, logistics, or safety mandates may require schedule shifts, arena reallocations, or format adjustments.",
      ],
      bullets: [
        "Event schedules, timeline allocations, and prize pools may be updated when necessary.",
        "Registered participants will be informed of critical changes through official communication channels, announcements, or at the venue.",
      ],
    },
    {
      id: "power-to-team-challengers",
      number: 11,
      title: "Power to Team Challengers",
      badge: "Organizational Authority",
      lead: "To maintain festival integrity, safety, sportsmanship, and fair competition, Team Challengers holds necessary administrative authority.",
      paragraphs: [
        "The student organizing committee and faculty coordinators of Team Challengers are entrusted with ensuring that Aerophilia 2026 is conducted in a fair, orderly, transparent, and safe environment for all participants, guests, and campus community members.",
        "Accordingly, when reasonably necessary and subject to applicable institutional policies and laws, Team Challengers exercises the following reasonable powers:",
      ],
      bullets: [
        "Event & Rule Updates: Modify, clarify, or update event guidelines, competition formats, problem statements, track layouts, and scheduling to adapt to operational constraints.",
        "Safety & Airspace Management: Enforce strict safety zones, frequency checks, and radio control protocols; suspend flights or activities if safe operating parameters are compromised.",
        "Disciplinary & Fair Play Actions: Disqualify, restrict, or revoke participation of any individual or team found engaging in unfair practices, plagiarism, code of conduct violations, harassment, property damage, or fraud.",
        "Schedule Adjustments: Postpone, pause, reschedule, or cancel specific competitions or activities in the event of unforeseen technical failures, inclement weather, or institutional directives.",
        "Dispute Resolution: Evaluate and deliver final, binding decisions on on-ground competition disputes, judging inquiries, and scoring clarifications through designated event leads and faculty judges.",
        "Website Administration: Update website information, policies, timelines, and announcements to maintain accuracy.",
      ],
      callout: {
        title: "Standard of Conduct & Fair Play",
        text: "Team Challengers exercises these powers transparently, responsibly, and in good faith to preserve competitive fairness and participant safety. Decisions made under these provisions are intended to serve the best interests of the student engineering community.",
        type: "note",
      },
    },
    {
      id: "limitation-of-liability",
      number: 12,
      title: "Limitation of Liability",
      badge: "Legal Precaution",
      lead: "To the extent permitted by applicable law, reasonable liability limitations apply to website usage and event attendance.",
      paragraphs: [
        "To the maximum extent permitted by applicable law, Team Challengers, its student organizers, volunteer leads, and affiliated institutional representatives shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising out of or related to your use of the website or attendance at the festival.",
        "Participants entering hardware contests (such as RC aeromodelling, drone racing, or robotics) are responsible for their own equipment, components, batteries, and personal belongings. Organizers provide designated testing zones but assume no liability for equipment damage sustained during competitive flights, races, or crashes.",
      ],
    },
    {
      id: "changes-to-these-terms",
      number: 13,
      title: "Changes to These Terms",
      badge: "Periodic Updates",
      lead: "These Terms & Conditions may be updated periodically to reflect operational, legal, or logistical changes.",
      paragraphs: [
        "Team Challengers reserves the right to amend or update these Terms as necessary. When revisions occur, the updated version will be published on this page with an updated 'Last Updated' date.",
        "Your continued use of the website or participation in Aerophilia following the posting of revised Terms indicates your acknowledgment and acceptance of the revised Terms.",
      ],
    },
    {
      id: "applicable-law",
      number: 14,
      title: "Applicable Law",
      badge: "Governing Law",
      lead: "These Terms and all interactions arising from this website are governed by applicable laws.",
      paragraphs: [
        "These Terms & Conditions, together with any policies incorporated herein by reference, are subject to applicable laws and institutional regulations governing student educational organizations and collegiate events.",
        "Any disputes or claims arising out of or related to these Terms shall be resolved in accordance with applicable legal principles and collegiate administrative guidelines.",
      ],
    },
    {
      id: "contact-information",
      number: 15,
      title: "Contact",
      badge: "Official Inquiries",
      lead: "For inquiries, clarifications, or questions regarding these Terms & Conditions, you may reach out to Team Challengers.",
      paragraphs: [
        "If you have questions or concerns regarding these Terms or any aspect of Aerophilia 2026, please contact the organizing committee through the official channels listed below:",
      ],
      bullets: [
        "Official Email: challengers@sahyadri.edu.in",
        "Campus Address: Sahyadri Campus, Adyar - 575007, Karnataka",
        "Official Website: challengers.sahyadri.edu.in",
        "Dedicated Contact Page: Visit the Contact page (/contact) to view student leads and department contacts.",
      ],
    },
  ],
};
