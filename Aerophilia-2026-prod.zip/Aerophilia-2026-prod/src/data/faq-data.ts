import { FaqItemData } from "@/types/faq";

export const defaultFaqs: FaqItemData[] = [
  {
    id: "faq-1",
    question: "Who can participate in Aerophilia 2026?",
    answer:
      "Aerophilia is open to students from all engineering colleges, degree colleges, PU colleges, and high schools. Certain events may have specific age or educational requirements.",
    category: "General",
  },
  {
    id: "faq-2",
    question: "How do I register for events?",
    answer:
      "You can register for events through our official portal. Click on the 'Register' button on the specific event page or visit the main registration section.",
    category: "Registration",
  },
  {
    id: "faq-3",
    question: "Is accommodation provided for outstation participants?",
    answer:
      "Yes, accommodation is provided for outstation participants at a nominal fee. You need to opt for accommodation during the registration process.",
    category: "Accommodation",
  },
  {
    id: "faq-4",
    question: "What documents or IDs do I need to carry to the venue?",
    answer:
      "Participants must bring a valid college ID card along with their event registration pass/ticket for identity verification at the entry gates.",
    category: "General",
  },
  {
    id: "faq-5",
    question: "Is there a registration fee?",
    answer:
      "Registration fees vary depending on the individual event or workshop. Please refer to the specific event details on the portal for exact pricing.",
    category: "Registration",
  },
  {
    id: "faq-6",
    question: "Is WiFi/internet provided at the venue?",
    answer:
      "Campus Wi-Fi credentials will be provided to registered participants upon check-in at the registration desk for the duration of the event.",
    category: "General",
  },
  {
    id: "faq-7",
    question: "What is the last date to register?",
    answer:
      "The last date for online registration is 11 November 2026. We recommend registering early as slots are limited.",
    category: "Registration",
  },
];
