import type { Metadata } from "next";
import { LegalLayout } from "@/components/common/legal/legal-layout";
import { PRIVACY_DATA } from "@/data/legal/privacy-data";

export const metadata: Metadata = {
  title: "Privacy Policy | Aerophilia 2026",
  description:
    "Official Privacy Policy of Team Challengers for Aerophilia 2026, describing how personal information is handled, our transparent cookie approach, and third-party registration platform practices.",
  keywords: [
    "Privacy Policy",
    "Aerophilia 2026",
    "Team Challengers",
    "Sahyadri College",
    "Unstop Privacy",
    "Data Protection",
  ],
  openGraph: {
    title: "Privacy Policy | Aerophilia 2026",
    description:
      "Official Privacy Policy for Aerophilia 2026 and Team Challengers. Learn how personal information and third-party registrations are handled.",
    type: "website",
  },
};

export default function PrivacyPage() {
  return (
    <div className="relative flex flex-col flex-1 bg-transparent font-sans overflow-x-hidden -mt-24 pt-24">
      <LegalLayout data={PRIVACY_DATA} />
    </div>
  );
}
