import type { Metadata } from "next";
import { Poppins, Geist_Mono, Share_Tech_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { Footer, Navbar, CosmicBackground } from "@/components/common";
import LoaderComponent from "@/components/common/loaderContainer";

const poppins = Poppins({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const shareTechMono = Share_Tech_Mono({
  variable: "--font-mono-tech",
  weight: "400",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Aerophilia 2026",
    template: "%s | Aerophilia 2026",
  },
  description:
    "Aerophilia 2026 is the annual national-level aeromodelling and technical fest organized by Team Challengers at Sahyadri College of Engineering and Management (SCEM), Mangaluru",
  icons: {
    icon: "/assets/logos/alogo.svg",
  },
  keywords: [
    "Aerophilia 2026",
    "Team Challengers",
    "Sahyadri College of Engineering & Management",
    "Aerospace Fest",
    "Tech Fest",
    "Agentic AI",
    "Workshops",
    "Student-Driven Community",
    "Drone Racing",
    "Robotics Workshops",
    "National Technology Festival",
  ],
  creator: "Team Challengers Sahyadri",
  publisher: "Team Challengers Sahyadri",
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${poppins.variable} ${geistMono.variable} ${shareTechMono.variable} min-h-screen antialiased dark overflow-x-hidden`}
    >
      <body className="min-h-full bg-[#030712] text-white relative selection:bg-cyan-500/30 selection:text-cyan-200 overflow-x-clip">
        {/* Global Futuristic Cosmic Space Background */}
        <CosmicBackground />
        <LoaderComponent>
          <Toaster
            richColors
            duration={3000}
            theme="dark"
            position="top-right"
            dir="auto"
          />

          <div className="flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-1 pt-24 relative z-10">{children}</main>
            <Footer />
          </div>
        </LoaderComponent>
      </body>
    </html>
  );
}
