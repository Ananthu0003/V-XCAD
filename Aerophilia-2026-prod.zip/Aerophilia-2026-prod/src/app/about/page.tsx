import type { Metadata } from "next";
import Image from "next/image";
import { InfoCard, AboutTitle, ImageCarousel } from "@/components/common/about";
import { PageEntry, PageEntryItem } from "@/components/common";
import { NumberTicker } from "@/components/ui/Number-Ticker";
import { ABOUT_STATS } from "@/data/about-data";

/* ─── SEO Metadata ────────────────────────────────────────────────── */
export const metadata: Metadata = {
  title: "About | Aerophilia 2026",
  description:
    "Learn about Aerophilia 2026 — Sahyadri's premier aerospace and drone technology festival. Discover what we do, our events, and the team behind the wings.",
};

/* ─── Page Component ──────────────────────────────────────────────── */
export default function AboutPage() {
  return (
    <div className="relative flex flex-col flex-1 bg-transparent font-sans overflow-x-hidden -mt-24 pt-24">
      {/* ══════════════════════════════════════════════════════════════
          UNIFIED ABOUT SECTION — one continuous scroll, no separators
          ══════════════════════════════════════════════════════════════ */}
      <PageEntry className="w-full flex flex-col items-center">
        <section className="relative z-10 w-full flex flex-col items-center px-4 pt-8 pb-20">
          {/* ── Central radial glow — large, soft, persistent ────────── */}
          <div
            aria-hidden="true"
            className="absolute -top-[200px] left-1/2 -translate-x-1/2 w-[1200px] h-[800px] pointer-events-none"
          />

          {/* ── Title ────────────────────────────────────────────────── */}
          <PageEntryItem className="relative z-10 flex flex-col items-center w-full">
            <AboutTitle />
          </PageEntryItem>

          {/* ── Stats row — woven naturally below title ───────────────── */}
          <PageEntryItem className="relative z-10 mt-10 w-full max-w-2xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-y-8 gap-x-6">
            {ABOUT_STATS.map((stat) => (
              <div
                key={stat.label}
                className="relative flex flex-col items-center text-center gap-1"
              >
                <span className="text-3xl sm:text-[2.6rem] text-[#f0c040] tabular-nums leading-none">
                  <NumberTicker
                    value={stat.value}
                    className="text-3xl sm:text-[2.6rem] text-[#f0c040] tabular-nums leading-none"
                  />
                  {stat.suffix}
                </span>
                <span className="text-[10px] sm:text-[11px] text-zinc-500 uppercase tracking-[0.2em] font-semibold mt-1.5">
                  {stat.label}
                </span>
              </div>
            ))}
          </PageEntryItem>

          {/* ── Info Cards — same visual plane, generous top breathing room ── */}
          <div
            id="info-cards"
            className="relative z-10 mt-20 w-full max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10"
          >
            {/* Card 1 — Wings of Innovation */}
            <PageEntryItem className="w-full">
              <InfoCard
                title="Wings of Innovation"
                description="Aerophilia is the ultimate aerospace and drone technology festival that brings together innovators, enthusiasts, and professionals from across the nation. Experience the future of aviation technology through hands-on workshops, competitive events, and cutting-edge demonstrations."
              />
            </PageEntryItem>

            {/* Card 2 — Beyond the Horizon */}
            <PageEntryItem className="w-full">
              <InfoCard
                title="Beyond the Horizon"
                description="Experience thrilling drone competitions, aerospace engineering challenges, technical contests, interactive workshops, and engaging non-technical events. Showcase your skills, explore emerging technologies, and connect with a community passionate about flight and innovation."
              />
            </PageEntryItem>

            {/* Card 3 — Behind the Wings */}
            <PageEntryItem className="w-full">
              <InfoCard title="Behind the Wings">
                <div className="flex flex-col items-center text-center gap-4">
                  <p className="text-gray-400 text-xs sm:text-sm tracking-widest uppercase font-medium">
                    Organised By
                  </p>
                  <div className="relative w-48 h-14 my-1">
                    <Image
                      src="/assets/logos/challengers-logo.webp"
                      alt="Challengers — Invent, Innovate, Improvise"
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      className="object-contain"
                    />
                  </div>
                  <p className="text-gray-400 text-xs tracking-wide leading-relaxed">
                    Sahyadri College of Engineering
                    <br />
                    and Management
                  </p>
                  <p className="text-gray-300 text-sm leading-relaxed max-w-xs">
                    A student-driven community inspiring passion and creativity
                    in aeromodelling, coding, aerospace, drone technology, and
                    innovation.
                  </p>
                </div>
              </InfoCard>
            </PageEntryItem>
          </div>
        </section>

        {/* ── Image Carousel Section ─────────────────────────────────── */}
        <PageEntryItem className="relative z-10 w-full pb-20">
          <ImageCarousel />
        </PageEntryItem>
      </PageEntry>
    </div>
  );
}
