"use client";

import React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ContactHeader } from "@/components/common/contact/contact-header";
import { ContactCards } from "@/components/common/contact/contact-cards";
import { FaqAccordion } from "@/components/common/faq-accordion";
import { LocationSection } from "@/components/common/contact/location-section";
import { defaultFaqs } from "@/data/faq-data";

export default function ContactPage() {
  const { scrollY } = useScroll();

  // Top glow moves down at a faster pace
  const yGlow1 = useTransform(scrollY, [0, 1000], [0, 400]);

  // Bottom glow moves slightly up
  const yGlow2 = useTransform(scrollY, [0, 1000], [0, -150]);

  return (
    <div className="relative min-h-screen bg-transparent pb-24 overflow-hidden -mt-24 pt-24">
      {/* Ambient glow spots */}
      <motion.div
        className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-cyan-500/[0.04] rounded-full blur-[150px] pointer-events-none"
        style={{ y: yGlow1 }}
      />
      <motion.div
        className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-indigo-500/[0.05] rounded-full blur-[150px] pointer-events-none"
        style={{ y: yGlow2 }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6">
        <ContactHeader />

        <div className="mt-4">
          <ContactCards />
        </div>

        {/* Divider line */}
        <div className="my-16 h-px bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />

        <FaqAccordion items={defaultFaqs} title="FAQs" />

        {/* Divider line */}
        <div className="my-16 h-px bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />

        <LocationSection />
      </div>
    </div>
  );
}
