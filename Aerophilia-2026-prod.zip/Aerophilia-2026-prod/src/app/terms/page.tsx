import type { Metadata } from "next";
import { LegalLayout } from "@/components/common/legal/legal-layout";
import { TERMS_DATA } from "@/data/legal/terms-data";

export const metadata: Metadata = {
  title: "Terms & Conditions | Aerophilia 2026",
  description:
    "Official Terms & Conditions governing the use of the Team Challengers Aerophilia 2026 website, registrations, and participation in competitions, workshops, and events.",
  keywords: [
    "Terms and Conditions",
    "Aerophilia 2026",
    "Team Challengers",
    "Sahyadri College",
    "Event Rules",
    "Unstop Registration",
  ],
  openGraph: {
    title: "Terms & Conditions | Aerophilia 2026",
    description:
      "Official Terms & Conditions governing participation, registrations, and website use for Aerophilia 2026 by Team Challengers.",
    type: "website",
  },
};

export default function TermsPage() {
  return (
    <div className="relative flex flex-col flex-1 bg-transparent font-sans overflow-x-hidden -mt-24 pt-24">
      <LegalLayout data={TERMS_DATA} />
    </div>
  );
}
