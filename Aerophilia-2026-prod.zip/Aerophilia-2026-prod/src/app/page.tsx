import Image from "next/image";
import Link from "next/link";
import { ArrowRight, HelpCircle } from "lucide-react";
import { SlidingGallery, SmoothScroll } from "@/components/common/home";
import { Timeline } from "@/components/common/timeline/timeline";
import { InfoCard } from "@/components/common/about/Info-Card";
import { NumberTicker } from "@/components/ui/Number-Ticker";
import { ABOUT_STATS } from "@/data/about-data";
import { FaqAccordion } from "@/components/common/faq-accordion";
import { defaultFaqs } from "@/data/faq-data";
import EventTvShowcase from "@/components/common/home/EventTvShowcase";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 bg-transparent font-sans">
      <SmoothScroll />

      {/* ── 1. HERO SECTION ────────────────────────────────────────────── */}
      <section className="relative min-h-[85vh] sm:min-h-[90vh] flex flex-col items-center justify-center overflow-hidden bg-transparent w-full -mt-24 pt-32 sm:pt-36 pb-16">
        <div className="z-10 flex flex-col items-center text-center px-4 max-w-5xl mx-auto w-full">
          <div className="flex items-center justify-center gap-6 sm:gap-10 mb-6">
            <div className="relative h-8 w-24 sm:h-12 sm:w-32">
              <Image
                src="/assets/logos/sahyadri-logo.webp"
                alt="Sahyadri Logo"
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-contain"
              />
            </div>
            <div className="relative h-8 w-24 sm:h-12 sm:w-32">
              <Image
                src="/assets/logos/synergia-logo.webp"
                alt="Synergia Logo"
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-contain"
              />
            </div>
            <div className="relative h-8 w-24 sm:h-12 sm:w-32">
              <Image
                src="/assets/logos/challengers-logo.webp"
                alt="Challengers Logo"
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-contain"
              />
            </div>
          </div>

          {/* Main Big Logo */}
          <div className="relative h-24 w-[280px] xs:w-[320px] sm:h-32 sm:w-[480px] md:h-36 md:w-[540px] mb-4">
            <Image
              src="/assets/logos/aerophilia-logo.svg"
              alt="Aerophilia Logo"
              fill
              className="object-contain drop-shadow-[0_0_35px_rgba(56,189,248,0.3)]"
              priority
            />
          </div>

          <p className="text-zinc-400 mt-2 text-sm sm:text-base md:text-lg tracking-wide font-medium max-w-2xl">
            Sahyadri&apos;s National Aerospace &amp; Technology Fest
            <span className="mx-2 text-cyan-400/70 hidden sm:inline">•</span>
            <span className="block sm:inline mt-1 sm:mt-0 text-cyan-300 font-semibold">
              November 2026
            </span>
          </p>

          <p className="text-zinc-400 text-sm sm:text-base md:text-lg max-w-xl mt-4 leading-relaxed font-normal tracking-wide sm:text-pretty">
            Where{" "}
            <span className="text-zinc-100 font-medium">
              passion meets innovation
            </span>
            . Join thousands of creators, aeromodellers, FPV pilots, and tech
            enthusiasts in the ultimate celebration of flight.
          </p>

          <div className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-3.5 sm:gap-5">
            <Link
              href="/events"
              className="px-6 sm:px-8 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 shadow-[0_0_25px_rgba(6,182,212,0.4)] hover:shadow-[0_0_35px_rgba(6,182,212,0.6)] flex items-center gap-2 active:scale-95"
            >
              <span>Explore Events</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              href="/gallery"
              className="px-6 sm:px-8 py-3 rounded-xl bg-[#0b1324]/80 hover:bg-[#101b33] border border-cyan-500/30 hover:border-cyan-400/60 text-cyan-300 hover:text-white font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 backdrop-blur-md flex items-center gap-2 active:scale-95"
            >
              <span>View Gallery</span>
            </Link>
          </div>
        </div>
      </section>

      {/* ── 2. ABOUT AEROPHILIA SECTION ────────────────────────────────── */}
      <section
        id="about"
        className="relative py-16 sm:py-24 px-4 max-w-6xl mx-auto w-full z-10"
      >
        {/* Header Capsule */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex flex-col items-center px-10 py-2.5 sm:px-14 sm:py-3.5 rounded-full border border-cyan-400/70 bg-transparent shadow-[0_0_20px_rgba(34,211,238,0.12)] mb-4 transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,211,238,0.25)]">
            <p className="text-[#f0c040] font-sans italic font-medium tracking-widest text-[11px] sm:text-xs uppercase">
              About
            </p>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-cyan-300 tracking-widest font-sans uppercase">
              AEROPHILIA 2026
            </h2>
          </div>
          <p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto font-medium leading-relaxed">
            India&apos;s premier student-led aerospace festival empowering
            innovators through flight technology, competitive robotics, and
            groundbreaking research.
          </p>
        </div>

        {/* Stats Row */}
        <div className="w-full max-w-3xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-16 sm:mb-20">
          {ABOUT_STATS.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center text-center p-3 rounded-2xl bg-[#081224]/50 border border-cyan-500/15 backdrop-blur-sm"
            >
              <span className="text-3xl sm:text-4xl font-black text-[#f0c040] tabular-nums tracking-tight">
                <NumberTicker
                  value={stat.value}
                  className="text-3xl sm:text-4xl font-black text-[#f0c040] tabular-nums"
                />
                {stat.suffix}
              </span>
              <span className="text-[10px] sm:text-xs text-zinc-400 uppercase tracking-[0.18em] font-semibold mt-1.5">
                {stat.label}
              </span>
            </div>
          ))}
        </div>

        <EventTvShowcase />

        {/* 3 Info Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10">
          {/* Card 1 */}
          <InfoCard
            title="Wings of Innovation"
            description="Aerophilia is the ultimate aerospace and drone technology festival that brings together innovators, enthusiasts, and professionals from across the nation. Experience the future of aviation technology through hands-on workshops, competitive events, and cutting-edge demonstrations."
          />

          {/* Card 2 */}
          <InfoCard
            title="Beyond the Horizon"
            description="Experience thrilling drone competitions, aerospace engineering challenges, technical contests, interactive workshops, and engaging non-technical events. Showcase your skills, explore emerging technologies, and connect with a community passionate about flight and innovation."
          />

          {/* Card 3 */}
          <InfoCard title="Behind the Wings">
            <div className="flex flex-col items-center text-center gap-3">
              <p className="text-gray-400 text-xs sm:text-sm tracking-widest uppercase font-medium">
                Organised By
              </p>
              <div className="relative w-44 h-12 my-1">
                <Image
                  src="/assets/logos/challengers-logo.webp"
                  alt="Team Challengers Logo"
                  fill
                  sizes="(max-width: 768px) 100vw, 300px"
                  className="object-contain"
                />
              </div>
              <p className="text-gray-400 text-xs tracking-wide leading-relaxed">
                Sahyadri College of Engineering &amp; Management
              </p>
              <p className="text-gray-300 text-xs sm:text-sm leading-relaxed max-w-xs">
                A student-driven community inspiring passion and creativity in
                aeromodelling, coding, aerospace, drone technology, and
                innovation.
              </p>
            </div>
          </InfoCard>
        </div>
      </section>

      {/* ── 3. SLIDING GALLERY MARQUEE ─────────────────────────────────── */}
      <SlidingGallery />

      {/* ── 4. FAQS SECTION ────────────────────────────────────────────── */}
      <section
        id="faqs"
        className="relative py-16 sm:py-24 px-4 max-w-5xl mx-auto w-full z-10"
      >
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-400/30 bg-cyan-950/40 text-cyan-400 text-xs font-mono tracking-widest uppercase mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Got Questions?</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-400 to-indigo-300 tracking-wider">
            Frequently Asked Questions
          </h2>
          <p className="text-zinc-400 text-xs sm:text-sm md:text-base mt-2 font-medium">
            Everything you need to know about participating, registrations,
            accommodation, and event guidelines.
          </p>
        </div>

        {/* FAQs Accordion Component */}
        <FaqAccordion items={defaultFaqs} title="" />
      </section>

      {/* ── 5. EVENT TIMELINE SECTION ──────────────────────────────────── */}
      <Timeline />
    </div>
  );
}
