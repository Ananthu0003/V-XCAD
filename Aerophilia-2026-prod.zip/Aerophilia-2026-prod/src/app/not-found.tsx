"use client";

import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { motion, type Variants } from "framer-motion";

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.1,
    },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
};

export default function NotFound() {
  return (
    <div className="relative flex flex-1 flex-col items-center justify-center min-h-[70vh] px-4 py-12 overflow-hidden text-white font-sans select-none">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[350px] w-[350px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/10 blur-[100px]"
      />

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="flex flex-col items-center text-center max-w-md w-full"
      >
        <motion.h1
          variants={itemVariants}
          className="text-7xl sm:text-8xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-cyan-500/40 drop-shadow-sm mb-3"
        >
          Not Found
        </motion.h1>

        <motion.p
          variants={itemVariants}
          className="text-sm text-slate-400 mb-8 max-w-sm leading-relaxed"
        >
          Sorry, we couldn’t find the page you’re looking for. It might have
          been moved or deleted.
        </motion.p>

        <motion.div variants={itemVariants}>
          <Link
            href="/"
            className="group relative inline-flex items-center gap-2.5 px-6 py-2.5 rounded-full bg-[#090e1a]/90 border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider shadow-lg shadow-cyan-950/20 backdrop-blur-md transition-all duration-300 hover:border-cyan-400 hover:text-white hover:shadow-cyan-500/20 active:scale-95"
          >
            <ChevronLeft className="w-4 h-4 transition-transform duration-200 group-hover:-translate-x-1" />
            <span>Back to Home</span>
          </Link>
        </motion.div>
      </motion.div>
    </div>
  );
}
