import type { Metadata } from "next";
import { GalleryGrid, GalleryHeader } from "@/components/common/gallery";

export const metadata: Metadata = {
  title: "Gallery | Aerophilia 2026",
  description:
    "Relive the best moments from Aerophilia - aeromodelling, drone racing, hackathons, and more.",
};

export default function GalleryPage() {
  return (
    <div className="relative flex flex-col flex-1 bg-transparent font-sans -mt-24 pt-24 overflow-x-hidden">
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 pb-24 pt-12">
        <GalleryHeader />
        <GalleryGrid />
      </div>
    </div>
  );
}
