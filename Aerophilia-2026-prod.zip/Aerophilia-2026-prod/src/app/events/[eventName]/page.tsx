"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import { motion, type Variants } from "framer-motion";
import {
  ChevronLeft,
  Calendar,
  Clock,
  MapPin,
  Trophy,
  Users,
  Download,
  Phone,
  ShieldCheck,
  IndianRupee,
  ArrowRight,
} from "lucide-react";
import { SAMPLE_EVENTS } from "@/data/events";

/* ── Animation Variants ── */
const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
};

const itemFadeUp: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" },
  },
};

export default function EventPage() {
  const params = useParams();
  const rawEventName = params?.eventName;
  const eventName = Array.isArray(rawEventName)
    ? rawEventName[0]
    : rawEventName || "";

  const currentIndex = SAMPLE_EVENTS.findIndex(
    (e) => e.id.toLowerCase() === eventName.toLowerCase(),
  );
  const event =
    currentIndex !== -1 ? SAMPLE_EVENTS[currentIndex] : SAMPLE_EVENTS[0];

  const {
    name,
    date,
    time,
    venue,
    description,
    detailedDescription,
    image = "/assets/images/carousel/memory-1.webp",
    registrationUrl,
    rulebookUrl,
    prizePool,
    teamSize,
    eligibility,
    registrationFee,
    rules,
    coordinators,
  } = event;

  const displayDate = date.includes("•") ? date.split("•")[0].trim() : date;
  const displayTime =
    time || (date.includes("•") ? date.split("•")[1].trim() : "10:00 AM");
  const registerUrl =
    registrationUrl && registrationUrl !== "#" && registrationUrl !== "none"
      ? registrationUrl
      : undefined;
  const isExternalRegister = registerUrl
    ? registerUrl.startsWith("http")
    : false;

  /* Helper to format detailed paragraphs cleanly */
  const renderFormattedDescription = (text: string) => {
    const paragraphs = text.split("\n\n");
    return paragraphs.map((para, idx) => {
      const isBulletBlock = para.includes("• ");
      if (isBulletBlock) {
        const lines = para.split("\n");
        return (
          <div key={`bullet-block-${idx}`} className="my-5 space-y-3">
            {lines.map((line, lIdx) => {
              if (line.trim().startsWith("•")) {
                const parts = line.replace("•", "").trim().split("—");
                const title = parts[0]?.trim();
                const desc = parts.slice(1).join("—")?.trim();
                return (
                  <div
                    key={`role-${lIdx}`}
                    className="p-4 rounded-xl bg-[#090e1a]/80 border border-cyan-500/30 hover:border-cyan-400 transition-all"
                  >
                    <div className="text-sm leading-relaxed">
                      {desc ? (
                        <>
                          <span className="font-bold text-cyan-300 uppercase tracking-wide">
                            {title}
                          </span>
                          <span className="text-zinc-300"> — {desc}</span>
                        </>
                      ) : (
                        <span className="text-zinc-300 font-medium">
                          {line.replace("•", "").trim()}
                        </span>
                      )}
                    </div>
                  </div>
                );
              }
              return (
                <p
                  key={`line-${lIdx}`}
                  className="text-zinc-300 text-sm leading-relaxed"
                >
                  {line}
                </p>
              );
            })}
          </div>
        );
      }
      return (
        <p
          key={`para-${idx}`}
          className="text-zinc-300 text-sm sm:text-base leading-relaxed mb-4"
        >
          {para}
        </p>
      );
    });
  };

  return (
    <div className="min-h-[calc(100vh-6rem)] bg-transparent text-white font-sans selection:bg-cyan-500/30 selection:text-cyan-200 pb-20 overflow-x-hidden">
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-4"
      >
        {/* ════════════════════════════════════════════════════════════════
            TOP NAVIGATION & ACTION BAR
            ════════════════════════════════════════════════════════════════ */}
        <motion.div
          variants={itemFadeUp}
          className="flex items-center justify-between gap-4 py-3 mb-8 border-b border-cyan-500/20"
        >
          {/* Back button */}
          <Link
            href="/events"
            className="group inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#090e1a]/90 border border-cyan-500/40 text-cyan-400 text-xs font-bold uppercase tracking-wider hover:border-cyan-300 hover:text-white transition-all active:scale-95 backdrop-blur-md"
          >
            <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            <span>Back to Events</span>
          </Link>
        </motion.div>

        {/* ════════════════════════════════════════════════════════════════
            EVENT TITLE HEADING (Top of page)
            ════════════════════════════════════════════════════════════════ */}
        <motion.div variants={itemFadeUp} className="mb-6">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-wider text-white leading-tight">
            {name}
          </h1>
        </motion.div>

        {/* ════════════════════════════════════════════════════════════════
            MAIN 2-COLUMN LAYOUT
            Left Column: Overview + Rules
            Right Column: Portrait Photo + Sticky Quick-Info HUD
            ════════════════════════════════════════════════════════════════ */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* ─────────────────────────────────────────────────────────────
              LEFT COLUMN (8 cols): Overview, Rules
              ───────────────────────────────────────────────────────────── */}
          <div className="lg:col-span-8 space-y-8">
            {/* Detailed Description Section (Overview & Structure) */}
            <motion.section
              variants={itemFadeUp}
              className="p-6 sm:p-8 rounded-3xl bg-[#090e1a]/90 backdrop-blur-xl border border-cyan-500/30 relative overflow-hidden"
            >
              <div className="mb-6 pb-4 border-b border-cyan-500/20">
                <h2 className="text-lg sm:text-xl font-black uppercase tracking-wider text-cyan-400">
                  Event Overview & Structure
                </h2>
              </div>

              <div className="prose prose-invert max-w-none">
                {detailedDescription ? (
                  renderFormattedDescription(detailedDescription)
                ) : (
                  <p className="text-zinc-300 text-base leading-relaxed">
                    {description}
                  </p>
                )}
              </div>
            </motion.section>

            {/* Rules & Guidelines Section */}
            {rules && rules.length > 0 && (
              <motion.section
                variants={itemFadeUp}
                className="p-6 sm:p-8 rounded-3xl bg-[#090e1a]/90 backdrop-blur-xl border border-cyan-500/30 relative overflow-hidden"
              >
                <div className="flex items-center justify-between gap-2 mb-6 pb-4 border-b border-cyan-500/20">
                  <h2 className="text-lg sm:text-xl font-black uppercase tracking-wider text-[#f6be50]">
                    Rules & Regulations
                  </h2>
                  {rulebookUrl && (
                    <span className="text-xs text-amber-300/80 font-bold tracking-wide uppercase hidden sm:inline">
                      Official Rulebook
                    </span>
                  )}
                </div>

                <ol className="space-y-3.5">
                  {rules.map((rule, idx) => (
                    <li
                      key={`rule-${idx}`}
                      className="flex items-start gap-3 text-zinc-300 text-sm sm:text-base leading-relaxed"
                    >
                      <span className="font-bold text-[#f6be50] shrink-0 select-none">
                        {idx + 1}.
                      </span>
                      <span>{rule}</span>
                    </li>
                  ))}
                </ol>
              </motion.section>
            )}
          </div>

          {/* ─────────────────────────────────────────────────────────────
              RIGHT COLUMN (4 cols): Portrait Photo + Sticky Quick-Info HUD
              ───────────────────────────────────────────────────────────── */}
          <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-28">
            {/* Small Portrait Photo Box */}
            {image && (
              <motion.div
                variants={itemFadeUp}
                className="relative w-full aspect-[4/3] sm:aspect-[16/10] lg:aspect-[4/3] rounded-3xl overflow-hidden border-2 border-cyan-400/50 bg-[#090e1a] group"
              >
                <Image
                  src={image}
                  alt={name}
                  fill
                  priority
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                />
              </motion.div>
            )}

            {/* Quick Info Card */}
            <motion.div
              variants={itemFadeUp}
              className="p-6 sm:p-7 rounded-3xl bg-[#090e1a]/95 backdrop-blur-2xl border-2 border-cyan-400/40 relative overflow-hidden"
            >
              {/* Prize Pool Highlight */}
              {prizePool && (
                <div className="mb-6 p-4 rounded-2xl bg-[#0d182b]/70 border border-[#f6be50]/60 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-semibold uppercase tracking-widest text-[#f6be50]">
                      Championship Prize Pool
                    </span>
                    <p className="text-2xl font-semibold text-white font-sans tracking-wide">
                      {prizePool}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#090e1a] border border-[#f6be50]/50 flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-[#f6be50]" />
                  </div>
                </div>
              )}

              {/* Event Metadata List */}
              <div className="space-y-4 mb-7">
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Calendar className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                      Date
                    </p>
                    <p className="text-sm font-normal text-zinc-200">
                      {displayDate}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                      Time
                    </p>
                    <p className="text-sm font-normal text-zinc-200">
                      {displayTime}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                      Venue
                    </p>
                    <p className="text-sm font-normal text-zinc-200">{venue}</p>
                  </div>
                </div>

                {teamSize && (
                  <div className="flex items-start gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                      <Users className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                        Team Size
                      </p>
                      <p className="text-sm font-normal text-zinc-200">
                        {teamSize}
                      </p>
                    </div>
                  </div>
                )}

                {eligibility && (
                  <div className="flex items-start gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                      <ShieldCheck className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                        Eligibility
                      </p>
                      <p className="text-xs font-normal text-zinc-300 leading-relaxed">
                        {eligibility}
                      </p>
                    </div>
                  </div>
                )}

                {registrationFee && (
                  <div className="flex items-start gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#0d182b] border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5">
                      <IndianRupee className="w-4 h-4 text-cyan-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-medium uppercase tracking-widest text-[#f6be50]">
                        Registration Fee
                      </p>
                      <p className="text-sm font-normal text-zinc-200">
                        {registrationFee}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Primary Call to Actions */}
              {(registerUrl ||
                (rulebookUrl &&
                  rulebookUrl !== "N/A" &&
                  rulebookUrl !== "coming-soon")) && (
                <div className="space-y-3 pt-5 border-t border-cyan-500/20">
                  {registerUrl && (
                    <Link
                      href={registerUrl}
                      target={isExternalRegister ? "_blank" : undefined}
                      rel={
                        isExternalRegister ? "noopener noreferrer" : undefined
                      }
                      className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full font-black text-sm uppercase tracking-wider transition-all bg-cyan-400 hover:bg-cyan-300 text-black hover:scale-105 active:scale-95"
                    >
                      <span>Register Now</span>
                      <ArrowRight className="w-4 h-4 text-current" />
                    </Link>
                  )}

                  {rulebookUrl &&
                    rulebookUrl !== "N/A" &&
                    rulebookUrl !== "coming-soon" && (
                      <Link
                        href={rulebookUrl}
                        rel={
                          rulebookUrl.endsWith(".pdf")
                            ? "noopener noreferrer"
                            : undefined
                        }
                        download
                        className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-[#090e1a] hover:bg-cyan-500/10 border-2 border-cyan-400/50 hover:border-cyan-300 text-cyan-300 hover:text-white text-xs font-black uppercase tracking-wider transition-all"
                      >
                        <Download className="w-4 h-4 text-cyan-400" />
                        <span>Download Rulebook (PDF)</span>
                      </Link>
                    )}
                </div>
              )}
            </motion.div>

            {/* Event Coordinators Card */}
            {coordinators && coordinators.length > 0 && (
              <motion.div
                variants={itemFadeUp}
                className="p-6 rounded-3xl bg-[#090e1a]/90 backdrop-blur-xl border border-cyan-500/30"
              >
                <h3 className="text-xs font-black uppercase tracking-widest text-cyan-400 mb-4 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-cyan-400" />
                  <span>Event Coordinators</span>
                </h3>
                <div className="space-y-3">
                  {coordinators.map((coord, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-[#070c17]/90 border border-cyan-500/20 flex items-center justify-between"
                    >
                      <div>
                        <p className="text-sm font-bold text-white">
                          {coord.name}
                        </p>
                        {coord.phone && (
                          <a
                            href={`tel:${coord.phone}`}
                            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium inline-flex items-center gap-1 mt-0.5"
                          >
                            <span>{coord.phone}</span>
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
