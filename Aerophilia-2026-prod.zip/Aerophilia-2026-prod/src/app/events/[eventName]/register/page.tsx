"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Calendar,
  GraduationCap,
  MapPin,
  Users,
} from "lucide-react";
import { ALL_EVENTS } from "@/data/events";
import { WorkshopRegistrationForm } from "@/components/common/forms/registrationForm";

export default function EventRegistration() {
  const { eventName } = useParams<{ eventName: string }>();

  // Look up the event from the central events registry
  const event = ALL_EVENTS.find((e) => e.id === eventName);

  // ── 404-style fallback ────────────────────────────────────────────────────
  if (!event) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4 gap-6">
        <div className="text-6xl font-black text-white/10">404</div>
        <h1 className="text-2xl font-bold text-white">Event Not Found</h1>
        <p className="text-slate-400 max-w-sm">
          The event <span className="text-cyan-400 font-mono">{eventName}</span>{" "}
          doesn&apos;t exist or registrations are not open yet.
        </p>
        <Link
          href="/events"
          className="inline-flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          View all events
        </Link>
      </div>
    );
  }

  // ── Registration Page ─────────────────────────────────────────────────────
  return (
    <div className="min-h-screen px-4 py-12 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Back link */}
        <Link
          href={`/events/${eventName}`}
          className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-cyan-400 transition-colors mb-8 group"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          Back to event details
        </Link>

        {/* ── Event Header ── */}
        <div className="mb-10 space-y-3">
          {/* Category badge */}
          <span className="inline-block text-[10px] font-bold tracking-[0.2em] uppercase text-cyan-400 border border-cyan-400/30 rounded-full px-3 py-1 bg-cyan-400/5">
            {event.tag ?? event.category}
          </span>

          <h1 className="text-3xl sm:text-4xl font-black text-white leading-tight">
            {event.name}
          </h1>

          {/* Meta pills */}
          <div className="flex flex-wrap gap-3 pt-1">
            {event.date && (
              <MetaPill icon={<Calendar className="w-3.5 h-3.5" />}>
                {event.date}
              </MetaPill>
            )}
            {event.venue && (
              <MetaPill icon={<MapPin className="w-3.5 h-3.5" />}>
                {event.venue}
              </MetaPill>
            )}
            {event.teamSize && (
              <MetaPill icon={<Users className="w-3.5 h-3.5" />}>
                {event.teamSize}
              </MetaPill>
            )}
            {event.category === "Workshops" && (
              <MetaPill
                icon={<GraduationCap className="w-3.5 h-3.5 text-cyan-400" />}
              >
                8th – 12th Std
              </MetaPill>
            )}
          </div>

          {event.description && (
            <p className="text-slate-400 text-sm leading-relaxed pt-1 max-w-xl">
              {event.description}
            </p>
          )}
        </div>

        {/* ── Glassmorphism Form Card ── */}
        <div className="relative rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-sm p-6 sm:p-8 shadow-[0_0_80px_rgba(6,182,212,0.05)]">
          {/* Glow accent top */}
          <div
            aria-hidden
            className="absolute -top-px left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"
          />

          <div className="mb-6">
            <h2 className="text-lg font-bold text-white">
              Registration Details
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Fields marked <span className="text-red-400">*</span> are
              required.
            </p>
          </div>

          <WorkshopRegistrationForm eventId={event.id} eventName={event.name} />
        </div>

        {/* ── Coordinators ── */}
        {event.coordinators && event.coordinators.length > 0 && (
          <div className="mt-8 rounded-xl border border-white/[0.06] bg-white/[0.02] p-5">
            <p className="text-xs font-semibold tracking-widest uppercase text-slate-500 mb-3">
              Need help?
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              {event.coordinators.map((coord) => (
                <div
                  key={coord.name}
                  className="flex items-center gap-3 text-sm"
                >
                  <div className="w-7 h-7 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 text-xs font-bold">
                    {coord.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-white font-medium text-xs">
                      {coord.name}
                    </p>
                    {coord.phone && (
                      <a
                        href={`tel:${coord.phone}`}
                        className="text-cyan-400/70 hover:text-cyan-400 text-xs transition-colors"
                      >
                        {coord.phone}
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Helper ────────────────────────────────────────────────────────────────

function MetaPill({
  icon,
  children,
}: {
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-slate-400 bg-white/[0.04] border border-white/[0.08] rounded-full px-3 py-1">
      <span className="text-cyan-400/70">{icon}</span>
      {children}
    </span>
  );
}
