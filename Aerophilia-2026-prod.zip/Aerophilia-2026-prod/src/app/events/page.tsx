"use client";

import { useState } from "react";
import { EventCard } from "@/components/common/events";
import {
  SAMPLE_EVENTS,
  CATEGORIES,
  type EventData,
  type EVENT_CATEGORIES,
} from "@/data/events";
import { Input } from "@base-ui/react/input";

export default function EventsPage() {
  const [selectedCategory, setSelectedCategory] =
    useState<EVENT_CATEGORIES>("All");
  const [searchQuery, setSearchQuery] = useState<string | null>("");

  const filteredEvents = SAMPLE_EVENTS.filter((e: EventData) => {
    const matchesCategory =
      selectedCategory === "All" || e.category === selectedCategory;
    const matchesSearch = e.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase().trim());

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col flex-1 bg-transparent font-sans text-white min-h-screen -mt-20 sm:-mt-24 pt-24 sm:pt-28 pb-12 overflow-x-hidden">
      {/* Background Tech Grid */}
      <div className="relative w-full pb-20 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col items-center">
        {/* Header Section */}
        <div className="relative z-10 text-center max-w-3xl mb-8 sm:mb-12 w-full px-2 flex flex-col items-center">
          {/* What's Taking Off EVENTS Capsule Badge */}
          <div className="inline-flex flex-col items-center justify-center rounded-full border-2 border-cyan-400 bg-[#090e1a]/90 px-8 py-3 sm:px-16 sm:py-4 shadow-[0_0_30px_rgba(6,182,212,0.25)] backdrop-blur-md">
            <span className="text-xs sm:text-base font-medium text-[#f6be50] tracking-wide">
              What&apos;s Taking Off
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-wider text-cyan-400 uppercase leading-tight font-sans">
              EVENTS
            </h1>
          </div>

          {/* Category Filter Pills (Horizontal scroll on mobile, wrap on desktop) */}
          <div className="flex flex-col items-center gap-4 mt-6 sm:mt-8 w-full max-w-4xl mx-auto px-2">
            {/* Search Input Container */}
            <div className="relative w-full max-w-md">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              <Input
                type="text"
                placeholder="Search interested events ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-[#0d1627] text-white text-xs sm:text-sm rounded-full border border-white/10 placeholder-zinc-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-all duration-200"
              />
            </div>

            {/* Category Pills & Input Group */}
            <div className="w-full overflow-x-auto flex sm:flex-wrap items-center justify-start sm:justify-center gap-2 pb-2 sm:pb-0 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  onClick={() =>
                    setSelectedCategory(category as EVENT_CATEGORIES)
                  }
                  className={`px-3.5 sm:px-4 py-1.5 rounded-full text-[11px] sm:text-xs font-semibold tracking-wider transition-all duration-200 shrink-0 ${
                    selectedCategory === category
                      ? "bg-cyan-500 text-black shadow-lg shadow-cyan-500/25 border border-cyan-400 scale-105"
                      : "bg-[#0d1627] text-zinc-400 border border-white/10 hover:border-cyan-500/40 hover:text-white"
                  }`}
                >
                  {category.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Events Cards Grid */}
        <div className="relative z-10 w-full max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 lg:gap-x-10 lg:gap-y-12 justify-items-center px-1 sm:px-4">
          {filteredEvents.map((event) => (
            <EventCard key={event.id} {...event} />
          ))}
        </div>

        {/* Empty state fallback */}
        {filteredEvents.length === 0 && (
          <div className="relative z-10 text-center py-12 px-4">
            <p className="text-zinc-400 text-sm mb-4">
              No events found matching your search.
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
              }}
              className="px-4 py-2 rounded-full text-xs font-semibold text-black bg-cyan-500 hover:bg-cyan-400 transition-all duration-200"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
