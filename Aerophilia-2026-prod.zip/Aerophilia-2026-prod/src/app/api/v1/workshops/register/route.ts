import { NextRequest, NextResponse } from "next/server";
import { clientDB } from "@/lib/firebase";
import { validateRegistrationService } from "@/services/validation-service";
import { FieldValue } from "firebase-admin/firestore";

export const dynamic = "force-dynamic"; // Prevents Static Site during buid time

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const response = validateRegistrationService.safeParse(body);

    if (!response.success) {
      return NextResponse.json(
        {
          success: false,
          message: `Error registering for ${body.eventName || "workshop"}`,
          errors: response.error.flatten().fieldErrors,
        },
        { status: 400 },
      );
    }

    const validatedData = response.data;

    const participantsRef = clientDB
      .collection("registrations")
      .doc(validatedData.eventId)
      .collection("participants");

    const existingSnapshot = await participantsRef
      .where("email", "==", validatedData.email)
      .where("eventName", "==", validatedData.eventName)
      .get();

    if (!existingSnapshot.empty) {
      return NextResponse.json(
        {
          success: false,
          message: "Duplicate registration",
          errors: `You are already registered for ${validatedData.eventName}.`,
        },
        { status: 409 },
      );
    }

    const docRef = await participantsRef.add({
      ...validatedData,
      registeredAt: FieldValue.serverTimestamp(),
    });

    return NextResponse.json(
      { success: true, registrationId: docRef.id },
      { status: 201 },
    );
  } catch (err: any) {
    console.error("Error registering for the workshop", err);
    return NextResponse.json(
      {
        success: false,
        message: "Server error",
        errors: "Internal server error. Please try again later.",
      },
      { status: 500 },
    );
  }
}
