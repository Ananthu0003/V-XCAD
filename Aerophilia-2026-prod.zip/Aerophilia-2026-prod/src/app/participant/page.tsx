import AttendeeCard from "@/components/common/attendee/attendee";

export default function ParticipantPage() {
  return (
    <div className="relative min-h-screen w-full bg-transparent pt-28 pb-16 px-4 flex flex-col items-center justify-center font-sans overflow-hidden">
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12 z-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-400/30 bg-cyan-950/40 text-cyan-400 text-xs font-mono tracking-widest uppercase mb-4 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
          <span>Aerophilia 2026 Pass</span>
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-400 to-indigo-300 tracking-wider uppercase">
          Claim Your Pass
        </h1>
        <p className="text-zinc-400 text-xs sm:text-sm md:text-base mt-3 font-medium max-w-lg mx-auto leading-relaxed">
          Customize your official attendee badge with your photo and details,
          then share it across socials.
        </p>
      </div>

      <div className="w-full max-w-5xl z-10">
        <AttendeeCard />
      </div>
    </div>
  );
}
