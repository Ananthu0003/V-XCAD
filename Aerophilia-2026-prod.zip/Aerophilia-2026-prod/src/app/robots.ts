import { MetadataRoute } from "next";

export default function Robots(): MetadataRoute.Robots {
  const baseUrl = `${process.env.FRONTEND_URL!}`;

  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: [
        "/api/",
        "/_next/",
        "/out",
        "/admin/",
        "/private/",
        "/public/assets",
        "/public",
        "/assets",
        "/lib",
      ],
    },
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
