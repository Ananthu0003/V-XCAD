"use client";

import React from "react";
import { Timeline } from "@/components/common/timeline/timeline";

export default function TimelinePage() {
  return (
    <main className="flex flex-col flex-1 bg-transparent font-sans text-white min-h-screen -mt-24 pt-28 pb-0 opacity-100 transition-opacity duration-300">
      <Timeline />
    </main>
  );
}
