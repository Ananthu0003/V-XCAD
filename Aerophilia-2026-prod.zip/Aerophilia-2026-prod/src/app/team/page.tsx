import { Metadata } from "next";
import { TeamHeader } from "@/components/common/team/Team-Header";
import { TeamSection } from "@/components/common/team/Team-Section";

export const metadata: Metadata = {
  title: "Meet the Team | Aerophilia 2026",
  description: "Meet the organizers and team behind Aerophilia 2026.",
};

export default function TeamPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-transparent text-white selection:bg-cyan-500 selection:text-black -mt-24 pt-24">
      <TeamHeader />
      <TeamSection />
    </div>
  );
}
