import type { ReactNode } from "react";

export interface PhotoSlide {
  id: string;
  title: string;
  description: string;
  /** Image source URL. If missing or invalid, a styled placeholder is displayed. */
  src?: string;
  alt: string;
  /** Set true for portrait/vertical photos to use blur-backdrop instead of crop */
  portrait?: boolean;
  /** Controls where object-cover anchors — e.g. 'top', 'center', 'bottom' */
  objectPosition?: string;
}

export interface ImageCarouselProps {
  slides?: PhotoSlide[];
  autoPlayInterval?: number;
}

/** Props for the InfoCard component */
export interface InfoCardProps {
  /** Card title displayed in cyan uppercase */
  title: string;
  /** Card body description text */
  description?: string;
  /** Optional custom children rendered below the description */
  children?: ReactNode;
  /** Optional additional className for the outer wrapper */
  className?: string;
}
