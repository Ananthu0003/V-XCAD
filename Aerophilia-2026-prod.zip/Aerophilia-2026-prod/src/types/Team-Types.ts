export interface TeamMember {
  name: string;
  role: string;
  photoUrl?: string;
  linkedinUrl?: string;
  githubUrl: string;
}
