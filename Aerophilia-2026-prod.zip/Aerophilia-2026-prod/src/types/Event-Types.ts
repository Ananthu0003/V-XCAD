import type { EventCardProps } from "@/components/common/events/EventCard";

/* Coordinator contact info for an event */
export interface EventCoordinator {
  name: string;
  phone?: string;
}

/*
 * Extended event data used on the Event Details page.
 * All new fields are optional so existing events won't break.
 */
export interface EventDetailData extends EventCardProps {
  id: string;
  time: string;
  description: string;
  rulebookUrl?: string;

  /* ── New optional fields (data to be provided later) ── */
  detailedDescription?: string;
  teamSize?: string;
  eligibility?: string;
  registrationFee?: string;
  rules?: string[];
  coordinators?: EventCoordinator[];
}
