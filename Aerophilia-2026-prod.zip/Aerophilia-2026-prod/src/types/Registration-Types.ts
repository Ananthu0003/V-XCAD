/**
 * Aerophilia 2026 — Workshop Registration Types
 */

export type WorkshopGrade =
  | "8th Std"
  | "9th Std"
  | "10th Std"
  | "11th Std"
  | "12th Std"
  | "Others"
  | string;

export interface WorkshopRegistrationData {
  /** Participant's full name */
  name: string;
  /** Participant's email address */
  email: string;
  /** Participant's phone number (10 digits) */
  phone: string;
  /** School / PU College / Institution name */
  college: string;
  /** Class / Grade of study (8th - 12th) */
  year: WorkshopGrade;
  /** Stream / Section (optional or e.g. Science, General) */
  department?: string;

  /** Participant's Student ID / Roll Number */
  usn?: string;

  /** Slugified event id, e.g. "aeromodeling-workshop" */
  eventId: string;
  /** Human-readable event name */
  eventName: string;
  /** ISO timestamp of registration */
  registeredAt: string;
}

export interface RegistrationResult {
  success: boolean;
  registrationId?: string;
  errors?: string | string[] | Record<string, string[]>;
  message?: string;
}
