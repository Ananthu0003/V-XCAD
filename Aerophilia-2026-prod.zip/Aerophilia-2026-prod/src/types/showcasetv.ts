export interface AirShowData {
  id: string;
  label: string;
  channelName: string;
  image: string;
  description: string;
}
