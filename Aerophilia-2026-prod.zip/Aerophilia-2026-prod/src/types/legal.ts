export interface LegalCallout {
  title?: string;
  text: string;
  type?: "info" | "warning" | "note";
}

export interface LegalSubSection {
  title: string;
  paragraphs?: string[];
  bullets?: string[];
}

export interface LegalSection {
  id: string;
  number: number;
  title: string;
  badge?: string;
  lead?: string;
  paragraphs: string[];
  bullets?: string[];
  subsections?: LegalSubSection[];
  callout?: LegalCallout;
}

export interface LegalPageData {
  title: string;
  subtitle: string;
  category: string;
  description: string;
  lastUpdated: string;
  version: string;
  sections: LegalSection[];
}
