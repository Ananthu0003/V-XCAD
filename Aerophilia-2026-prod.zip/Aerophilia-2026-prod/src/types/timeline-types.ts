export type TimelineNodeState = "upcoming" | "active" | "completed";

export interface TimelineEvent {
  id: string;
  eventNumber: string;
  title: string;
  date: string;
  time: string;
  progress: number; // Position along the path (0.0 to 1.0)
  side: "above" | "below";
  category?: string;
  venue?: string;
  prizePool?: string;
  registrationUrl?: string;
}
