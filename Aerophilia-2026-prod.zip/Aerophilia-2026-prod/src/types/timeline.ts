/**
 * Aerophilia 2026 — Shared Timeline Data Types
 */

export type TimelineEventCategory =
  "all" | "flagship" | "technical" | "non-technical" | "workshop" | "keynote";

/** Current execution status of an event item */
export type TimelineEventStatus = "upcoming" | "live" | "completed";

export interface TimelineEvent {
  id: string;
  title: string;
  subtitle: string;
  category: Exclude<TimelineEventCategory, "all">;
  dayNumber: 1 | 2 | 3;
  dateString: string; // e.g. "Nov 13, 2026"
  startTime: string; // e.g. "09:30 AM"
  endTime: string; // e.g. "12:30 PM"
  location: string;
  description: string;
  prizePool?: string;
  registrationUrl?: string;
  speakerOrHost?: {
    name: string;
    role: string;
    organization?: string;
    avatarUrl?: string;
  };
  tags: string[];
  status: TimelineEventStatus;
  isFeatured?: boolean;
}

/**
 * Filter and Search state object.
 */
export interface TimelineFilterState {
  category: TimelineEventCategory;
  searchQuery: string;
  statusFilter: TimelineEventStatus | "all";
  selectedDay: 1 | 2 | 3 | "all";
}
