import * as React from "react";
import { Input as InputPrimitive } from "@base-ui/react/input";

import { cn } from "@/lib/utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <InputPrimitive
      type={type}
      data-slot="input"
      className={cn(
        "h-10 w-full min-w-0 rounded-xl border border-cyan-500/30 bg-[#0b1324] px-3 py-2 text-sm text-zinc-100 transition-all outline-none file:mr-2 file:inline-flex file:h-7 file:items-center file:rounded-lg file:border-0 file:bg-cyan-500/10 file:px-2.5 file:text-xs file:font-semibold file:uppercase file:tracking-wider file:text-cyan-300 hover:file:bg-cyan-500/20 placeholder:text-zinc-500 focus-visible:border-cyan-400 focus-visible:ring-2 focus-visible:ring-cyan-400/40 focus-visible:shadow-[0_0_15px_rgba(6,182,212,0.25)] disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-zinc-900/50 disabled:opacity-50 aria-invalid:border-red-500 aria-invalid:ring-2 aria-invalid:ring-red-500/30 md:text-sm",
        className,
      )}
      {...props}
    />
  );
}

export { Input };
