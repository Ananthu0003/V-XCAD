"use client";

import React, { createContext, useContext, useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── Context ─── */
interface AccordionContextType {
  openItem: string | null;
  toggleItem: (id: string) => void;
}

const AccordionContext = createContext<AccordionContextType | undefined>(
  undefined,
);

/* ─── Root ─── */
export const Accordion = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  const [openItem, setOpenItem] = useState<string | null>(null);
  const toggleItem = (id: string) =>
    setOpenItem((prev) => (prev === id ? null : id));

  return (
    <AccordionContext.Provider value={{ openItem, toggleItem }}>
      <div className={cn("w-full", className)}>{children}</div>
    </AccordionContext.Provider>
  );
};

/* ─── Item ─── */
export const AccordionItem = ({
  id,
  children,
  className,
}: {
  id: string;
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <div className={cn("rounded-lg overflow-hidden", className)}>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, { id } as Record<string, unknown>);
        }
        return child;
      })}
    </div>
  );
};

/* ─── Trigger ─── */
export const AccordionTrigger = ({
  id,
  children,
  className,
  indicatorClassName,
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
  indicatorClassName?: string;
}) => {
  const context = useContext(AccordionContext);
  if (!context)
    throw new Error("AccordionTrigger must be used within an Accordion");
  const isOpen = context.openItem === id;

  return (
    <button
      onClick={() => id && context.toggleItem(id)}
      className={cn(
        "flex w-full items-center justify-between px-5 py-4 text-left font-medium transition-all duration-200 cursor-pointer",
        className,
      )}
      aria-expanded={isOpen}
    >
      <span className="flex-1">{children}</span>
      <div
        className={cn(
          "flex items-center justify-center shrink-0 ml-4 transition-transform duration-300 ease-out",
          isOpen && "rotate-180",
          indicatorClassName,
        )}
      >
        <ChevronDown className="h-4 w-4" />
      </div>
    </button>
  );
};

/* ─── Content ─── */
export const AccordionContent = ({
  id,
  children,
  className,
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
}) => {
  const context = useContext(AccordionContext);
  if (!context)
    throw new Error("AccordionContent must be used within an Accordion");
  const isOpen = context.openItem === id;

  return (
    <div
      className={cn(
        "grid transition-all duration-300 ease-in-out",
        isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
      )}
    >
      <div className="overflow-hidden">
        <div className={cn("px-5 pb-5 pt-0", className)}>{children}</div>
      </div>
    </div>
  );
};
