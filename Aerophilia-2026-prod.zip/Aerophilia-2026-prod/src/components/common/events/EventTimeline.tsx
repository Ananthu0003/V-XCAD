"use client";

import React, { useEffect, useRef, useState, useId, useCallback } from "react";
import { useScroll, useMotionValueEvent } from "framer-motion";
import { TimelineEvent, TimelineNodeState } from "@/types/timeline-types";
import { TimelineCard } from "./TimelineCard";

export interface EventTimelineProps {
  events: TimelineEvent[];
}

// Pre-calculated exact physical path ratios for 0ms instant load
const EXACT_DESKTOP_RATIOS = [
  0.0324, 0.0999, 0.1674, 0.3081, 0.3756, 0.4431, 0.5731, 0.6406, 0.7081,
  0.8381, 0.9056, 0.9731,
];

const EXACT_MOBILE_RATIOS = [
  0.012, 0.097, 0.182, 0.267, 0.353, 0.438, 0.523, 0.609, 0.694, 0.779, 0.865,
  0.95,
];

// Desktop S-curve Path definition (Viewbox: 0 0 1000 950)
const DESKTOP_PATH_D = `
  M 120,150 
  L 820,150 
  C 960,150 960,380 820,380 
  L 180,380 
  C 40,380 40,610 180,610 
  L 820,610 
  C 960,610 960,840 820,840 
  L 180,840
`;

// Desktop exact marker coordinates (12 positions: 3 on each straight track)
const DESKTOP_MARKER_POSITIONS = [
  { x: 240, y: 150, side: "above" },
  { x: 490, y: 150, side: "above" },
  { x: 740, y: 150, side: "above" },
  { x: 740, y: 380, side: "above" },
  { x: 490, y: 380, side: "above" },
  { x: 240, y: 380, side: "above" },
  { x: 240, y: 610, side: "above" },
  { x: 490, y: 610, side: "above" },
  { x: 740, y: 610, side: "above" },
  { x: 740, y: 840, side: "above" },
  { x: 490, y: 840, side: "above" },
  { x: 240, y: 840, side: "above" },
];

export function EventTimeline({ events }: EventTimelineProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Desktop DOM refs
  const desktopPathRef = useRef<SVGPathElement>(null);
  const desktopActivePathRef = useRef<SVGPathElement>(null);
  const desktopRocketGroupRef = useRef<SVGGElement>(null);
  const desktopPathLengthRef = useRef<number>(0);

  // Mobile DOM refs (Direct GPU updates for 0ms lag)
  const mobileActiveTrackRef = useRef<HTMLDivElement>(null);
  const mobileAirplaneRef = useRef<HTMLDivElement>(null);

  const [isMobile, setIsMobile] = useState(false);

  // Discrete milestone states for cards to avoid re-rendering on every scroll pixel
  const [nodeStates, setNodeStates] = useState<TimelineNodeState[]>(() =>
    events.map(() => "upcoming"),
  );
  const prevStatesRef = useRef<TimelineNodeState[]>(nodeStates);

  const filterId = useId();
  const jetGlowId = `jet-glow-${filterId.replace(/:/g, "")}`;

  // Framer Motion scroll progress tracking
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start 20%", "end 80%"],
  });

  const prevProgressRef = useRef(0);
  const directionRef = useRef<1 | -1>(1);

  // Measure and cache desktop path length once on mount / resize
  const measurePath = useCallback(() => {
    if (desktopPathRef.current) {
      const len = desktopPathRef.current.getTotalLength();
      desktopPathLengthRef.current = len;
      if (desktopActivePathRef.current) {
        desktopActivePathRef.current.style.strokeDasharray = `${len}`;
        desktopActivePathRef.current.style.strokeDashoffset = `${len}`;
      }
    }
  }, []);

  // Screen size check and path length initialization
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        measurePath();
      }
    };
    checkMobile();
    window.addEventListener("resize", checkMobile, { passive: true });
    return () => window.removeEventListener("resize", checkMobile);
  }, [measurePath]);

  // Initial measure
  useEffect(() => {
    measurePath();
  }, [measurePath]);

  // Ultra-optimized scroll event listener
  useMotionValueEvent(scrollYProgress, "change", (latest) => {
    const p = Math.max(0, Math.min(1, latest));
    const prevP = prevProgressRef.current;

    // Skip micro-jitter
    if (Math.abs(p - prevP) < 0.0001) return;

    // Update scroll direction
    if (p > prevP) {
      directionRef.current = 1;
    } else if (p < prevP) {
      directionRef.current = -1;
    }
    prevProgressRef.current = p;

    // -------------------------------------------------------------
    // 1. DESKTOP DIRECT DOM ANIMATION (Zero React Re-renders)
    // -------------------------------------------------------------
    if (!isMobile) {
      const desktopPathEl = desktopPathRef.current;
      const desktopActivePathEl = desktopActivePathRef.current;
      const rocketEl = desktopRocketGroupRef.current;

      if (desktopPathEl && rocketEl) {
        let totalLength = desktopPathLengthRef.current;
        if (totalLength === 0) {
          totalLength = desktopPathEl.getTotalLength();
          desktopPathLengthRef.current = totalLength;
        }

        if (totalLength > 0) {
          const currentLen = p * totalLength;
          const pt = desktopPathEl.getPointAtLength(currentLen);

          // Find tangent vector for rotation
          const deltaLen = Math.min(currentLen + 2, totalLength);
          const nextPt = desktopPathEl.getPointAtLength(deltaLen);
          const dx = nextPt.x - pt.x;
          const dy = nextPt.y - pt.y;
          let angle = (Math.atan2(dy, dx) * 180) / Math.PI;

          if (directionRef.current === -1) {
            angle += 180;
          }

          rocketEl.setAttribute(
            "transform",
            `translate(${pt.x}, ${pt.y}) rotate(${angle})`,
          );

          if (desktopActivePathEl) {
            desktopActivePathEl.style.strokeDashoffset = `${totalLength - currentLen}`;
          }
        }
      }
    }

    // -------------------------------------------------------------
    // 2. MOBILE DIRECT DOM ANIMATION (Zero React Re-renders)
    // -------------------------------------------------------------
    if (isMobile) {
      if (mobileActiveTrackRef.current) {
        mobileActiveTrackRef.current.style.height = `calc(${p * 100}% * 0.95)`;
      }
      if (mobileAirplaneRef.current) {
        const rot = directionRef.current === -1 ? -90 : 90;
        mobileAirplaneRef.current.style.top = `calc(40px + ${p * 100}% * 0.95 - 17px)`;
        mobileAirplaneRef.current.style.transform = `rotate(${rot}deg)`;
      }
    }

    // -------------------------------------------------------------
    // 3. DISCRETE MILESTONE CHECK (Re-renders ONLY on state change)
    // -------------------------------------------------------------
    const ratios = isMobile ? EXACT_MOBILE_RATIOS : EXACT_DESKTOP_RATIOS;
    const tolerance = isMobile ? 0.04 : 0.02;

    let hasStateChange = false;
    const nextStates: TimelineNodeState[] = new Array(events.length);

    for (let i = 0; i < events.length; i++) {
      const nodeP =
        ratios[i] ?? 0.02 + i * (0.96 / Math.max(1, events.length - 1));
      const diff = p - nodeP;

      let s: TimelineNodeState = "upcoming";
      if (diff >= 0.012) {
        s = "completed";
      } else if (Math.abs(diff) <= tolerance) {
        s = "active";
      }

      nextStates[i] = s;
      if (s !== prevStatesRef.current[i]) {
        hasStateChange = true;
      }
    }

    if (hasStateChange) {
      prevStatesRef.current = nextStates;
      setNodeStates(nextStates);
    }
  });

  // Smoothly scroll window to target event node when clicked
  const scrollToEventNode = (idx: number) => {
    if (!containerRef.current) return;
    const ratios = isMobile ? EXACT_MOBILE_RATIOS : EXACT_DESKTOP_RATIOS;
    const targetProgress = ratios[idx] ?? events[idx]?.progress ?? 0;
    const rect = containerRef.current.getBoundingClientRect();
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const targetY = rect.top + scrollTop + targetProgress * rect.height - 250;
    window.scrollTo({ top: Math.max(0, targetY), behavior: "smooth" });
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-6xl mx-auto py-8 px-2 sm:px-6 select-none overflow-hidden"
    >
      <style>{`
        .flame { transform-box: fill-box; transform-origin: top center; }
        .flame-outer { animation: pulse-outer 0.15s ease-in-out infinite alternate; }
        .flame-inner { animation: pulse-inner 0.12s ease-in-out infinite alternate; }
        .flame-core { animation: pulse-core 0.1s ease-in-out infinite alternate; }
        @keyframes pulse-outer {
            from { transform: scaleY(0.95); filter: drop-shadow(0 5px 15px rgba(255, 69, 0, 0.6)); opacity: 0.8; }
            to { transform: scaleY(1.05); filter: drop-shadow(0 20px 40px rgba(255, 69, 0, 1)) drop-shadow(0 0 20px rgba(255, 69, 0, 0.8)); opacity: 1; }
        }
        @keyframes pulse-inner {
            from { transform: scaleY(0.9); filter: drop-shadow(0 0 10px rgba(255, 215, 0, 0.6)); }
            to { transform: scaleY(1.1); filter: drop-shadow(0 15px 30px rgba(255, 215, 0, 1)); }
        }
        @keyframes pulse-core {
            from { transform: scaleY(0.9); filter: drop-shadow(0 0 5px rgba(224, 255, 255, 0.6)); }
            to { transform: scaleY(1.05); filter: drop-shadow(0 5px 15px rgba(224, 255, 255, 1)); }
        }
      `}</style>

      {/* =========================================================================
          DESKTOP SERPENTINE TIMELINE (md breakpoint and up)
          ========================================================================= */}
      <div className="hidden md:block relative w-full aspect-[1000/950]">
        {/* Departure Label */}
        <div className="absolute top-[115px] left-[15px] flex flex-col items-center text-amber-400 z-20">
          <span className="text-xs font-extrabold font-mono tracking-widest uppercase mb-1">
            Departure
          </span>
        </div>

        {/* Arrival Label */}
        <div className="absolute bottom-[95px] left-[100px] flex items-center gap-2 text-amber-400 z-20">
          <span className="text-xs font-extrabold font-mono tracking-widest uppercase">
            Arrival
          </span>
        </div>

        {/* Base SVG Path Track & Revealer (z-10) */}
        <svg
          viewBox="0 0 1000 950"
          className="absolute inset-0 w-full h-full overflow-visible z-10 pointer-events-none"
        >
          <defs>
            <filter id={jetGlowId} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background Path Track */}
          <path
            ref={desktopPathRef}
            d={DESKTOP_PATH_D}
            fill="none"
            stroke="#1a2d42"
            strokeWidth="6"
            strokeLinecap="round"
          />

          {/* Active Revealed Neon Cyan Path */}
          <path
            ref={desktopActivePathRef}
            d={DESKTOP_PATH_D}
            fill="none"
            stroke="#00f0ff"
            strokeWidth="6"
            strokeLinecap="round"
            style={{
              filter: "drop-shadow(0 0 8px rgba(0,240,255,0.8))",
            }}
          />
        </svg>

        {/* Overlay Flight Image SVG (z-40) — Renders aircraft ON TOP of all cards */}
        <svg
          viewBox="0 0 1000 950"
          className="absolute inset-0 w-full h-full overflow-visible z-40 pointer-events-none"
        >
          <g
            ref={desktopRocketGroupRef}
            className="will-change-transform"
            transform="translate(120, 150) rotate(0)"
          >
            <g transform="rotate(90)">
              {/* Glowing Rocket Vector Icon */}
              <g
                transform="scale(0.13) translate(-200, -230)"
                filter={`url(#${jetGlowId})`}
              >
                <path
                  className="flame flame-outer"
                  d="M170 440 Q200 600 200 600 Q200 600 230 440 Q200 540 170 440"
                  fill="#FF4500"
                  opacity="0.9"
                />
                <path
                  className="flame flame-inner"
                  d="M180 440 Q200 550 200 550 Q200 550 220 440 Q200 510 180 440"
                  fill="#FFD700"
                />
                <path
                  className="flame flame-core"
                  d="M190 440 Q200 490 200 490 Q200 490 210 440 Q200 470 190 440"
                  fill="#E0FFFF"
                />
                <polygon
                  points="170,420 230,420 235,445 165,445"
                  fill="#B0B0B0"
                />
                <polygon
                  points="175,420 225,420 228,445 172,445"
                  fill="#666666"
                />
                <path
                  d="M200 40 C210 100 225 150 225 220 L225 425 L175 425 L175 220 C175 150 190 100 200 40 Z"
                  fill="#FFFFFF"
                />
                <polygon
                  points="225,200 255,220 255,290 225,270"
                  fill="#F0F0F0"
                />
                <polygon
                  points="225,205 248,222 248,235 225,220"
                  fill="#1A1A1A"
                />
                <polygon
                  points="175,200 145,220 145,290 175,270"
                  fill="#F0F0F0"
                />
                <polygon
                  points="175,205 152,222 152,235 175,220"
                  fill="#1A1A1A"
                />
                <polygon
                  points="225,270 355,360 355,405 225,385"
                  fill="#FFFFFF"
                />
                <polygon
                  points="175,270 45,360 45,405 175,385"
                  fill="#FFFFFF"
                />
                <line
                  x1="225"
                  y1="365"
                  x2="345"
                  y2="395"
                  stroke="#E0E0E0"
                  strokeWidth="2"
                />
                <line
                  x1="175"
                  y1="365"
                  x2="55"
                  y2="395"
                  stroke="#E0E0E0"
                  strokeWidth="2"
                />
                <polygon
                  points="215,370 275,455 250,465 220,425"
                  fill="#F8F8F8"
                />
                <polygon
                  points="185,370 125,455 150,465 180,425"
                  fill="#F8F8F8"
                />
                <path
                  d="M200 110 L213 155 C213 165 208 175 200 175 C192 175 187 165 187 155 Z"
                  fill="#1A1A1A"
                />
                <path
                  d="M200 112 L211 155 C211 163 207 172 200 172 Z"
                  fill="#87CEFA"
                  opacity="0.8"
                />
                <line
                  x1="200"
                  y1="110"
                  x2="200"
                  y2="175"
                  stroke="#FFFFFF"
                  strokeWidth="1.5"
                />
                <line
                  x1="200"
                  y1="40"
                  x2="200"
                  y2="110"
                  stroke="#E0E0E0"
                  strokeWidth="1"
                />
                <line
                  x1="200"
                  y1="175"
                  x2="200"
                  y2="425"
                  stroke="#E0E0E0"
                  strokeWidth="1"
                />
                <path
                  d="M175 220 L225 220"
                  stroke="#E0E0E0"
                  strokeWidth="1.5"
                  fill="none"
                />
                <path
                  d="M175 320 L225 320"
                  stroke="#E0E0E0"
                  strokeWidth="1.5"
                  fill="none"
                />
                <polygon
                  points="200,250 205,260 215,260 207,266 210,276 200,270 190,276 193,266 185,260 195,260"
                  fill="#CCCCCC"
                />
              </g>
            </g>
          </g>
        </svg>

        {/* 10 Event Cards & Markers on Desktop */}
        {events.map((ev, idx) => {
          const coords = DESKTOP_MARKER_POSITIONS[idx] || {
            x: 500,
            y: 500,
            side: "above",
          };
          const state = nodeStates[idx] || "upcoming";

          return (
            <React.Fragment key={ev.id}>
              {/* Node Marker Circle on Path */}
              <div
                onClick={() => scrollToEventNode(idx)}
                className="absolute z-20 -translate-x-1/2 -translate-y-1/2 transition-transform duration-300 pointer-events-auto cursor-pointer"
                style={{
                  left: `${(coords.x / 1000) * 100}%`,
                  top: `${(coords.y / 950) * 100}%`,
                }}
                title={`Click to view ${ev.title}`}
              >
                <div
                  className={`relative flex items-center justify-center rounded-full transition-all duration-300 ${
                    state === "active"
                      ? "w-7 h-7 bg-amber-400 shadow-[0_0_22px_#fbbf24] scale-125 z-30"
                      : state === "completed"
                        ? "w-5 h-5 bg-cyan-400 shadow-[0_0_10px_#38bdf8]"
                        : "w-4 h-4 bg-[#0f2136] border-2 border-cyan-500/40"
                  }`}
                >
                  <div
                    className={`rounded-full ${
                      state === "active"
                        ? "w-3 h-3 bg-white"
                        : state === "completed"
                          ? "w-2 h-2 bg-[#0a1322]"
                          : "w-1.5 h-1.5 bg-cyan-400/60"
                    }`}
                  />
                </div>
              </div>

              {/* Event Card Container positioned ABOVE node */}
              <div
                className="absolute z-30 pointer-events-auto"
                style={{
                  left: `${(coords.x / 1000) * 100}%`,
                  top: `${((coords.y - 28) / 950) * 100}%`,
                  transform: "translate(-50%, -100%)",
                }}
              >
                <TimelineCard
                  event={ev}
                  state={state}
                  variant="desktop"
                  onClick={() => scrollToEventNode(idx)}
                />
              </div>
            </React.Fragment>
          );
        })}
      </div>

      {/* =========================================================================
          COMPACT MOBILE VERTICAL TIMELINE (< md breakpoint)
          ========================================================================= */}
      <div className="block md:hidden relative w-full pt-10 pb-12 px-2 sm:px-4">
        {/* Mobile Vertical CSS Track */}
        <div className="absolute top-10 bottom-12 left-[28px] w-[4px] bg-[#1a2d42] rounded-full z-10" />

        {/* Mobile Active CSS Track */}
        <div
          ref={mobileActiveTrackRef}
          className="absolute top-10 left-[28px] w-[4px] bg-[#00f0ff] rounded-full z-10 will-change-[height]"
          style={{
            height: "0%",
            filter: "drop-shadow(0 0 6px rgba(0,240,255,0.8))",
          }}
        />

        {/* Mobile CSS Airplane (Hardware-accelerated) */}
        <div
          ref={mobileAirplaneRef}
          className="absolute left-[13px] z-40 will-change-transform pointer-events-none"
          style={{
            top: "40px",
            transform: "rotate(90deg)",
          }}
        >
          <svg
            viewBox="-24 -24 48 48"
            className="w-[34px] h-[34px] overflow-visible"
          >
            {/* Glowing Rocket Vector Icon */}
            <g
              transform="scale(0.13) translate(-200, -230)"
              filter={`url(#${jetGlowId})`}
            >
              <path
                className="flame flame-outer"
                d="M170 440 Q200 600 200 600 Q200 600 230 440 Q200 540 170 440"
                fill="#FF4500"
                opacity="0.9"
              />
              <path
                className="flame flame-inner"
                d="M180 440 Q200 550 200 550 Q200 550 220 440 Q200 510 180 440"
                fill="#FFD700"
              />
              <path
                className="flame flame-core"
                d="M190 440 Q200 490 200 490 Q200 490 210 440 Q200 470 190 440"
                fill="#E0FFFF"
              />
              <polygon
                points="170,420 230,420 235,445 165,445"
                fill="#B0B0B0"
              />
              <polygon
                points="175,420 225,420 228,445 172,445"
                fill="#666666"
              />
              <path
                d="M200 40 C210 100 225 150 225 220 L225 425 L175 425 L175 220 C175 150 190 100 200 40 Z"
                fill="#FFFFFF"
              />
              <polygon
                points="225,200 255,220 255,290 225,270"
                fill="#F0F0F0"
              />
              <polygon
                points="225,205 248,222 248,235 225,220"
                fill="#1A1A1A"
              />
              <polygon
                points="175,200 145,220 145,290 175,270"
                fill="#F0F0F0"
              />
              <polygon
                points="175,205 152,222 152,235 175,220"
                fill="#1A1A1A"
              />
              <polygon
                points="225,270 355,360 355,405 225,385"
                fill="#FFFFFF"
              />
              <polygon points="175,270 45,360 45,405 175,385" fill="#FFFFFF" />
              <line
                x1="225"
                y1="365"
                x2="345"
                y2="395"
                stroke="#E0E0E0"
                strokeWidth="2"
              />
              <line
                x1="175"
                y1="365"
                x2="55"
                y2="395"
                stroke="#E0E0E0"
                strokeWidth="2"
              />
              <polygon
                points="215,370 275,455 250,465 220,425"
                fill="#F8F8F8"
              />
              <polygon
                points="185,370 125,455 150,465 180,425"
                fill="#F8F8F8"
              />
              <path
                d="M200 110 L213 155 C213 165 208 175 200 175 C192 175 187 165 187 155 Z"
                fill="#1A1A1A"
              />
              <path
                d="M200 112 L211 155 C211 163 207 172 200 172 Z"
                fill="#87CEFA"
                opacity="0.8"
              />
              <line
                x1="200"
                y1="110"
                x2="200"
                y2="175"
                stroke="#FFFFFF"
                strokeWidth="1.5"
              />
              <line
                x1="200"
                y1="40"
                x2="200"
                y2="110"
                stroke="#E0E0E0"
                strokeWidth="1"
              />
              <line
                x1="200"
                y1="175"
                x2="200"
                y2="425"
                stroke="#E0E0E0"
                strokeWidth="1"
              />
              <path
                d="M175 220 L225 220"
                stroke="#E0E0E0"
                strokeWidth="1.5"
                fill="none"
              />
              <path
                d="M175 320 L225 320"
                stroke="#E0E0E0"
                strokeWidth="1.5"
                fill="none"
              />
              <polygon
                points="200,250 205,260 215,260 207,266 210,276 200,270 190,276 193,266 185,260 195,260"
                fill="#CCCCCC"
              />
            </g>
          </svg>
        </div>

        {/* Mobile Departure Label */}
        <div className="absolute top-2 left-2 text-amber-400 text-[11px] font-mono font-bold tracking-wider z-20">
          🚀 DEPARTURE
        </div>

        {/* 10 Mobile Event Cards Stacked Vertically */}
        <div className="flex flex-col gap-6 pl-[54px] pr-1 relative z-20">
          {events.map((ev, idx) => {
            const state = nodeStates[idx] || "upcoming";

            return (
              <div key={ev.id} className="relative flex items-center w-full">
                {/* Node Marker on vertical line (x=28) */}
                <div
                  onClick={() => scrollToEventNode(idx)}
                  className="absolute -left-[35px] flex items-center justify-center cursor-pointer"
                >
                  <div
                    className={`rounded-full transition-all duration-300 ${
                      state === "active"
                        ? "w-5 h-5 bg-amber-400 shadow-[0_0_12px_#fbbf24] scale-110"
                        : state === "completed"
                          ? "w-4 h-4 bg-cyan-400 shadow-[0_0_8px_#38bdf8]"
                          : "w-3.5 h-3.5 bg-[#0f2136] border border-cyan-500/50"
                    }`}
                  />
                </div>

                {/* Mobile Responsive Timeline Card */}
                <div className="w-full">
                  <TimelineCard
                    event={ev}
                    state={state}
                    variant="mobile"
                    onClick={() => scrollToEventNode(idx)}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Arrival Label */}
        <div className="absolute bottom-2 left-2 text-amber-400 text-[11px] font-mono font-bold tracking-wider z-20">
          📍 ARRIVAL
        </div>
      </div>
    </div>
  );
}
