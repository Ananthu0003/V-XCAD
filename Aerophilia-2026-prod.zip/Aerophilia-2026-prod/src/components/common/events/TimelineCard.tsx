"use client";

import React from "react";
import { TimelineEvent, TimelineNodeState } from "@/types/timeline-types";
import Link from "next/link";

export interface TimelineCardProps {
  event: TimelineEvent;
  state: TimelineNodeState;
  variant?: "desktop" | "mobile";
  onClick?: () => void;
}

export const TimelineCard = React.memo(function TimelineCard({
  event,
  state,
  variant = "desktop",
  onClick,
}: TimelineCardProps) {
  const isActive = state === "active";
  const isCompleted = state === "completed";

  return (
    <div
      onClick={onClick}
      className={`group relative flex flex-col justify-center px-4 py-3 rounded-xl border transition-all duration-300 cursor-pointer ${
        variant === "mobile"
          ? "w-full max-w-sm sm:max-w-md"
          : "min-w-[200px] max-w-[240px]"
      } ${
        isActive
          ? "bg-[#0c182b]/95 border-cyan-400 shadow-[0_0_25px_rgba(56,189,248,0.4)] scale-105 z-30"
          : isCompleted
            ? "bg-[#0b1322]/90 border-cyan-600/50 shadow-md hover:border-cyan-400/70 hover:scale-102 z-20 opacity-90"
            : "bg-[#080d17]/85 border-cyan-900/40 shadow-sm opacity-70 hover:opacity-100 hover:border-cyan-500/50 z-10"
      }`}
      style={{
        backdropFilter: "blur(12px)",
      }}
    >
      {/* Callout Tail / Pointer Stem */}
      {variant === "mobile" ? (
        <div
          className={`absolute left-0 top-1/2 -translate-y-1/2 -translate-x-full w-0 h-0 border-y-[8px] border-y-transparent border-r-[12px] transition-colors duration-300 ${
            isActive
              ? "border-r-cyan-400"
              : isCompleted
                ? "border-r-cyan-600/50"
                : "border-r-cyan-900/40"
          }`}
        />
      ) : (
        <div
          className={`absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-x-[10px] border-x-transparent border-t-[14px] transition-colors duration-300 ${
            isActive
              ? "border-t-cyan-400"
              : isCompleted
                ? "border-t-cyan-600/50"
                : "border-t-cyan-900/40"
          }`}
        />
      )}

      {/* Event Header: Date & Time */}
      <div className="flex items-center justify-between gap-2 mb-1">
        <span
          className={`text-[10px] font-mono font-bold tracking-wider uppercase ${
            isActive
              ? "text-cyan-300"
              : isCompleted
                ? "text-amber-400/90"
                : "text-zinc-400"
          }`}
        >
          {event.eventNumber}
        </span>
        <span className="text-[10px] font-mono text-cyan-400/80">
          {event.date}, {event.time}
        </span>
      </div>

      {/* Event Title */}
      <Link
        href={event.registrationUrl || `/events/${event.id}`}
        className={`text-xs sm:text-sm font-bold tracking-tight line-clamp-1 transition-colors ${
          isActive
            ? "text-white"
            : isCompleted
              ? "text-cyan-100"
              : "text-zinc-300 group-hover:text-cyan-200"
        }`}
      >
        {event.title}
      </Link>

      {/* Category / Venue metadata badge */}
      {(event.category || event.venue) && (
        <div className="mt-1.5 flex items-center gap-1.5 text-[9px] text-zinc-400 font-sans">
          {event.category && (
            <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40 text-cyan-300 font-mono">
              {event.category}
            </span>
          )}
          {event.venue && (
            <span className="truncate text-zinc-400/90">📍 {event.venue}</span>
          )}
        </div>
      )}
    </div>
  );
});
