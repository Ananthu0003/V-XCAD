"use client";

import Link from "next/link";
import { useId } from "react";

export interface EventCardProps {
  id?: string;
  name: string;
  date: string;
  venue: string;
  tag?: string;
  category?: string;
  image?: string;
  registrationUrl?: string;
  prizePool?: string;
}

export function EventCard({
  id,
  name,
  date,
  venue,
  tag = "OPEN",
  registrationUrl = "/events",
  image,
}: EventCardProps) {
  const clipId = useId();
  const targetUrl = `/events/${id}`;

  return (
    <div
      className="block outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-lg relative group select-none cursor-pointer"
      style={{
        /* fluid: up to 320px, adapts to small mobile screens */
        width: "min(320px, 90vw)",
        aspectRatio: "320 / 450",
        filter: "drop-shadow(0px 10px 24px rgba(0,0,0,0.55))",
        transition: "filter 0.3s ease, transform 0.3s ease",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.filter =
          "drop-shadow(0px 14px 32px rgba(72,203,245,0.30))";
        (e.currentTarget as HTMLDivElement).style.transform =
          "translateY(-4px)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.filter =
          "drop-shadow(0px 10px 24px rgba(0,0,0,0.55))";
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(0px)";
      }}
    >
      {/* Background link over the card body to go to event details */}
      <Link
        href={targetUrl}
        aria-label={`View details for ${name}`}
        className="absolute inset-0 z-10 rounded-lg"
      />

      {/* Direct Register button link over the bottom button */}
      <Link
        href={targetUrl}
        rel="noopener noreferrer"
        aria-label={`Register for ${name}`}
        className="absolute z-20 rounded-lg transition-transform active:scale-95 cursor-pointer"
        style={{
          left: "27.2%",
          top: "80%",
          width: "61.25%",
          height: "10.2%",
        }}
        onClick={(e) => e.stopPropagation()}
      />

      <svg
        viewBox="0 0 320 450"
        width="100%"
        height="100%"
        xmlns="http://www.w3.org/2000/svg"
        style={{ userSelect: "none", pointerEvents: "none" }}
        aria-hidden="true"
      >
        <defs>
          <clipPath id={`eventCardImageClip-${clipId}`}>
            <rect x="85" y="230" width="200" height="115" rx="6" />
          </clipPath>
        </defs>

        {/* ── Deep Cyberpunk Background ── */}
        <rect width="320" height="450" rx="6" fill="#0e1520" />

        {/* ── Subtle Outer Frame Border ── */}
        <rect
          x="2"
          y="2"
          width="316"
          height="446"
          rx="6"
          fill="none"
          stroke="#1c2c40"
          strokeWidth="2"
        />

        {/* =============================================
            LEFT SIDEBAR — GOLDEN WIREFRAME STRIPES
            ============================================= */}
        <g
          stroke="#e2ad54"
          strokeWidth="1.5"
          fill="none"
          strokeLinejoin="round"
        >
          {/* Top Rounded Shape */}
          <path d="M 25,110 L 25,42.5 A 12.5,12.5 0 0,1 50,42.5 L 50,95 Z" />

          {/* Diagonal Parallelogram Cuts */}
          <path d="M 25,155 L 25,120 L 50,105 L 50,140 Z" />
          <path d="M 25,200 L 25,165 L 50,150 L 50,185 Z" />
          <path d="M 25,245 L 25,210 L 50,195 L 50,230 Z" />
          <path d="M 25,290 L 25,255 L 50,240 L 50,275 Z" />
          <path d="M 25,335 L 25,300 L 50,285 L 50,320 Z" />
          <path d="M 25,380 L 25,345 L 50,330 L 50,365 Z" />

          {/* Bottom Trapezoid Shape */}
          <path d="M 25,420 L 25,390 L 50,375 L 50,420 Z" />
        </g>

        {/* =============================================
            RIGHT SIDE — TOP INFO BOX (CYAN)
            ============================================= */}
        <g
          stroke="#48cbf5"
          strokeWidth="1.5"
          fill="none"
          strokeLinejoin="round"
        >
          {/* Main Bounding Box with Bottom-Left Notch Cutout */}
          <path
            d="
              M 85,30
              L 285,30
              A 10,10 0 0,1 295,40
              L 295,170
              A 10,10 0 0,1 285,180
              L 180,180
              L 160,150
              L 85,150
              A 10,10 0 0,1 75,140
              L 75,40
              A 10,10 0 0,1 85,30 Z
            "
          />

          {/* Pill shape on the right step */}
          <rect x="185" y="153" width="95" height="18" rx="9" />
        </g>

        {/* ── Event Name ── */}
        <foreignObject x="90" y="40" width="190" height="55">
          <div
            className="uppercase font-sans font-extrabold"
            style={{
              color: "#48cbf5",
              fontSize: "17px",
              letterSpacing: "0.5px",
              lineHeight: "1.15",
              wordWrap: "break-word",
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
            }}
          >
            {name}
          </div>
        </foreignObject>

        {/* ── Date ── */}
        <text
          x="90"
          y="100"
          fill="#e2ad54"
          fontFamily="system-ui, sans-serif"
          fontSize="13"
          fontWeight="500"
        >
          {date}
        </text>

        {/* ── Venue ── */}
        <foreignObject x="90" y="105" width="200" height="60">
          <div
            style={{
              fontFamily: "system-ui, sans-serif",
              fontSize: "13px",
              fontWeight: 500,
              color: "#e2ad54",
              wordBreak: "break-word",
            }}
          >
            {venue}
          </div>
        </foreignObject>

        {/* =============================================
            FLOATING COLOURED STATUS DOTS
            (sit in the notch cut from the cyan path)
            ============================================= */}
        <circle cx="85" cy="166" r="7" fill="#f25130" />
        <circle cx="108" cy="166" r="7" fill="#39e088" />
        <circle cx="131" cy="166" r="7" fill="#45ccfa" />

        {/* Tag text inside the pill */}
        {tag && (
          <text
            x="232"
            y="165"
            fill="#48cbf5"
            fontFamily="system-ui, sans-serif"
            fontSize="9"
            fontWeight="600"
            letterSpacing="1"
            textAnchor="middle"
          >
            {tag.toUpperCase().slice(0, 15)}
          </text>
        )}

        {/* =============================================
            BOTTOM REGISTRATION BOX (Full Image + Overlaid Controls)
            ============================================= */}
        {/* Full Box Background Image */}
        {image && (
          <foreignObject x="75" y="195" width="220" height="225">
            <div className="w-full h-full rounded-[10px] overflow-hidden relative bg-[#090e1a]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={image}
                alt={name}
                className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
              />
              {/* Contrast Vignettes for Overlapping Text & Buttons */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/20 to-black/85 pointer-events-none" />
            </div>
          </foreignObject>
        )}

        {/* Cyan Box Outline */}
        <rect
          x="75"
          y="195"
          width="220"
          height="225"
          rx="10"
          stroke="#48cbf5"
          strokeWidth="1.5"
          fill="none"
        />

        {/* ── REGISTER Button — Overlapping Bottom ── */}
        <rect
          x="87"
          y="360"
          width="196"
          height="46"
          rx="8"
          fill="#f4542e"
          fillOpacity="0.65"
          stroke="#ff7b63"
          strokeOpacity="0.75"
          strokeWidth="1.5"
        />
        <text
          x="185"
          y="389"
          fill="#ffffff"
          fontFamily="system-ui, sans-serif"
          fontSize="17"
          fontWeight="800"
          letterSpacing="1.5"
          textAnchor="middle"
        >
          VIEW DETAILS
        </text>
      </svg>
    </div>
  );
}
