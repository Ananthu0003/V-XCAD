"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Menu, X, Ticket } from "lucide-react";

interface NavItems {
  href: string;
  label: string;
}

const NAV_LINKS: NavItems[] = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/events", label: "Events" },
  { href: "/timeline", label: "Timeline" },
  { href: "/gallery", label: "Gallery" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((v) => !v);
  const closeMenu = () => setIsOpen(false);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const handler = (e: MediaQueryListEvent) => {
      if (e.matches) closeMenu();
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  return (
    <>
      <div className="fixed top-4 sm:top-6 left-1/2 -translate-x-1/2 w-full max-w-5xl px-4 z-50">
        <nav className="bg-[#0f172a]/60 backdrop-blur-xl border border-cyan-500/30 rounded-full pl-4 sm:pl-6 pr-2 sm:pr-3 py-2 flex items-center justify-between shadow-lg shadow-cyan-900/10">
          <Link
            href="/"
            className="flex items-center shrink-0"
            onClick={closeMenu}
          >
            <Image
              src="/assets/logos/alogo.svg"
              alt="Aerophilia Logo"
              width={36}
              height={36}
              className="h-8 sm:h-10 w-auto"
            />
          </Link>

          <ul className="hidden md:flex items-center gap-6 lg:gap-8">
            {NAV_LINKS.map((link: NavItems) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-cyan-400 font-semibold text-sm uppercase tracking-wider hover:text-white transition-colors"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <Link
              href="/participant"
              onClick={closeMenu}
              className="relative hidden md:inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full font-semibold text-xs sm:text-sm uppercase tracking-wider text-cyan-950 bg-cyan-400 hover:bg-cyan-300 transition-all duration-300 shadow-[0_0_15px_rgba(34,211,238,0.4)] hover:shadow-[0_0_25px_rgba(34,211,238,0.8)] overflow-hidden group shrink-0"
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/70 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />

              <Ticket className="w-4 h-4 relative z-10 text-cyan-950" />
              <span className="relative z-10 whitespace-nowrap">
                Attendee Pass
              </span>
            </Link>

            <button
              onClick={toggleMenu}
              className="md:hidden p-2 sm:p-2.5 text-cyan-400 hover:text-white bg-[#0f172a]/80 border border-cyan-500/20 rounded-full transition-colors focus:outline-none"
              aria-label="Toggle Menu"
              aria-expanded={isOpen}
            >
              {isOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </nav>
      </div>

      <div
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300 md:hidden ${
          isOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none"
        }`}
        onClick={closeMenu}
        aria-hidden="true"
      />

      <aside
        className={`fixed top-0 right-0 h-full w-72 max-w-[82vw] bg-[#0a1020]/98 backdrop-blur-2xl border-l border-cyan-500/20 pt-24 px-6 pb-8 flex flex-col justify-between z-40 transition-transform duration-300 ease-in-out md:hidden shadow-2xl ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
        aria-label="Mobile navigation"
      >
        <ul className="flex flex-col gap-6">
          {NAV_LINKS.map(({ href, label }) => (
            <li key={href}>
              <Link
                href={href}
                onClick={closeMenu}
                className="block text-cyan-400 font-semibold text-lg tracking-widest uppercase hover:text-white transition-colors"
              >
                {label}
              </Link>
              <div className="mt-2 h-px bg-cyan-500/10" />
            </li>
          ))}

          <li className="pt-2">
            <Link
              href="/participant"
              onClick={closeMenu}
              className="relative flex items-center justify-center gap-2 w-full py-3 rounded-full font-semibold text-sm uppercase tracking-wider text-cyan-950 bg-cyan-400 active:scale-[0.98] transition-transform overflow-hidden group shadow-[0_0_15px_rgba(34,211,238,0.4)]"
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/70 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
              <Ticket className="w-4 h-4 relative z-10 text-cyan-950" />
              <span className="relative z-10">Attendee Pass</span>
            </Link>
          </li>
        </ul>
      </aside>
    </>
  );
}
