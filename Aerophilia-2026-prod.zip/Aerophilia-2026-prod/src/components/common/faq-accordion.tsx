"use client";

import React from "react";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { FaqItemData } from "@/types/faq";

interface FaqAccordionProps {
  items: FaqItemData[];
  title?: string;
}

export const FaqAccordion: React.FC<FaqAccordionProps> = ({
  items,
  title = "FAQs",
}) => {
  if (!items || items.length === 0) return null;

  return (
    <section className="w-full max-w-5xl mx-auto">
      {title && (
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-left mb-6 text-cyan-300 tracking-[0.15em] font-sans uppercase">
          {title}
        </h2>
      )}

      <Accordion className="space-y-3">
        {items.map((faq) => (
          <AccordionItem
            key={faq.id}
            id={faq.id}
            className="border border-cyan-400/35 bg-[#0d1525] rounded-lg shadow-lg hover:border-cyan-400/55 transition-colors duration-200"
          >
            <AccordionTrigger
              className="text-white hover:bg-white/[0.02] hover:text-yellow-400 py-4 px-5 text-sm sm:text-base tracking-wider uppercase transition-colors duration-300"
              indicatorClassName="w-8 h-8 rounded-full border-2 border-cyan-400/60 text-cyan-400 hover:border-cyan-300"
            >
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-slate-400 text-sm sm:text-base leading-relaxed px-5 pb-5">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
};
