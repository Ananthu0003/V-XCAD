export function Loader() {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#030308] text-slate-100 overflow-hidden select-none font-sans">
      <div className="absolute h-[700px] w-[700px] rounded-full bg-indigo-950/40 blur-[160px] pointer-events-none" />
      <div className="absolute h-[500px] w-[500px] rounded-full bg-red-950/40 blur-[140px] pointer-events-none" />

      <div className="absolute inset-0 bg-black/60 pointer-events-none">
        <div className="absolute h-1 w-1 bg-white rounded-full top-1/4 left-1/5 animate-ping [animation-duration:3s]" />
        <div className="absolute h-1 w-1 bg-blue-300 rounded-full top-3/4 left-1/3 animate-ping [animation-duration:2.5s]" />
        <div className="absolute h-1.5 w-1.5 bg-red-400 rounded-full top-1/3 right-1/4 animate-ping [animation-duration:4s]" />
        <div className="absolute h-1 w-1 bg-white rounded-full bottom-1/4 right-1/3 animate-ping [animation-duration:2s]" />
      </div>

      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <svg
          className="w-[140vw] h-[140vh] max-w-none opacity-80 drop-shadow-[0_0_15px_rgba(255,255,255,0.6)] animate-[expandWebMesh_3s_cubic-bezier(0.16,1,0.3,1)_forwards]"
          viewBox="0 0 1000 1000"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g stroke="white" strokeWidth="1.8" strokeLinecap="round">
            <line
              x1="500"
              y1="500"
              x2="500"
              y2="20"
              strokeOpacity="0.8"
              strokeDasharray="4 4"
            />
            <line x1="500" y1="500" x2="839" y2="160" strokeOpacity="0.8" />
            <line
              x1="500"
              y1="500"
              x2="980"
              y2="500"
              strokeOpacity="0.8"
              strokeDasharray="6 6"
            />
            <line x1="500" y1="500" x2="839" y2="839" strokeOpacity="0.8" />
            <line
              x1="500"
              y1="500"
              x2="500"
              y2="980"
              strokeOpacity="0.8"
              strokeDasharray="4 4"
            />
            <line x1="500" y1="500" x2="160" y2="839" strokeOpacity="0.8" />
            <line
              x1="500"
              y1="500"
              x2="20"
              y2="500"
              strokeOpacity="0.8"
              strokeDasharray="6 6"
            />
            <line x1="500" y1="500" x2="160" y2="160" strokeOpacity="0.8" />

            <path
              d="M 500 420 Q 540 435 556 444 Q 570 470 580 500 Q 570 530 556 556 Q 530 570 500 580 Q 470 570 444 556 Q 430 530 420 500 Q 430 470 444 444 Q 470 430 500 420 Z"
              strokeOpacity="0.95"
            />
            <path
              d="M 500 320 Q 580 345 627 372 Q 655 435 680 500 Q 655 565 627 627 Q 565 655 500 680 Q 435 655 372 627 Q 345 565 320 500 Q 345 435 372 372 Q 435 345 500 320 Z"
              strokeOpacity="0.75"
            />
            <path
              d="M 500 210 Q 625 240 705 294 Q 760 400 790 500 Q 760 600 705 705 Q 600 760 500 790 Q 400 760 294 705 Q 240 600 210 500 Q 240 400 294 294 Q 400 240 500 210 Z"
              strokeOpacity="0.55"
            />
            <path
              d="M 500 90 Q 690 120 810 189 Q 880 340 910 500 Q 880 660 810 810 Q 660 880 500 910 Q 340 880 189 810 Q 120 660 90 500 Q 120 340 189 189 Q 340 120 500 90 Z"
              strokeOpacity="0.35"
            />

            <circle
              cx="556"
              cy="444"
              r="3"
              fill="white"
              className="animate-pulse"
            />
            <circle
              cx="444"
              cy="556"
              r="3"
              fill="white"
              className="animate-pulse"
            />
            <circle cx="627" cy="372" r="3.5" fill="#38bdf8" />
            <circle cx="372" cy="627" r="3.5" fill="#f43f5e" />
            <circle cx="705" cy="294" r="4" fill="white" />
          </g>
        </svg>
      </div>

      <div className="relative z-10 flex flex-col items-center animate-[spiderSlideIn_0.8s_ease-out_forwards]">
        <div className="absolute bottom-full h-screen w-[1.5px] bg-gradient-to-b from-transparent via-cyan-300 to-white opacity-80 shadow-[0_0_10px_#38bdf8]" />

        <div className="w-24 h-32 flex flex-col items-center bg-[#dc2626] rounded-b-3xl rounded-t-2xl relative border-2 border-cyan-400/50 shadow-[0_0_35px_rgba(56,189,248,0.4)] animate-[spaceFloat_4s_ease-in-out_infinite]">
          <div className="w-20 h-20 rounded-full bg-[#ef4444] border-2 border-red-500 -mt-2 flex items-center justify-center relative shadow-inner overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-900/40 via-transparent to-cyan-300/30 z-10 pointer-events-none" />

            <div className="absolute w-[24px] h-[14px] bg-gradient-to-br from-white to-cyan-200 rounded-t-sm rounded-b-[8px] rotate-[155deg] left-[6px] top-[8px] border-[2px] border-black shadow-[0_0_8px_#38bdf8]" />
            <div className="absolute w-[24px] h-[14px] bg-gradient-to-bl from-white to-cyan-200 rounded-t-sm rounded-b-[8px] rotate-[-155deg] right-[6px] top-[8px] border-[2px] border-black shadow-[0_0_8px_#38bdf8]" />
          </div>

          <div className="w-22 h-12 bg-[#991b1b] rounded-b-2xl mt-1 border-t-2 border-red-900 relative overflow-hidden flex flex-col items-center">
            <div className="w-5 h-6 bg-cyan-400/90 rounded-sm mt-2 shadow-[0_0_10px_#38bdf8]" />
          </div>
        </div>

        <div className="flex flex-col items-center gap-3 text-center mt-8">
          <h1 className="text-base font-black tracking-[0.3em] uppercase bg-gradient-to-r from-red-400 via-white to-cyan-300 bg-clip-text text-transparent drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)]">
            Aerophilia <span className="text-cyan-400">2026</span>
          </h1>

          <div className="h-1.5 w-52 overflow-hidden rounded-full bg-zinc-900 border border-cyan-400/40 shadow-inner">
            <div className="h-full w-full rounded-full bg-gradient-to-r from-red-600 via-cyan-400 to-indigo-500 animate-[progress3s_3s_linear_forwards]" />
          </div>

          <p className="text-[11px] font-mono tracking-widest uppercase text-cyan-200 drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
            Gateway to Tech Events Starts Here
            <span className="text-cyan-400 animate-pulse">...</span>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes expandWebMesh {
          0% {
            transform: scale(0) rotate(-90deg);
            opacity: 0;
          }
          50% {
            opacity: 0.9;
          }
          85% {
            transform: scale(1.05) rotate(2deg);
          }
          100% {
            transform: scale(1) rotate(0deg);
            opacity: 0.8;
          }
        }

        @keyframes progress3s {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(0%); }
        }

        @keyframes spiderSlideIn {
          0% { transform: translateY(-50px) scale(0.8); opacity: 0; }
          100% { transform: translateY(0) scale(1); opacity: 1; }
        }

        @keyframes spaceFloat {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-10px) rotate(2deg); }
        }
      `}</style>
    </div>
  );
}
