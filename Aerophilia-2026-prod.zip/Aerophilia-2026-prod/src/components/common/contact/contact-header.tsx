"use client";

import React from "react";

export const ContactHeader = () => {
  return (
    <div className="w-full flex justify-center items-center pt-8 pb-6 md:pt-12 md:pb-8">
      {/* Pill capsule */}
      <div className="inline-flex flex-col items-center px-12 py-3 sm:px-16 sm:py-4 rounded-full border border-cyan-400 bg-transparent shadow-[0_0_20px_rgba(34,211,238,0.08)]">
        <p className="text-[#f0c040] font-sans italic font-medium tracking-widest text-[11px] sm:text-xs">
          Let&apos;s Clear The Air
        </p>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-cyan-300 tracking-widest font-sans uppercase">
          CONTACT US
        </h1>
      </div>
    </div>
  );
};
