"use client";

export const LocationSection = () => {
  return (
    <section className="w-full max-w-4xl mx-auto px-4 sm:px-6">
      <div className="flex flex-col md:flex-row justify-center items-center gap-6 sm:gap-8 md:gap-16">
        {/* Left: Connected Google Map */}
        <div className="w-full sm:max-w-[350px] aspect-[7/4] rounded-2xl overflow-hidden border border-[#06B6D4] shadow-xl hover:shadow-cyan-900/15 hover:border-cyan-500/30 transition-all duration-300 shrink-0">
          {" "}
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.6432213358885!2d74.92212097358708!3d12.866305217181095!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba359a79303465f%3A0x44b942137435cf0f!2sCHALLENGERS!5e0!3m2!1sen!2sin!4v1786814909337!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen={true}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="grayscale contrast-[1.1] invert opacity-80 hover:opacity-100 hover:grayscale-0 hover:invert-0 transition-all duration-500"
          />
        </div>

        {/* Right: Address Details */}
        <div className="flex flex-col justify-center text-center md:text-left w-full max-w-xl px-2 sm:px-0">
          <h2 className="text-xl sm:text-2xl md:text-3xl text-cyan-300 font-semibold mb-2 sm:mb-4 tracking-wider font-sans">
            The Launchpad
          </h2>
          <div className="space-y-1 text-white font-sans text-sm sm:text-base md:text-lg tracking-wide leading-relaxed">
            <p>Sahyadri College of Engineering and Management,</p>
            <p>
              Adyar - 575007, <br />
              Karnataka
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
