"use client";

import React from "react";
import { Mail, Globe, Phone } from "lucide-react";
import Link from "next/link";

/* Custom Instagram SVG — lucide-react doesn't export one in this project's version */
const InstagramIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </svg>
);

/* ─── Premium Radar Card ─── */
const RadarCard = ({
  icon: Icon,
  text,
  label,
  href,
  index,
}: {
  icon: React.FC<{ className?: string }>;
  text: string;
  label: string;
  href: string;
  index: number;
}) => (
  <a
    href={href}
    target={href.startsWith("mailto:") ? undefined : "_blank"}
    rel="noopener noreferrer"
    className="group relative block rounded-xl overflow-hidden animate-[radarFadeUp_0.6s_ease-out_both] cursor-pointer"
    style={{ animationDelay: `${index * 120}ms` }}
  >
    {/* Animated glow border */}
    <div className="absolute -inset-[1px] rounded-xl bg-gradient-to-r from-cyan-500/40 via-cyan-300/20 to-cyan-500/40 opacity-40 group-hover:opacity-100 transition-opacity duration-500 blur-[0.5px]" />

    {/* Shimmer sweep overlay */}
    <div className="absolute inset-0 rounded-xl overflow-hidden pointer-events-none z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
      <div className="absolute inset-0 animate-[shimmerSweep_1.8s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-white/[0.04] to-transparent -translate-x-full" />
    </div>

    {/* Card body */}
    <div className="relative bg-[#0c1322]/90 backdrop-blur-sm rounded-xl px-5 py-4 sm:px-6 sm:py-5 flex items-center gap-4 transition-all duration-500 ease-out group-hover:bg-[#0f1a2e]/95 group-hover:-translate-y-[2px] group-hover:shadow-[0_8px_32px_-8px_rgba(6,182,212,0.15)]">
      {/* Accent line */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-0 bg-gradient-to-b from-[#f0c040] to-[#d4a020] rounded-r-full transition-all duration-500 ease-out group-hover:h-3/5" />

      {/* Icon with glow */}
      <div className="relative shrink-0">
        <Icon className="h-[18px] w-[18px] text-[#f0c040] shrink-0 transition-all duration-500 group-hover:scale-110 group-hover:drop-shadow-[0_0_6px_rgba(240,192,64,0.5)]" />
      </div>

      {/* Text content */}
      <div className="flex flex-col min-w-0">
        <span className="text-sm sm:text-[15px] text-slate-200 font-semibold tracking-wide truncate transition-colors duration-300 group-hover:text-white">
          {text}
        </span>
        <span className="text-[11px] sm:text-xs text-slate-400/80 font-medium tracking-wider uppercase mt-0.5 transition-colors duration-300 group-hover:text-[#f0c040]/60">
          {label}
        </span>
      </div>

      {/* Arrow indicator */}
      <svg
        className="ml-auto h-4 w-4 text-slate-600 shrink-0 transition-all duration-500 group-hover:text-cyan-400 group-hover:translate-x-0.5"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
      >
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
      </svg>
    </div>
  </a>
);

/* ─── Crew member data ─── */
const crewMembers = [
  {
    name: "Adhithi Gatty",
    number: "+91 831 058 5243",
    role: "Head",
    rawNumber: "+918310585243",
  },
  {
    name: "Tanmay",
    number: "+91 832 900 1204",
    role: "Head",
    rawNumber: "+918329001204",
  },
  {
    name: "Saalim",
    number: "+91 890 417 0961",
    role: "Co-Head",
    rawNumber: "+918904170961",
  },
];

/* ─── Premium Crew Card ─── */
const CrewCard = ({
  name,
  number,
  role,
  index,
  rawNumber,
}: {
  name: string;
  number: string;
  role: string;
  index: number;
  rawNumber: string;
}) => (
  <div
    className="group relative rounded-xl overflow-hidden animate-[crewFadeUp_0.6s_ease-out_both]"
    style={{ animationDelay: `${index * 120}ms` }}
  >
    {/* Animated glow border */}
    <div className="absolute -inset-[1px] rounded-xl bg-gradient-to-r from-cyan-500/40 via-cyan-300/20 to-cyan-500/40 opacity-50 group-hover:opacity-100 transition-opacity duration-500 blur-[0.5px]" />

    {/* Shimmer sweep overlay */}
    <div className="absolute inset-0 rounded-xl overflow-hidden pointer-events-none z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
      <div className="absolute inset-0 animate-[shimmerSweep_1.8s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-white/[0.04] to-transparent -translate-x-full" />
    </div>

    {/* Card body */}
    <div className="relative bg-[#0c1322]/90 backdrop-blur-sm rounded-xl px-5 py-4 sm:px-6 sm:py-5 flex items-center gap-4 transition-all duration-500 ease-out group-hover:bg-[#0f1a2e]/95 group-hover:-translate-y-[2px] group-hover:shadow-[0_8px_32px_-8px_rgba(6,182,212,0.15)]">
      {/* Accent line */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-0 bg-gradient-to-b from-cyan-400 to-cyan-600 rounded-r-full transition-all duration-500 ease-out group-hover:h-3/5" />

      {/* Phone icon with glow */}
      <div className="relative shrink-0">
        <Phone className="h-[18px] w-[18px] text-cyan-400 fill-current transition-all duration-500 group-hover:text-cyan-300 group-hover:scale-110 group-hover:drop-shadow-[0_0_6px_rgba(34,211,238,0.5)]" />
      </div>

      {/* Text content */}
      <div className="flex flex-col min-w-0">
        <span className="text-sm sm:text-[15px] text-slate-200 font-semibold tracking-wide truncate transition-colors duration-300 group-hover:text-white">
          {name}
        </span>
        <span className="text-[11px] sm:text-xs text-slate-400/80 font-medium tracking-wider uppercase mt-0.5 transition-colors duration-300 group-hover:text-cyan-400/70">
          {role}
        </span>
      </div>

      {/* Number on the right */}
      <Link
        href={`tel:${rawNumber}`}
        className="ml-auto text-[12px] sm:text-[13px] text-[#f0c040]/80 font-mono tracking-wide transition-colors duration-300 group-hover:text-[#f0c040] shrink-0"
      >
        {number}
      </Link>
    </div>
  </div>
);

export const ContactCards = () => {
  return (
    <div className="w-full max-w-5xl mx-auto">
      {/* Keyframes for card animations */}
      <style>{`
        @keyframes crewFadeUp {
          from {
            opacity: 0;
            transform: translateY(16px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes radarFadeUp {
          from {
            opacity: 0;
            transform: translateY(12px) scale(0.98);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        @keyframes shimmerSweep {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {/* Left Section — On Your Radar */}
        <div className="flex flex-col">
          <div className="text-center mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-cyan-300 tracking-wider font-sans">
              On Your Radar
            </h2>
          </div>
          <div className="space-y-3">
            <RadarCard
              icon={Mail}
              text="challengers@sahyadri.edu.in"
              label="Email"
              href="mailto:challengers@sahyadri.edu.in"
              index={0}
            />
            <RadarCard
              icon={Globe}
              text="challengers.sahyadri.edu.in"
              label="Website"
              href="https://challengers.sahyadri.edu.in"
              index={1}
            />
            <RadarCard
              icon={InstagramIcon}
              text="challengers.sahyadri"
              label="Instagram"
              href="https://www.instagram.com/challengers.sahyadri"
              index={2}
            />
          </div>
        </div>

        {/* Right Section — Contact the Crew */}
        <div className="flex flex-col">
          <div className="text-center mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-cyan-300 tracking-wider font-sans">
              Contact the Crew
            </h2>
          </div>
          <div className="space-y-3">
            {crewMembers.map((member, i) => (
              <CrewCard
                key={member.name}
                name={member.name}
                number={member.number}
                role={member.role}
                index={i}
                rawNumber={member.rawNumber}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
