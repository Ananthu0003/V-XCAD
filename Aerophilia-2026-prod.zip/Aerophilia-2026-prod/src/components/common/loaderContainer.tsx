"use client";

import { useState, useEffect, Suspense, ReactNode } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { Loader } from "./Loader";

function AerophiliaLoader({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    setIsLoading(true);

    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, [pathname, searchParams]);

  return (
    <>
      {isLoading && <Loader />}
      <div style={{ display: isLoading ? "none" : "block" }}>{children}</div>
    </>
  );
}

export default function LoaderComponent({ children }: { children: ReactNode }) {
  return (
    <>
      <Suspense fallback={<Loader />}>
        <AerophiliaLoader>{children}</AerophiliaLoader>
      </Suspense>
    </>
  );
}
