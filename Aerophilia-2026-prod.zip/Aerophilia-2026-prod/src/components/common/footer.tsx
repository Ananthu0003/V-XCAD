"use client";

import Image from "next/image";
import Link from "next/link";
import {
  Mail,
  Phone,
  MapPin,
  ChevronRight,
  ArrowUp,
  Link as LinkIcon,
} from "lucide-react";

interface FooterElements {
  name: string;
  href: string;
}

const elements: FooterElements[] = [
  { name: "Home", href: "/" },
  { name: "About", href: "/about" },
  { name: "Events", href: "/events" },
  { name: "Timeline", href: "/timeline" },
  { name: "Gallery", href: "/gallery " },
  { name: "Contact", href: "/contact" },
  { name: "Team", href: "/team" },
];

const InstagramIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </svg>
);

const FacebookIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
  </svg>
);

const YoutubeIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
    <path d="m10 15 5-3-5-3z" />
  </svg>
);

const LinkedinIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
    <rect width="4" height="12" x="2" y="9" />
    <circle cx="4" cy="4" r="2" />
  </svg>
);

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#030712]/80 backdrop-blur-xl text-white pt-16 pb-8 border-t border-cyan-500/20">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-0 mb-16">
          {/* Column 1: Info */}
          <div className="space-y-6 md:pr-8">
            <Image
              src="/assets/logos/aerophilia-logo.svg"
              alt="Aerophilia Logo"
              width={200}
              height={50}
              className="h-10 w-auto"
            />
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              Where innovation takes flight. Join us for an immersive experience
              in technology, aeromodelling, and endless possibilities.
            </p>
            <div className="space-y-4 pt-4">
              <div className="flex items-center gap-4 text-gray-300">
                <Mail className="w-5 h-5 text-gray-400 stroke-[1.5]" />
                <a
                  href="mailto:challengers@sahyadri.edu.in"
                  className="text-sm hover:text-white transition-colors"
                >
                  challengers@sahyadri.edu.in
                </a>
              </div>
              <div className="flex items-center gap-4 text-gray-300">
                <Phone className="w-5 h-5 text-gray-400 stroke-[1.5]" />
                <a
                  href="tel:+918310585243"
                  className="text-sm hover:text-white transition-colors"
                >
                  +91 83105 85243 - Adhithi Gatty
                </a>
              </div>
              <div className="flex items-center gap-4 text-gray-300">
                <Phone className="w-5 h-5 text-gray-400 stroke-[1.5]" />
                <a
                  href="tel:+918329001204"
                  className="text-sm hover:text-white transition-colors"
                >
                  +91 83290 01204 - Tanmay
                </a>
              </div>
              <div className="flex items-start gap-4 text-gray-300 pt-2">
                <MapPin className="w-5 h-5 text-gray-400 shrink-0 mt-0.5 stroke-[1.5]" />
                <p className="text-sm leading-relaxed">
                  Sahyadri Campus,
                  <br />
                  Adyar - 575007,
                  <br />
                  Karnataka
                </p>
              </div>
            </div>
          </div>

          {/* Column 2: Links */}
          <div className="md:border-l md:border-r border-white/10 md:px-12 flex flex-col md:items-center">
            <div className="w-full max-w-37.5">
              <h3 className="text-xl font-semibold mb-8 tracking-widest uppercase">
                Links
              </h3>
              <ul className="space-y-5">
                {elements.map((link: FooterElements) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors group uppercase"
                    >
                      <ChevronRight className="w-4 h-4 stroke-3 group-hover:translate-x-1 transition-transform" />
                      <span className="text-sm font-medium tracking-wider">
                        {link.name}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Column 3: Socials */}
          <div className="md:pl-16 flex flex-col md:items-start">
            <div>
              <h3 className="text-xl font-semibold mb-8 tracking-widest uppercase">
                Socials
              </h3>
              <ul className="space-y-5">
                {[
                  {
                    name: "Website",
                    icon: LinkIcon,
                    href: "https://challengers.sahyadri.edu.in",
                  },
                  {
                    name: "Instagram",
                    icon: InstagramIcon,
                    href: "https://www.instagram.com/aerophilia_2026/?hl=en",
                  },
                  {
                    name: "Facebook",
                    icon: FacebookIcon,
                    href: "https://www.facebook.com/challengers.sahyadri",
                  },
                  {
                    name: "YouTube",
                    icon: YoutubeIcon,
                    href: "https://www.youtube.com/@teamchallengers7989",
                  },
                  {
                    name: "LinkedIn",
                    icon: LinkedinIcon,
                    href: "https://www.linkedin.com/company/team-challengers",
                  },
                ].map((social) => {
                  const Icon = social.icon;
                  return (
                    <li key={social.name}>
                      <a
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-4 text-gray-300 hover:text-white transition-colors group"
                      >
                        <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center group-hover:border-white/30 transition-colors">
                          <Icon className="w-4 h-4 group-hover:scale-110 transition-transform stroke-[1.5]" />
                        </div>
                        <span className="text-sm tracking-wide">
                          {social.name}
                        </span>
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 pt-10 flex flex-col items-center relative">
          <div className="text-center mb-8">
            <p className="text-xs text-gray-500 mb-3 tracking-widest uppercase">
              Organized by
            </p>
            <Image
              src="/assets/logos/challengers-logo.webp"
              alt="Challengers Logo"
              width={200}
              height={50}
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              className="h-12 w-auto opacity-90 hover:opacity-100 transition-opacity mx-auto"
            />
          </div>

          <div className="text-center space-y-3 w-full pb-2">
            <div className="flex items-center justify-center gap-3 text-xs text-gray-500 tracking-wide">
              <Link
                href="/terms"
                className="hover:text-white transition-colors"
              >
                Terms and Conditions
              </Link>
              <span>|</span>
              <Link
                href="/privacy"
                className="hover:text-white transition-colors"
              >
                Privacy Policy
              </Link>
            </div>
            <p className="text-sm text-gray-400 tracking-wide">
              &copy; {new Date().getFullYear()} AEROPHILIA. All rights reserved.
            </p>
          </div>

          <button
            onClick={scrollToTop}
            className="absolute right-0 bottom-2 p-3 rounded-full border border-white/20 text-gray-300 hover:text-white hover:border-white transition-all hover:bg-white/10 hidden md:block"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5 stroke-[1.5]" />
          </button>
        </div>
      </div>
    </footer>
  );
}
