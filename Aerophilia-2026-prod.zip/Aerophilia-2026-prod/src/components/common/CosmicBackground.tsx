"use client";

import React, { useEffect, useRef } from "react";

export interface CosmicBackgroundProps {
  className?: string;
  showPlanet?: boolean;
  showShootingStars?: boolean;
  starDensityMultiplier?: number;
}

const STATIC_STARS = Array.from({ length: 45 }, (_, i) => {
  const seed1 = (i * 137.5) % 100;
  const seed2 = ((i + 1) * 263.3) % 100;
  const seed3 = (i * 47.9) % 10;
  return {
    id: i,
    top: `${seed1.toFixed(2)}%`,
    left: `${seed2.toFixed(2)}%`,
    size: Number((2.0 + (seed3 / 10) * 3.5).toFixed(2)),
    delay: `${((i * 0.35) % 5).toFixed(1)}s`,
    duration: `${(3.5 + ((i * 0.5) % 4)).toFixed(1)}s`,
    opacity: Number((0.35 + (seed3 / 10) * 0.55).toFixed(2)),
  };
});

/* ─────────────────────────────────────────────────────────────────────────────
   1. High-Fidelity Ringed Gas Giant Planet (Aero-Chronos) — GPU Optimized
───────────────────────────────────────────────────────────────────────────── */
const RingedGasGiantPlanet = React.memo(function RingedGasGiantPlanet({
  className = "",
  style = {},
}: {
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`relative pointer-events-none select-none ${className}`}
      style={style}
      aria-hidden="true"
    >
      <svg viewBox="0 0 200 160" className="w-full h-auto overflow-visible">
        <defs>
          {/* 3D Volumetric Sphere Lighting */}
          <radialGradient id="gasGiantBody" cx="30%" cy="26%" r="68%">
            <stop offset="0%" stopColor="#e0f2fe" />
            <stop offset="16%" stopColor="#7dd3fc" />
            <stop offset="38%" stopColor="#0284c7" />
            <stop offset="62%" stopColor="#0369a1" />
            <stop offset="80%" stopColor="#082f49" />
            <stop offset="94%" stopColor="#021124" />
            <stop offset="100%" stopColor="#010610" />
          </radialGradient>

          {/* Atmospheric Storm Bands Texture */}
          <linearGradient id="cloudBands" x1="0" y1="0" x2="0.3" y2="1">
            <stop offset="0%" stopColor="#bae6fd" stopOpacity="0.45" />
            <stop offset="12%" stopColor="#38bdf8" stopOpacity="0.12" />
            <stop offset="26%" stopColor="#0284c7" stopOpacity="0.4" />
            <stop offset="38%" stopColor="#7dd3fc" stopOpacity="0.18" />
            <stop offset="50%" stopColor="#0369a1" stopOpacity="0.35" />
            <stop offset="64%" stopColor="#38bdf8" stopOpacity="0.22" />
            <stop offset="78%" stopColor="#0c4a6e" stopOpacity="0.5" />
            <stop offset="90%" stopColor="#7dd3fc" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#082f49" stopOpacity="0.55" />
          </linearGradient>

          {/* Night Terminator Shadow */}
          <radialGradient id="sphereTerminator" cx="30%" cy="26%" r="65%">
            <stop offset="42%" stopColor="#000000" stopOpacity="0" />
            <stop offset="68%" stopColor="#010917" stopOpacity="0.65" />
            <stop offset="88%" stopColor="#010612" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#000208" stopOpacity="1" />
          </radialGradient>

          {/* Planetary Rings Texture with Cassini Division */}
          <linearGradient id="ringTexture" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#bae6fd" stopOpacity="0.8" />
            <stop offset="18%" stopColor="#38bdf8" stopOpacity="0.65" />
            <stop offset="32%" stopColor="#0284c7" stopOpacity="0.2" />
            <stop offset="38%" stopColor="#0369a1" stopOpacity="0.75" />
            <stop offset="44%" stopColor="#38bdf8" stopOpacity="0.9" />
            <stop offset="48%" stopColor="#000000" stopOpacity="0.05" />
            <stop offset="52%" stopColor="#000000" stopOpacity="0.05" />
            <stop offset="56%" stopColor="#7dd3fc" stopOpacity="0.75" />
            <stop offset="70%" stopColor="#0284c7" stopOpacity="0.55" />
            <stop offset="85%" stopColor="#38bdf8" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#e0f2fe" stopOpacity="0.85" />
          </linearGradient>

          {/* Planet Shadow onto Front Rings */}
          <radialGradient id="ringShadowCast" cx="50%" cy="40%" r="50%">
            <stop offset="0%" stopColor="#010612" stopOpacity="0.95" />
            <stop offset="60%" stopColor="#010612" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#010612" stopOpacity="0" />
          </radialGradient>

          {/* Back Ring Clipping Path */}
          <clipPath id="backRingClip">
            <rect x="0" y="0" width="200" height="74" />
          </clipPath>

          {/* Front Ring Clipping Path */}
          <clipPath id="frontRingClip">
            <rect x="0" y="74" width="200" height="86" />
          </clipPath>
        </defs>

        {/* 1. Atmospheric Back Corona Glow (Pure Gradient - No Expensive Gaussian Filter) */}
        <circle cx="100" cy="74" r="48" fill="#38bdf8" opacity="0.2" />

        {/* 2. Back Half of Rings (Behind Planet) */}
        <g clipPath="url(#backRingClip)">
          <g transform="rotate(-18 100 74)">
            <ellipse
              cx="100"
              cy="74"
              rx="88"
              ry="24"
              fill="none"
              stroke="url(#ringTexture)"
              strokeWidth="18"
              opacity="0.85"
            />
            <ellipse
              cx="100"
              cy="74"
              rx="72"
              ry="19"
              fill="none"
              stroke="#bae6fd"
              strokeWidth="2.5"
              opacity="0.9"
            />
            <ellipse
              cx="100"
              cy="74"
              rx="96"
              ry="26"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1"
              opacity="0.6"
            />
          </g>
        </g>

        {/* 3. Planet Sphere Body */}
        <g>
          <circle cx="100" cy="74" r="38" fill="url(#gasGiantBody)" />
          <circle
            cx="100"
            cy="74"
            r="38"
            fill="url(#cloudBands)"
            opacity="0.6"
          />
          <circle cx="100" cy="74" r="38" fill="url(#sphereTerminator)" />
          <circle
            cx="100"
            cy="74"
            r="38"
            fill="none"
            stroke="#bae6fd"
            strokeWidth="1.2"
            opacity="0.75"
          />
        </g>

        {/* 4. Front Half of Rings (In Front of Planet) */}
        <g clipPath="url(#frontRingClip)">
          <g transform="rotate(-18 100 74)">
            <ellipse
              cx="100"
              cy="74"
              rx="88"
              ry="24"
              fill="none"
              stroke="url(#ringTexture)"
              strokeWidth="18"
              opacity="0.95"
            />
            <ellipse
              cx="100"
              cy="74"
              rx="72"
              ry="19"
              fill="none"
              stroke="#bae6fd"
              strokeWidth="2.5"
              opacity="0.95"
            />
            <ellipse
              cx="100"
              cy="74"
              rx="96"
              ry="26"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1"
              opacity="0.7"
            />
            <ellipse
              cx="100"
              cy="74"
              rx="36"
              ry="10"
              fill="url(#ringShadowCast)"
              transform="translate(18, 0)"
              opacity="0.85"
            />
          </g>
        </g>
      </svg>
    </div>
  );
});

/* ─────────────────────────────────────────────────────────────────────────────
   2. High-Fidelity Terrestrial Planet with Moon (Ares-Nova) — GPU Optimized
───────────────────────────────────────────────────────────────────────────── */
const TerrestrialPlanetWithMoon = React.memo(
  function TerrestrialPlanetWithMoon({
    className = "",
    style = {},
  }: {
    className?: string;
    style?: React.CSSProperties;
  }) {
    return (
      <div
        className={`relative pointer-events-none select-none ${className}`}
        style={style}
        aria-hidden="true"
      >
        <svg viewBox="0 0 140 140" className="w-full h-auto overflow-visible">
          <defs>
            {/* Terrestrial 3D Shading */}
            <radialGradient id="marsBody" cx="30%" cy="26%" r="70%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="18%" stopColor="#fbbf24" />
              <stop offset="40%" stopColor="#f97316" />
              <stop offset="65%" stopColor="#c2410c" />
              <stop offset="82%" stopColor="#7c2d12" />
              <stop offset="96%" stopColor="#270701" />
              <stop offset="100%" stopColor="#0c0200" />
            </radialGradient>

            {/* Terrain & Crater Contours */}
            <linearGradient id="marsCraters" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.4" />
              <stop offset="30%" stopColor="#7c2d12" stopOpacity="0.6" />
              <stop offset="60%" stopColor="#431407" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#270701" stopOpacity="0.8" />
            </linearGradient>

            {/* Moon 3D Shading */}
            <radialGradient id="moonGrad" cx="35%" cy="30%" r="65%">
              <stop offset="0%" stopColor="#f8fafc" />
              <stop offset="35%" stopColor="#cbd5e1" />
              <stop offset="70%" stopColor="#64748b" />
              <stop offset="100%" stopColor="#0f172a" />
            </radialGradient>

            <radialGradient id="marsTerminator" cx="30%" cy="26%" r="68%">
              <stop offset="38%" stopColor="#000000" stopOpacity="0" />
              <stop offset="68%" stopColor="#1a0400" stopOpacity="0.6" />
              <stop offset="90%" stopColor="#0d0200" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#000000" stopOpacity="1" />
            </radialGradient>
          </defs>

          {/* Orbit Path Ellipse */}
          <ellipse
            cx="65"
            cy="65"
            rx="52"
            ry="22"
            fill="none"
            stroke="rgba(245,158,11,0.2)"
            strokeWidth="0.8"
            strokeDasharray="3 4"
            transform="rotate(-25 65 65)"
          />

          {/* Atmospheric Corona */}
          <circle cx="65" cy="65" r="30" fill="#f59e0b" opacity="0.15" />

          {/* Planet Sphere */}
          <g>
            <circle cx="65" cy="65" r="25" fill="url(#marsBody)" />
            <path
              d="M52 56 Q57 52 64 54 Q72 58 78 52 Q82 60 74 66 Q66 70 58 64 Z"
              fill="url(#marsCraters)"
              opacity="0.55"
            />
            <path
              d="M60 72 Q68 76 74 72 Q80 78 72 82 Q64 82 60 76 Z"
              fill="url(#marsCraters)"
              opacity="0.45"
            />
            <circle cx="56" cy="50" r="3.5" fill="#7c2d12" opacity="0.5" />
            <circle cx="72" cy="74" r="2.5" fill="#7c2d12" opacity="0.5" />
            <circle cx="65" cy="65" r="25" fill="url(#marsTerminator)" />
            <circle
              cx="65"
              cy="65"
              r="25"
              fill="none"
              stroke="#fef08a"
              strokeWidth="0.9"
              opacity="0.8"
            />
          </g>

          {/* Orbiting Moon with floating animation */}
          <g className="animate-orbit-moon">
            <circle cx="112" cy="46" r="6" fill="url(#moonGrad)" />
            <circle
              cx="112"
              cy="46"
              r="6"
              fill="none"
              stroke="#f1f5f9"
              strokeWidth="0.5"
              opacity="0.7"
            />
          </g>
        </svg>
      </div>
    );
  },
);

/* ─────────────────────────────────────────────────────────────────────────────
   3. High-Fidelity Ice Giant Planet (Gliese-Ice) — GPU Optimized
───────────────────────────────────────────────────────────────────────────── */
const IceGiantPlanet = React.memo(function IceGiantPlanet({
  className = "",
  style = {},
}: {
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`relative pointer-events-none select-none ${className}`}
      style={style}
      aria-hidden="true"
    >
      <svg viewBox="0 0 100 100" className="w-full h-auto overflow-visible">
        <defs>
          <radialGradient id="iceGiantGrad" cx="32%" cy="28%" r="68%">
            <stop offset="0%" stopColor="#f5d0fe" />
            <stop offset="22%" stopColor="#c084fc" />
            <stop offset="45%" stopColor="#7c3aed" />
            <stop offset="70%" stopColor="#4338ca" />
            <stop offset="88%" stopColor="#1e1b4b" />
            <stop offset="100%" stopColor="#050314" />
          </radialGradient>
          <radialGradient id="iceTerminator" cx="32%" cy="28%" r="68%">
            <stop offset="40%" stopColor="#000000" stopOpacity="0" />
            <stop offset="75%" stopColor="#07021a" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#000000" stopOpacity="1" />
          </radialGradient>
        </defs>

        {/* Aurora polar glow */}
        <ellipse
          cx="44"
          cy="36"
          rx="9"
          ry="3.5"
          fill="#34d399"
          opacity="0.6"
          transform="rotate(-15 44 36)"
        />

        {/* Sphere */}
        <circle cx="50" cy="50" r="18" fill="url(#iceGiantGrad)" />
        <circle cx="50" cy="50" r="18" fill="url(#iceTerminator)" />
        <circle
          cx="50"
          cy="50"
          r="18"
          fill="none"
          stroke="#e879f9"
          strokeWidth="0.8"
          opacity="0.75"
        />

        {/* Subtle diagonal ring */}
        <ellipse
          cx="50"
          cy="50"
          rx="28"
          ry="6"
          fill="none"
          stroke="rgba(192,132,252,0.45)"
          strokeWidth="1.2"
          transform="rotate(35 50 50)"
        />
      </svg>
    </div>
  );
});

/* ─────────────────────────────────────────────────────────────────────────────
   4. Multi-Track Shooting Stars (Hardware-Accelerated Meteors)
───────────────────────────────────────────────────────────────────────────── */
const ShootingStarsLayer = React.memo(function ShootingStarsLayer() {
  return (
    <div
      className="hidden md:block absolute inset-0 overflow-hidden pointer-events-none z-0"
      aria-hidden="true"
    >
      {/* Meteor 1: Cyan-White Streak traversing top-right to mid-left */}
      <div
        className="absolute top-[8%] right-[10%] animate-meteor-fast"
        style={{ animationDelay: "0.2s" }}
      >
        <div className="relative flex items-center">
          <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_8px_#ffffff,0_0_14px_#38bdf8]" />
          <div
            className="h-[2px] w-36 sm:w-52"
            style={{
              background:
                "linear-gradient(90deg, #ffffff 0%, rgba(56,189,248,0.9) 25%, rgba(99,102,241,0.4) 65%, transparent 100%)",
            }}
          />
        </div>
      </div>

      {/* Meteor 2: Violet-Cyan Streak across mid-upper sky */}
      <div
        className="absolute top-[28%] right-[25%] animate-meteor-long"
        style={{ animationDelay: "3.4s" }}
      >
        <div className="relative flex items-center">
          <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_8px_#ffffff,0_0_14px_#c084fc]" />
          <div
            className="h-[1.5px] w-40 sm:w-56"
            style={{
              background:
                "linear-gradient(90deg, #ffffff 0%, rgba(192,132,252,0.9) 25%, rgba(56,189,248,0.4) 65%, transparent 100%)",
            }}
          />
        </div>
      </div>

      {/* Meteor 3: Golden-Amber Fireball Streak */}
      <div
        className="absolute top-[52%] right-[15%] animate-meteor-fast"
        style={{ animationDelay: "5.8s" }}
      >
        <div className="relative flex items-center">
          <div className="w-2 h-2 rounded-full bg-amber-100 shadow-[0_0_8px_#ffffff,0_0_14px_#f59e0b]" />
          <div
            className="h-[2px] w-32 sm:w-44"
            style={{
              background:
                "linear-gradient(90deg, #ffffff 0%, rgba(251,191,36,0.9) 30%, rgba(249,115,22,0.4) 70%, transparent 100%)",
            }}
          />
        </div>
      </div>

      {/* Meteor 4: High-speed White Flash Meteor */}
      <div
        className="absolute top-[14%] right-[55%] animate-meteor-long"
        style={{ animationDelay: "8.2s" }}
      >
        <div className="relative flex items-center">
          <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_6px_#ffffff,0_0_10px_#38bdf8]" />
          <div
            className="h-[1.5px] w-24 sm:w-36"
            style={{
              background:
                "linear-gradient(90deg, #ffffff 0%, rgba(186,230,253,0.8) 35%, transparent 100%)",
            }}
          />
        </div>
      </div>
    </div>
  );
});

/* ─────────────────────────────────────────────────────────────────────────────
   CosmicBackground — Ultra-Optimized Canvas Starfield, Planets & Meteors
───────────────────────────────────────────────────────────────────────────── */
export function CosmicBackground({
  className = "",
  showPlanet = true,
  showShootingStars = true,
  starDensityMultiplier = 1,
}: CosmicBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bhCanvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const bhRafRef = useRef<number>(0);

  const prefersReducedMotion = React.useSyncExternalStore(
    (callback) => {
      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      mq.addEventListener("change", callback);
      return () => mq.removeEventListener("change", callback);
    },
    () =>
      typeof window !== "undefined"
        ? window.matchMedia("(prefers-reduced-motion: reduce)").matches
        : false,
    () => false,
  );

  const isMobile = React.useSyncExternalStore(
    (callback) => {
      const mq = window.matchMedia("(max-width: 768px)");
      mq.addEventListener("change", callback);
      return () => mq.removeEventListener("change", callback);
    },
    () =>
      typeof window !== "undefined"
        ? window.matchMedia("(max-width: 768px)").matches
        : false,
    () => false,
  );

  // Parallax using CSS Variables without triggering React component re-renders
  useEffect(() => {
    if (isMobile || prefersReducedMotion || !containerRef.current) return;

    let ticking = false;
    const onMove = (e: MouseEvent) => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          if (containerRef.current) {
            const mx = ((e.clientX / window.innerWidth - 0.5) * 2).toFixed(3);
            const my = ((e.clientY / window.innerHeight - 0.5) * 2).toFixed(3);
            containerRef.current.style.setProperty("--mouse-x", mx);
            containerRef.current.style.setProperty("--mouse-y", my);
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
    };
  }, [isMobile, prefersReducedMotion]);

  /* ── Ultra High-Performance Canvas Starfield (Zero shadowBlur overhead) ── */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    interface GalaxyStar {
      x: number;
      y: number;
      vx: number;
      vy: number;
      r: number;
      baseR: number;
      hue: number;
      sat: number;
      alpha: number;
      flicker1: number;
      flicker2: number;
      fPhase1: number;
      fPhase2: number;
      isPulsar: boolean;
      flareAngle: number;
      flareSpeed: number;
      layer: number;
    }

    // Adaptive star count: 750 on mobile, 1800 on desktop
    const COUNT = isMobile
      ? Math.round(400 * starDensityMultiplier)
      : Math.round(1300 * starDensityMultiplier);

    let stars: GalaxyStar[] = [];
    let W = 0,
      H = 0;

    const HUES = [185, 195, 205, 215, 225, 270, 285, 45, 0];
    const SATS = [75, 65, 70, 55, 40, 60, 50, 80, 0];

    function build(w: number, h: number) {
      stars = [];
      for (let i = 0; i < COUNT; i++) {
        const hIdx = Math.floor(Math.random() * HUES.length);
        const layer = Math.random() < 0.65 ? 0 : Math.random() < 0.88 ? 1 : 2;
        const isPulsar = layer === 2 && Math.random() < 0.09;
        const baseR =
          layer === 0
            ? 0.4 + Math.random() * 0.5
            : layer === 1
              ? 0.8 + Math.random() * 0.6
              : 1.35 + Math.random() * 1.3;

        stars.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * (0.02 + layer * 0.035),
          vy: (Math.random() - 0.5) * (0.02 + layer * 0.035),
          r: baseR,
          baseR,
          hue: HUES[hIdx],
          sat: SATS[hIdx],
          alpha: 0.3 + Math.random() * 0.7,
          flicker1: 0.015 + Math.random() * 0.03,
          flicker2: 0.006 + Math.random() * 0.015,
          fPhase1: Math.random() * Math.PI * 2,
          fPhase2: Math.random() * Math.PI * 2,
          isPulsar,
          flareAngle: Math.random() * Math.PI,
          flareSpeed: (Math.random() - 0.5) * 0.006,
          layer,
        });
      }
    }

    function resize() {
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = Math.ceil(W * dpr);
      canvas.height = Math.ceil(H * dpr);
      canvas.style.width = W + "px";
      canvas.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      build(W, H);
    }
    resize();
    window.addEventListener("resize", resize);

    let tick = 0;
    let lastTime = 0;
    let isVisible = true;

    const handleVisibility = () => {
      isVisible = !document.hidden;
      if (isVisible) {
        rafRef.current = requestAnimationFrame(loop);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    function loop(time: number = 0) {
      if (!isVisible) return;
      rafRef.current = requestAnimationFrame(loop);

      // Frame rate governor: max 60fps for background star canvas
      if (time - lastTime < 16) return;
      lastTime = time;

      tick++;

      ctx.fillStyle = "rgba(3,7,18,0.28)";
      ctx.fillRect(0, 0, W, H);

      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];

        s.x += s.vx;
        s.y += s.vy;
        if (s.x < -4) s.x = W + 4;
        if (s.x > W + 4) s.x = -4;
        if (s.y < -4) s.y = H + 4;
        if (s.y > H + 4) s.y = -4;

        const harmonic1 = Math.sin(tick * s.flicker1 + s.fPhase1);
        const harmonic2 = Math.cos(tick * s.flicker2 + s.fPhase2);
        const twinkle = 0.52 + 0.32 * harmonic1 + 0.16 * harmonic2;
        const a = s.alpha * Math.max(0.1, Math.min(1.0, twinkle));
        const r = s.baseR * (0.92 + 0.16 * harmonic1);

        // High-speed dual-pass luminous star without expensive shadowBlur
        if (r > 1.3 || s.isPulsar) {
          // Soft outer corona
          ctx.fillStyle = `hsla(${s.hue},${s.sat}%,75%,${a * 0.22})`;
          ctx.beginPath();
          ctx.arc(s.x, s.y, r * 2.2, 0, Math.PI * 2);
          ctx.fill();

          // Crisp core
          ctx.fillStyle = `hsla(${s.hue},${s.sat}%,96%,${a})`;
          ctx.beginPath();
          ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
          ctx.fill();

          // Pulsar cross-flares
          if (s.isPulsar) {
            s.flareAngle += s.flareSpeed;
            const flareLen =
              r * (3.5 + 1.8 * Math.sin(tick * 0.035 + s.fPhase1));
            ctx.strokeStyle = `hsla(${s.hue},${s.sat}%,94%,${a * 0.7})`;
            ctx.lineWidth = 0.75;
            ctx.beginPath();
            ctx.moveTo(
              s.x - Math.sin(s.flareAngle) * flareLen,
              s.y - Math.cos(s.flareAngle) * flareLen,
            );
            ctx.lineTo(
              s.x + Math.sin(s.flareAngle) * flareLen,
              s.y + Math.cos(s.flareAngle) * flareLen,
            );
            ctx.moveTo(
              s.x - Math.cos(s.flareAngle) * flareLen,
              s.y + Math.sin(s.flareAngle) * flareLen,
            );
            ctx.lineTo(
              s.x + Math.cos(s.flareAngle) * flareLen,
              s.y - Math.sin(s.flareAngle) * flareLen,
            );
            ctx.stroke();
          }
        } else {
          ctx.fillStyle = `hsla(${s.hue},${s.sat}%,92%,${a})`;
          ctx.beginPath();
          ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.fillStyle = "rgb(3,7,18)";
    ctx.fillRect(0, 0, W, H);
    rafRef.current = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [starDensityMultiplier, isMobile]);

  /* ── Black Hole Canvas (Desktop Only) ────────────────────────────────────── */
  useEffect(() => {
    if (isMobile || !showPlanet) return;

    const canvas = bhCanvasRef.current;
    if (!canvas) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const SIZE = canvas.offsetWidth || 260;
    canvas.width = SIZE * dpr;
    canvas.height = SIZE * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const CX = SIZE / 2;
    const CY = SIZE / 2;
    const HOLE_R = SIZE * 0.175;
    const MAX_R = SIZE * 0.42;
    const MIN_R = HOLE_R + 4;
    const N = 1400;

    interface DiskP {
      angle: number;
      r: number;
      speed: number;
      hue: number;
      sat: number;
      alpha: number;
      trailArc: number;
      fPhase: number;
      fFreq: number;
    }
    const particles: DiskP[] = [];
    for (let i = 0; i < N; i++) {
      const t = Math.pow(Math.random(), 1.7);
      const r = MIN_R + t * (MAX_R - MIN_R);
      const speed = 0.0035 * Math.sqrt(MAX_R / r) * (0.8 + Math.random() * 0.4);
      const hue = 185 + t * 35;
      const sat = t > 0.85 ? 20 : 60 + t * 25;
      particles.push({
        angle: Math.random() * Math.PI * 2,
        r,
        speed,
        hue,
        sat,
        alpha: 0.6 + Math.random() * 0.4,
        trailArc: 0.08 + t * 0.15,
        fPhase: Math.random() * Math.PI * 2,
        fFreq: 0.025 + Math.random() * 0.05,
      });
    }

    const halo = ctx.createRadialGradient(CX, CY, HOLE_R, CX, CY, HOLE_R * 4.5);
    halo.addColorStop(0, "rgba(56,189,248,0.12)");
    halo.addColorStop(0.45, "rgba(14,116,233,0.04)");
    halo.addColorStop(1, "rgba(3,7,18,0)");

    const ring = ctx.createRadialGradient(
      CX,
      CY,
      HOLE_R * 0.88,
      CX,
      CY,
      HOLE_R * 1.55,
    );
    ring.addColorStop(0, "rgba(255,255,255,0.95)");
    ring.addColorStop(0.45, "rgba(56,189,248,0.60)");
    ring.addColorStop(0.8, "rgba(14,116,233,0.20)");
    ring.addColorStop(1, "rgba(3,7,18,0)");

    let tick = 0;
    let lastTime = 0;
    let isVisible = true;

    const handleVisibility = () => {
      isVisible = !document.hidden;
      if (isVisible) {
        bhRafRef.current = requestAnimationFrame(drawBH);
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    function drawBH(time: number = 0) {
      if (!isVisible) return;
      bhRafRef.current = requestAnimationFrame(drawBH);

      if (time - lastTime < 30) return;
      lastTime = time;

      tick++;
      const PREC = 0.27 + Math.sin(tick * 0.008) * 0.04;

      ctx!.clearRect(0, 0, SIZE, SIZE);

      ctx!.fillStyle = halo;
      ctx!.beginPath();
      ctx!.arc(CX, CY, HOLE_R * 4.5, 0, Math.PI * 2);
      ctx!.fill();

      // Back particles
      for (const p of particles) {
        p.angle += p.speed;
        const px = CX + Math.cos(p.angle) * p.r;
        const py = CY + Math.sin(p.angle) * p.r * PREC;
        if (py >= CY) continue;
        const ta = p.angle - p.trailArc;
        const tx = CX + Math.cos(ta) * p.r;
        const ty = CY + Math.sin(ta) * p.r * PREC;
        const flicker = 0.7 + 0.3 * Math.sin(tick * p.fFreq + p.fPhase);
        const front = 0.4 + 0.6 * Math.cos(p.angle + Math.PI * 0.5);
        const a = p.alpha * flicker * (0.25 + front * 0.75) * 0.55;
        ctx!.strokeStyle = `hsla(${p.hue},${p.sat}%,88%,${a})`;
        ctx!.lineWidth = 0.8 + (1 - p.r / MAX_R) * 0.8;
        ctx!.beginPath();
        ctx!.moveTo(tx, ty);
        ctx!.lineTo(px, py);
        ctx!.stroke();
      }

      ctx!.fillStyle = ring;
      ctx!.beginPath();
      ctx!.arc(CX, CY, HOLE_R * 1.55, 0, Math.PI * 2);
      ctx!.fill();

      ctx!.fillStyle = "#020408";
      ctx!.beginPath();
      ctx!.arc(CX, CY, HOLE_R * 0.93, 0, Math.PI * 2);
      ctx!.fill();

      ctx!.strokeStyle = "rgba(56,189,248,0.30)";
      ctx!.lineWidth = 1.5;
      ctx!.beginPath();
      ctx!.arc(CX, CY, HOLE_R * 0.93, 0, Math.PI * 2);
      ctx!.stroke();

      // Front particles
      for (const p of particles) {
        const px = CX + Math.cos(p.angle) * p.r;
        const py = CY + Math.sin(p.angle) * p.r * PREC;
        if (py < CY) continue;
        const ta = p.angle - p.trailArc;
        const tx = CX + Math.cos(ta) * p.r;
        const ty = CY + Math.sin(ta) * p.r * PREC;
        const flicker = 0.7 + 0.3 * Math.sin(tick * p.fFreq + p.fPhase);
        const front = 0.4 + 0.6 * Math.cos(p.angle + Math.PI * 0.5);
        const a = p.alpha * flicker * (0.35 + front * 0.65);
        ctx!.strokeStyle = `hsla(${p.hue},${p.sat}%,92%,${a})`;
        ctx!.lineWidth = 0.9 + (1 - p.r / MAX_R) * 0.9;
        ctx!.beginPath();
        ctx!.moveTo(tx, ty);
        ctx!.lineTo(px, py);
        ctx!.stroke();
      }
    }

    bhRafRef.current = requestAnimationFrame(drawBH);
    return () => {
      cancelAnimationFrame(bhRafRef.current);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [showPlanet, isMobile]);

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className={`fixed inset-0 pointer-events-none -z-10 overflow-hidden bg-[#030712] select-none ${className}`}
      style={{
        // Default CSS mouse parallax variables
        ["--mouse-x" as string]: "0",
        ["--mouse-y" as string]: "0",
      }}
    >
      {/* 1. Galaxy Canvas — Adaptive Particle Starfield */}
      <canvas
        ref={canvasRef}
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
        }}
      />

      {/* 2. Nebula Glow — Upper Left (CSS variable parallax) */}
      <div
        className="absolute -top-[12%] -left-[8%] w-[65vw] h-[65vw] max-w-[800px] max-h-[800px] rounded-full blur-[60px] md:blur-[130px] pointer-events-none opacity-25 md:opacity-30"
        style={{
          background:
            "radial-gradient(circle, rgba(14,165,233,0.24) 0%, rgba(99,102,241,0.14) 50%, transparent 75%)",
          transform:
            !isMobile && !prefersReducedMotion
              ? "translate3d(calc(var(--mouse-x) * 14px), calc(var(--mouse-y) * 14px), 0)"
              : "none",
        }}
      />

      {/* 3. Nebula Glow — Bottom Right */}
      <div
        className="absolute -bottom-[12%] -right-[8%] w-[70vw] h-[70vw] max-w-[900px] max-h-[900px] rounded-full blur-[60px] md:blur-[140px] pointer-events-none opacity-20 md:opacity-25"
        style={{
          background:
            "radial-gradient(circle, rgba(168,85,247,0.22) 0%, rgba(79,70,229,0.12) 55%, transparent 80%)",
          transform:
            !isMobile && !prefersReducedMotion
              ? "translate3d(calc(var(--mouse-x) * -18px), calc(var(--mouse-y) * -18px), 0)"
              : "none",
        }}
      />

      {/* 4. Cosmic Shooting Stars (Hardware-Accelerated Meteors) - Hidden on Mobile */}
      {showShootingStars && !isMobile && <ShootingStarsLayer />}

      {/* 5. (High-Fidelity 3D Planets on Mobile and Desktop) */}
      {showPlanet && (
        <>
          {/* Planet 1: Ringed Gas Giant (Aero-Chronos) */}
          <RingedGasGiantPlanet
            className="absolute animate-planet-slow"
            style={{
              top: isMobile ? "14%" : "17%",
              left: isMobile ? "68%" : "18%",
              width: isMobile ? "82px" : "150px",
              opacity: isMobile ? 0.85 : 0.95,
            }}
          />

          {/* Planet 2: Crimson-Amber Terrestrial Planet with Moon (Ares-Nova) */}
          <TerrestrialPlanetWithMoon
            className="absolute animate-planet-reverse"
            style={{
              top: isMobile ? "58%" : "48%",
              left: isMobile ? "4%" : "5%",
              width: isMobile ? "70px" : "120px",
              opacity: isMobile ? 0.8 : 0.9,
            }}
          />

          {/* Planet 3: Mystic Ice Giant (Gliese) */}
          <IceGiantPlanet
            className="absolute animate-planet-slow"
            style={{
              top: isMobile ? "38%" : "32%",
              left: isMobile ? "8%" : "54%",
              width: isMobile ? "48px" : "85px",
              opacity: isMobile ? 0.7 : 0.85,
            }}
          />
        </>
      )}

      {/* 6. Canvas Black Hole — Desktop Only */}
      {showPlanet && !isMobile && (
        <canvas
          ref={bhCanvasRef}
          aria-hidden="true"
          style={{
            position: "absolute",
            top: "clamp(64px, 7%, 110px)",
            right: "clamp(20px, 4%, 70px)",
            width: "clamp(140px, 17vw, 250px)",
            height: "clamp(140px, 17vw, 250px)",
            pointerEvents: "none",
            opacity: 0.92,
            transform: !prefersReducedMotion
              ? "translate3d(calc(var(--mouse-x) * -10px), calc(var(--mouse-y) * -10px), 0)"
              : "none",
          }}
        />
      )}

      {/* 7. Custom Twinkling Rotating Stars (Rendered on BOTH Mobile and Desktop) */}
      {(isMobile ? STATIC_STARS.slice(0, 16) : STATIC_STARS).map((star) => (
        <div
          key={star.id}
          className="star-shape"
          style={{
            top: star.top,
            left: star.left,
            width:
              (isMobile ? Math.max(2.2, star.size * 0.75) : star.size) + "px",
            height:
              (isMobile ? Math.max(2.2, star.size * 0.75) : star.size) + "px",
            opacity: star.opacity,
            animationDelay: star.delay,
            animationDuration: star.duration,
          }}
        />
      ))}

      {/* 8. Center Vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at 50% 45%, rgba(3,7,18,0.25) 0%, rgba(3,7,18,0.52) 55%, rgba(3,7,18,0.85) 100%)",
        }}
      />

      {/* 9. Edge Vignette */}
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_110px_rgba(2,4,10,0.88)]" />
    </div>
  );
}

export default CosmicBackground;
