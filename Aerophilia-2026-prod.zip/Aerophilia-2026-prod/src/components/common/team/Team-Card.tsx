"use client";

import Image from "next/image";
import { TeamMember } from "@/types/Team-Types";
import "./Team-Card.css";

interface TeamCardProps {
  member: TeamMember;
}

export function TeamCard({ member }: TeamCardProps) {
  const initial = member.name.charAt(0).toUpperCase();

  return (
    <div className="tc-canvas">
      <div className="tc-wrapper">
        <article className="tc-card">
          {/* Animated grid background */}
          <div className="tc-grid" aria-hidden="true" />

          <div className="tc-content">
            {/* Team member photo */}
            <div className="tc-member-card">
              <div className="tc-photo-wrap">
                {member.photoUrl ? (
                  <Image
                    src={member.photoUrl}
                    alt={member.name}
                    width={150}
                    height={180}
                    className="tc-photo"
                    unoptimized
                  />
                ) : (
                  <div className="tc-photo-placeholder">{initial}</div>
                )}
              </div>
            </div>

            {/* Bottom ticket */}
            <div className="tc-bottom-row">
              {/* Left cutout */}
              <span
                className="tc-ticket-notch tc-ticket-notch-left"
                aria-hidden="true"
              />

              {/* Right cutout */}
              <span
                className="tc-ticket-notch tc-ticket-notch-right"
                aria-hidden="true"
              />

              {/* Name */}
              <div className="tc-ticket-detail tc-name-detail">
                <span className="tc-ticket-value">{member.name}</span>
              </div>

              {/* Role */}
              <div className="tc-ticket-detail tc-role-detail">
                <span className="tc-ticket-value tc-role-value">
                  {member.role}
                </span>
              </div>

              {/* Social links */}
              <div className="tc-social-icons">
                {/* LinkedIn */}
                <a
                  href={member.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="tc-social-icon"
                  aria-label={`View ${member.name}'s LinkedIn profile`}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="currentColor"
                      d="M6.5 8.5H3.5V20H6.5V8.5ZM5 3C3.9 3 3 3.9 3 5C3 6.1 3.9 7 5 7C6.1 7 7 6.1 7 5C7 3.9 6.1 3 5 3ZM10 8.5H13V10.1C13.4 9.3 14.7 8.2 16.7 8.2C20.2 8.2 21 10.4 21 13.4V20H18V14C18 12.6 18 10.8 16.1 10.8C14.2 10.8 14 12.3 14 13.9V20H11V8.5H10Z"
                    />
                  </svg>
                </a>

                {/* GitHub */}
                <a
                  href={member.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="tc-social-icon"
                  aria-label={`View ${member.name}'s GitHub profile`}
                >
                  <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fill="currentColor"
                      d="M12 2C6.48 2 2 6.58 2 12.2C2 16.7 4.87 20.53 8.83 21.84C9.33 21.94 9.5 21.64 9.5 21.39V19.67C6.73 20.29 6.15 18.33 6.15 18.33C5.7 17.14 5.05 16.82 5.05 16.82C4.15 16.19 5.12 16.2 5.12 16.2C6.12 16.27 6.64 17.24 6.64 17.24C7.53 18.79 8.98 18.35 9.53 18.1C9.62 17.45 9.88 17.01 10.17 16.76C7.96 16.51 5.64 15.57 5.64 11.47C5.64 10.28 6.05 9.31 6.72 8.55C6.6 8.31 6.28 7.21 6.82 5.7C6.82 5.7 7.69 5.42 9.67 6.81C10.5 6.57 11.39 6.45 12.27 6.45C13.15 6.45 14.04 6.57 14.87 6.81C16.85 5.42 17.72 5.7 17.72 5.7C18.26 7.21 17.94 8.31 17.82 8.55C18.49 9.31 18.9 10.28 18.9 11.47C18.9 15.58 16.58 16.5 14.36 16.75C14.72 17.07 15.04 17.69 15.04 18.64V21.39C15.04 21.64 15.21 21.94 15.72 21.84C19.68 20.53 22.55 16.7 22.55 12.2C22.55 6.58 18.07 2 12.55 2H12Z"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}
