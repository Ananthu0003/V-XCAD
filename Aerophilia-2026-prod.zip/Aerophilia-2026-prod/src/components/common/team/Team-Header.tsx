"use client";

export function TeamHeader() {
  return (
    <div className="relative flex flex-col items-center justify-center text-center pt-32 pb-12 px-4 z-10">
      {/* Pill Outline Title Container matching reference screenshot */}
      <div className="relative z-10 inline-flex flex-col items-center justify-center px-10 py-4 sm:px-16 sm:py-5 border-2 border-cyan-400/80 rounded-full bg-[#0b1329]/70 backdrop-blur-md shadow-[0_0_30px_rgba(34,211,238,0.25)] transition-all duration-300 hover:shadow-[0_0_40px_rgba(34,211,238,0.4)]">
        {/* Subtitle */}
        <span className="text-amber-400 font-semibold text-xs sm:text-sm tracking-widest uppercase mb-1">
          Crew on Board
        </span>

        {/* Main Title */}
        <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-cyan-300 tracking-wider uppercase font-sans">
          Meet The Team
        </h1>
      </div>
    </div>
  );
}
