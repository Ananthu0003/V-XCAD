"use client";

import { TEAM_MEMBERS } from "@/data/Team-Data";
import { TeamCard } from "./Team-Card";

export function TeamSection() {
  return (
    <section className="w-full max-w-7xl mx-auto px-4 pb-24 z-10 relative">
      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
        {TEAM_MEMBERS.map((member) => (
          <TeamCard key={member.name} member={member} />
        ))}
      </div>
    </section>
  );
}
