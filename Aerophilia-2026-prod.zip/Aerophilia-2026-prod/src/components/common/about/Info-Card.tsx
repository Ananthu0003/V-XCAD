import React from "react";
import type { InfoCardProps } from "@/types/about";

/**
 * InfoCard
 *
 * Implements the exact double-layered 3D polygon card structure from the Figma design:
 * - Outer dark offset backdrop frame with top-left & bottom-right chamfered (diagonal cut) corners.
 * - Inner card container with matching chamfered polygon clip-path and crisp 1.5px cyan border.
 * - All internal text centered to match Figma typography alignment.
 */
export function InfoCard({
  title,
  description,
  children,
  className = "",
}: InfoCardProps) {
  /** Clip-path polygon with 28px chamfer (diagonal cut) on top-left and bottom-right corners */
  const chamfer_clip =
    "polygon(28px 0%, 100% 0%, 100% calc(100% - 28px), calc(100% - 28px) 100%, 0% 100%, 0% 28px)";

  return (
    <div
      className={`relative h-full min-h-[280px] w-full group select-none ${className}`}
    >
      {/* ── Layer 1: Outer Dark Offset Backdrop / Shadow Frame (Figma 3D depth layer) ── */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[#09111e] border border-[#1e2f4a] rounded-none translate-x-2.5 translate-y-2.5 pointer-events-none transition-transform duration-300 group-hover:translate-x-3.5 group-hover:translate-y-3.5"
        style={{ clipPath: chamfer_clip }}
      />

      {/* ── Layer 2: Outer Cyan Stroke Border Ring ───────────────────────────────── */}
      <div
        className="relative h-full min-h-0 w-full p-[1.5px] transition-all duration-300 group-hover:-translate-y-1"
        style={{
          clipPath: chamfer_clip,
          background:
            "linear-gradient(135deg, #22d3ee 0%, rgba(34,211,238,0.3) 50%, #22d3ee 100%)",
        }}
      >
        {/* ── Layer 3: Inner Card Body Content ────────────────────────────────────── */}
        <div
          className="relative h-full min-h-0 w-full flex flex-col items-center text-center px-6 sm:px-8 py-10 bg-[#0d1a2d] transition-colors duration-300 group-hover:bg-[#10223b]"
          style={{ clipPath: chamfer_clip }}
        >
          {/* Hover Bottom Accent Line */}
          <div
            aria-hidden="true"
            className="absolute bottom-0 left-0 h-[4px] w-0 bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.65)] transition-all duration-500 ease-out group-hover:w-full"
          />

          {/* Card Title — Cyan, Bold, Uppercase, Condensed */}
          <h2 className="relative z-10 font-black uppercase text-cyan-400 text-xl sm:text-2xl tracking-widest leading-tight mb-6 font-sans group-hover:text-cyan-300 transition-colors">
            {title}
          </h2>

          {/* Card Description — Centered text */}
          {description && (
            <p className="relative z-10 text-gray-300 text-sm sm:text-[15px] leading-relaxed text-center font-normal flex-1">
              {description}
            </p>
          )}

          {/* Custom Children (e.g. Organized By logo & host info) */}
          {children && (
            <div className="relative z-10 mt-2 w-full flex flex-col items-center text-center">
              {children}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
