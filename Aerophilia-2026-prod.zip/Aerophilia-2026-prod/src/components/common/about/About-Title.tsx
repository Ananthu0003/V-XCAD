import React from "react";

/**
 * AboutTitle
 *
 * Renders the exact Figma-designed "ABOUT AEROPHILIA" header banner.
 * Uses CSS mask-image to create responsive gaps for the text, ensuring the line
 * never goes behind the text while seamlessly blending with the grid background.
 */
export function AboutTitle() {
  return (
    <div className="relative mt-4 mb-10 sm:mt-6 sm:mb-12 select-none flex justify-center w-full px-4">
      <div className="relative w-full max-w-[440px] md:max-w-[560px] h-[72px] md:h-[84px] flex items-center justify-center">
        {/* CSS Mask for the border gaps */}
        <style>
          {`
            .pill-mask {
              -webkit-mask-image: 
                linear-gradient(to right, black 24px, transparent 40px, transparent 170px, black 186px), 
                linear-gradient(to left, black 24px, transparent 40px, transparent 260px, black 276px);
              -webkit-mask-size: 100% 51%, 100% 51%;
              -webkit-mask-position: top left, bottom left;
              -webkit-mask-repeat: no-repeat;
              mask-image: 
                linear-gradient(to right, black 24px, transparent 40px, transparent 170px, black 186px), 
                linear-gradient(to left, black 24px, transparent 40px, transparent 260px, black 276px);
              mask-size: 100% 51%, 100% 51%;
              mask-position: top left, bottom left;
              mask-repeat: no-repeat;
            }
            @media (min-width: 768px) {
              .pill-mask {
                -webkit-mask-image: 
                  linear-gradient(to right, black 36px, transparent 52px, transparent 260px, black 276px), 
                  linear-gradient(to left, black 36px, transparent 52px, transparent 405px, black 421px);
                mask-image: 
                  linear-gradient(to right, black 36px, transparent 52px, transparent 260px, black 276px), 
                  linear-gradient(to left, black 36px, transparent 52px, transparent 405px, black 421px);
              }
            }
          `}
        </style>

        {/* Pill Border Frame with masked gaps */}
        <div className="absolute inset-0 w-full h-full pointer-events-none rounded-full border-[3.5px] sm:border-[4.5px] border-cyan-300 pill-mask" />

        {/* SEO Hidden H1 */}
        <h1 className="sr-only">About Aerophilia</h1>

        {/* ABOUT Text — Top Left */}
        <span
          aria-hidden="true"
          className="absolute -top-[16px] md:-top-[26px] left-8 md:left-12 text-4xl md:text-[56px] font-black italic tracking-wider text-cyan-300 uppercase font-sans leading-none select-none"
        >
          ABOUT
        </span>

        {/* AEROPHILIA Text — Bottom Right */}
        <span
          aria-hidden="true"
          className="absolute -bottom-[16px] md:-bottom-[26px] right-8 md:right-12 text-4xl md:text-[56px] font-black italic tracking-wider text-cyan-300 uppercase font-sans leading-none select-none"
        >
          AEROPHILIA
        </span>
      </div>
    </div>
  );
}
