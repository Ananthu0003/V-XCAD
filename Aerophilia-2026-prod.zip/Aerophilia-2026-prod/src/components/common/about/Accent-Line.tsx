import React from "react";

interface AccentLineProps {
  /** Optional additional CSS classes */
  className?: string;
}

/**
 * AccentLine
 *
 * Premium HUD-style sci-fi section transition.
 * Features glowing data rails, an animated central orb, scan-line pulse,
 * and optional label — inspired by the Uiverse Admin12121 design system.
 */
export function AccentLine({ className = "" }: AccentLineProps) {
  return (
    <div
      className={`relative flex flex-col items-center justify-center w-full py-8 overflow-hidden select-none ${className}`}
      aria-hidden="true"
    >
      {/* ── CSS animations ─────────────────────────────────── */}
      <style>{`
        @keyframes acl-pulse {
          0%, 100% { opacity: 0.5; transform: scale(1); }
          50%       { opacity: 1;   transform: scale(1.35); }
        }
        @keyframes acl-scan {
          0%   { transform: translateX(-100%); opacity: 0; }
          20%  { opacity: 1; }
          80%  { opacity: 1; }
          100% { transform: translateX(100%);  opacity: 0; }
        }
        .acl-pulse  { animation: acl-pulse 2.4s ease-in-out infinite; }
        .acl-scan   { animation: acl-scan  3.2s ease-in-out infinite; }
        .acl-scan2  { animation: acl-scan  3.2s ease-in-out 1.6s infinite; }
      `}</style>

      {/* ── Rail row ───────────────────────────────────────── */}
      <div className="relative flex items-center justify-center w-full max-w-5xl mx-auto px-6">
        {/* Left data rail */}
        <div className="flex-1 relative h-[1px] overflow-hidden">
          {/* base line */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/50 to-cyan-500/70" />
          {/* animated scan beam */}
          <div className="acl-scan absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-cyan-300/80 to-transparent" />
          {/* top micro-rail */}
          <div className="absolute top-[-4px] left-[30%] right-0 h-[1px] bg-gradient-to-r from-cyan-500/30 to-transparent" />
        </div>

        {/* ── Central gap — clean break between rails ─────── */}
        <div className="shrink-0 mx-3 flex flex-col items-center gap-[3px]">
          <div className="w-[3px] h-[3px] rounded-full bg-cyan-400/60" />
          <div className="w-[3px] h-[3px] rounded-full bg-cyan-400/30" />
        </div>

        {/* Right data rail */}
        <div className="flex-1 relative h-[1px] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-cyan-500/50 to-cyan-500/70" />
          <div className="acl-scan2 absolute inset-y-0 w-1/3 bg-gradient-to-l from-transparent via-cyan-300/80 to-transparent" />
          <div className="absolute top-[-4px] right-[30%] left-0 h-[1px] bg-gradient-to-l from-cyan-500/30 to-transparent" />
        </div>
      </div>

      {/* ── Bottom decorative tick marks ───────────────────── */}
      <div className="flex items-center gap-1.5 mt-3">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="bg-cyan-500/40 rounded-full"
            style={{
              width: i === 2 ? "20px" : i === 1 || i === 3 ? "10px" : "5px",
              height: "2px",
              opacity: i === 2 ? 0.9 : 0.4,
            }}
          />
        ))}
      </div>
    </div>
  );
}
