"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight, Image as ImageIcon } from "lucide-react";
import { PHOTO_SLIDES } from "@/data/about-data";
import type { ImageCarouselProps } from "@/types/about";

export function ImageCarousel({
  slides = PHOTO_SLIDES,
  autoPlayInterval = 3500,
}: ImageCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  }, [slides.length]);

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  }, [slides.length]);

  useEffect(() => {
    if (isPaused || slides.length === 0) return;
    const timer = setInterval(() => {
      handleNext();
    }, autoPlayInterval);

    return () => clearInterval(timer);
  }, [handleNext, isPaused, autoPlayInterval, slides.length]);

  const handleImageError = (id: string) => {
    setFailedImages((prev) => ({ ...prev, [id]: true }));
  };

  if (slides.length === 0) return null;

  return (
    <section className="relative w-full px-0 sm:px-6 py-10 sm:max-w-5xl sm:mx-auto select-none">
      {/* Outer Photo Carousel Card */}
      <div
        className="relative overflow-hidden rounded-none sm:rounded-3xl bg-[#0a1120] border-y sm:border border-cyan-500/30 p-2 sm:p-4 shadow-2xl transition-all duration-300"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Ambient Glow Spotlight 1: Top-Right Cyan */}
        <div
          aria-hidden="true"
          className="absolute -top-16 -right-16 w-60 h-60 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none"
        />

        {/* Ambient Glow Spotlight 2: Bottom-Left Amber Accent (Replacing purple glow to match project theme) */}
        <div
          aria-hidden="true"
          className="absolute -bottom-16 -left-16 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"
        />

        {/* Photo Display Viewport */}
        <div className="relative w-full aspect-[4/3] sm:aspect-[16/9] md:aspect-[21/9] rounded-xl sm:rounded-2xl overflow-hidden bg-[#0c1626]">
          {slides.map((slide, index) => {
            const isActive = index === currentIndex;
            const hasFailed = !slide.src || failedImages[slide.id];

            return (
              <div
                key={slide.id}
                className={`absolute inset-0 transition-opacity duration-[1700ms] ease-in-out flex items-center justify-center ${
                  isActive
                    ? "opacity-100 z-10 pointer-events-auto"
                    : "opacity-0 z-0 pointer-events-none"
                }`}
              >
                {!hasFailed && slide.src ? (
                  slide.portrait ? (
                    /* ── Blur-backdrop for portrait photos (Apple-style) ── */
                    <div className="relative w-full h-full">
                      {/* Blurred background fill */}
                      <Image
                        src={slide.src}
                        alt=""
                        fill
                        unoptimized
                        aria-hidden
                        className="object-cover scale-110 blur-xl opacity-60 saturate-150"
                        onError={() => handleImageError(slide.id)}
                      />
                      {/* Sharp portrait photo centered on top */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="relative h-full aspect-[3/4]">
                          <Image
                            src={slide.src}
                            alt={slide.alt}
                            fill
                            unoptimized
                            className="object-contain drop-shadow-2xl"
                            onError={() => handleImageError(slide.id)}
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* ── Standard landscape photo ── */
                    <Image
                      src={slide.src}
                      alt={slide.alt}
                      fill
                      unoptimized
                      className="object-cover"
                      style={{
                        objectPosition: slide.objectPosition ?? "center",
                      }}
                      onError={() => handleImageError(slide.id)}
                    />
                  )
                ) : (
                  /* Theme-styled Photo Placeholder Frame */
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-gradient-to-br from-[#0c1829] via-[#09111e] to-[#060c18] text-center border border-cyan-500/20">
                    <div className="relative z-10 w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-3 text-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.2)]">
                      <ImageIcon className="w-7 h-7 sm:w-8 sm:h-8 stroke-[1.5]" />
                    </div>

                    <h3 className="relative z-10 text-lg sm:text-2xl font-extrabold text-white tracking-wide max-w-md">
                      {slide.title}
                    </h3>
                  </div>
                )}

                {/* Bottom Caption Overlay Bar */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#09111e]/95 via-[#09111e]/75 to-transparent p-4 sm:p-6 flex flex-col sm:flex-row sm:items-end justify-between gap-2 z-20">
                  <div>
                    <h3 className="text-sm sm:text-lg font-bold text-white leading-tight">
                      {slide.title}
                    </h3>
                    <p className="text-xs text-gray-300 hidden sm:block mt-0.5">
                      {slide.description}
                    </p>
                  </div>
                  <span className="text-xs text-cyan-400 font-mono font-bold tracking-wider">
                    0{index + 1} / 0{slides.length}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Navigation Control — Previous */}
          <button
            onClick={handlePrev}
            className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-30 p-2 text-white/60 hover:text-cyan-400 hover:scale-110 transition-all focus:outline-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            aria-label="Previous Slide"
          >
            <ChevronLeft className="w-8 h-8 sm:w-10 sm:h-10 stroke-[1.5]" />
          </button>

          {/* Navigation Control — Next */}
          <button
            onClick={handleNext}
            className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-30 p-2 text-white/60 hover:text-cyan-400 hover:scale-110 transition-all focus:outline-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            aria-label="Next Slide"
          >
            <ChevronRight className="w-8 h-8 sm:w-10 sm:h-10 stroke-[1.5]" />
          </button>
        </div>

        {/* Pagination Dots (Cyan & Amber themed) */}
        <div className="relative z-10 flex items-center justify-center gap-2 mt-4 pb-1">
          {slides.map((_, idx) => (
            <button
              key={`dot-${idx}`}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2 rounded-full transition-all duration-300 focus:outline-none ${
                idx === currentIndex
                  ? "w-8 bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
                  : "w-2 bg-gray-700 hover:bg-gray-500"
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
