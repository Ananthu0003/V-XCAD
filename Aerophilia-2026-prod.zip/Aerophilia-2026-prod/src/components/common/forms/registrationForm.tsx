"use client";

import React, { useState } from "react";
import { toast } from "sonner";
import { RegistrationService } from "@/services/registration-service";
import type { WorkshopRegistrationData } from "@/types/Registration-Types";
import Link from "next/link";

interface WorkshopRegistrationFormProps {
  eventId: string;
  eventName: string;
}

const YEAR_OPTIONS = [
  { label: "8th Std", value: "8th Std" },
  { label: "9th Std", value: "9th Std" },
  { label: "10th Std", value: "10th Std" },
  { label: "11th Std (1st PUC)", value: "11th Std" },
  { label: "12th Std (2nd PUC)", value: "12th Std" },
  { label: "Others", value: "Others" },
] as const;

const initialForm = {
  name: "",
  email: "",
  phone: "",
  usn: "",
  college: "",
  year: "" as WorkshopRegistrationData["year"] | "",
  otherYear: "",
  department: "",
  agreedToTerms: false,
};

type FormState = typeof initialForm;

export function WorkshopRegistrationForm({
  eventId,
  eventName,
}: WorkshopRegistrationFormProps) {
  const [form, setForm] = useState<FormState>(initialForm);
  const [loading, setLoading] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => {
    const target = e.target;
    const value =
      target.type === "checkbox"
        ? (target as HTMLInputElement).checked
        : target.value;

    setForm((prev) => ({ ...prev, [target.name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (!form.year) {
        toast.error("Please select your class / std.");
        return;
      }

      if (form.year === "Others" && !form.otherYear.trim()) {
        toast.error("Please enter your class / std.");
        return;
      }

      if (!form.agreedToTerms) {
        toast.error("You must agree to the terms and conditions to register.");
        return;
      }

      setLoading(true);
      const selectedYear =
        form.year === "Others" ? form.otherYear.trim() : form.year;

      const payload: WorkshopRegistrationData = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        usn: form.usn ? form.usn : undefined,
        college: form.college,
        year: selectedYear,
        department: form.department || "General",
        eventId,
        eventName,
        registeredAt: new Date().toISOString(),
      };

      const result = await RegistrationService.submit(payload);

      if (result.success) {
        setSubmitted(true);
        toast.success("Registration successful! Meet you at Aerophilia 2026");
      } else {
        const errors = result.errors;

        const fieldErrorList =
          typeof errors === "object" &&
          errors !== null &&
          !Array.isArray(errors)
            ? Object.values(errors).flat()
            : [];

        const errorMessage =
          fieldErrorList.length > 0 && typeof fieldErrorList[0] === "string"
            ? fieldErrorList[0]
            : Array.isArray(errors) && errors.length > 0
              ? errors[0]
              : typeof errors === "string"
                ? errors
                : result.message || "Please check the form inputs.";

        toast.error(errorMessage);
      }
    } catch (error: any) {
      toast.error(
        error.message || "Something went wrong. Please check your connection.",
      );
    } finally {
      setLoading(false);
    }
  };

  // ── Success State ─────────────────────────────────────────────────────────
  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center text-center py-16 px-6 gap-6">
        <div className="relative flex items-center justify-center w-24 h-24 rounded-full bg-cyan-500/10 border border-cyan-500/30 shadow-[0_0_40px_rgba(6,182,212,0.2)]">
          <svg
            className="w-12 h-12 text-cyan-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4.5 12.75l6 6 9-13.5"
            />
          </svg>
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-white">
            You&apos;re Registered!
          </h3>
          <p className="text-slate-400 max-w-md">
            Your registration for{" "}
            <span className="text-cyan-400 font-semibold">{eventName}</span> has
            been confirmed. We&apos;ll reach out with further details closer to
            the event.
          </p>
        </div>
      </div>
    );
  }

  // ── Form ──────────────────────────────────────────────────────────────────
  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-8"
      aria-label={`Registration form for ${eventName}`}
      noValidate
    >
      {/* ── Personal Details ── */}
      <fieldset className="space-y-5">
        <legend className="text-xs font-semibold tracking-[0.2em] text-cyan-400/80 uppercase mb-4 flex items-center gap-2">
          <span className="inline-block w-4 h-px bg-cyan-400/50" />
          Personal Details
          <span className="inline-block flex-1 h-px bg-cyan-400/10" />
        </legend>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <FormField
            id="reg-name"
            name="name"
            label="Full Name"
            placeholder="e.g. Arjun Sharma"
            value={form.name}
            onChange={handleChange}
            required
          />
          <FormField
            id="reg-email"
            name="email"
            type="email"
            label="Email Address"
            placeholder="you@example.com"
            value={form.email}
            onChange={handleChange}
            required
          />
          <FormField
            id="reg-phone"
            name="phone"
            type="tel"
            label="Phone Number"
            placeholder="+91 98765 43210"
            value={form.phone}
            onChange={handleChange}
            required
          />
          <FormField
            id="reg-usn"
            name="usn"
            label="Student ID / Roll No. (Optional)"
            placeholder="e.g. Roll No. / Admission No."
            value={form.usn}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <FormField
            id="reg-college"
            name="college"
            label="School / PU College / Institution"
            placeholder="e.g. Sharada Vidyalaya / St. Aloysius PU College"
            value={form.college}
            onChange={handleChange}
            required
          />
          <FormField
            id="reg-department"
            name="department"
            label="Stream / Section (Optional)"
            placeholder="e.g. Science / PCMB / Section A"
            value={form.department}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="event-name"
              className="text-xs font-medium tracking-wide text-slate-400"
            >
              Event Name <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                id="event-name"
                name="eventName"
                disabled={true}
                value={eventName}
                readOnly
                type="text"
                placeholder="Enter event name"
                className="w-full appearance-none bg-white/[0.02] border border-white/5 rounded-xl px-4 py-3 pl-10 text-sm text-slate-400 opacity-70 cursor-not-allowed select-none transition-all duration-200"
              />
              <svg
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 002-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="reg-year"
              className="text-xs font-medium tracking-wide text-slate-400"
            >
              Class / Std <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <select
                id="reg-year"
                name="year"
                value={form.year}
                onChange={handleChange}
                required
                className="w-full appearance-none bg-white/[0.04] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 focus:ring-2 focus:ring-cyan-500/20 transition-all duration-200 cursor-pointer pr-10"
              >
                <option
                  value=""
                  disabled
                  className="bg-[#0a0f1e] text-slate-400"
                >
                  Select class / std
                </option>
                {YEAR_OPTIONS.map((y) => (
                  <option
                    key={y.value}
                    value={y.value}
                    className="bg-[#0a0f1e] text-white"
                  >
                    {y.label}
                  </option>
                ))}
              </select>
              <svg
                className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </div>
          </div>

          {form.year === "Others" && (
            <div className="flex flex-col gap-1.5 sm:col-span-2">
              <label
                htmlFor="reg-other-year"
                className="text-xs font-medium tracking-wide text-slate-400"
              >
                Specify Class / Std <span className="text-red-400">*</span>
              </label>
              <input
                id="reg-other-year"
                name="otherYear"
                type="text"
                placeholder="Enter your class / standard"
                value={form.otherYear}
                onChange={handleChange}
                required
                className="w-full appearance-none bg-white/[0.04] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 focus:ring-2 focus:ring-cyan-500/20 transition-all duration-200"
              />
            </div>
          )}
        </div>
      </fieldset>

      <div className="flex items-start gap-3.5 pt-3">
        <input
          id="agreedToTerms"
          name="agreedToTerms"
          type="checkbox"
          checked={form.agreedToTerms}
          onChange={handleChange}
          required
          className="mt-0.5 h-4 w-4 rounded border-white/20 bg-white/[0.04] text-cyan-500 focus:ring-cyan-500/20 focus:ring-4 accent-cyan-500 cursor-pointer transition-all"
        />
        <label
          htmlFor="agreedToTerms"
          className="text-xs text-slate-400 select-none cursor-pointer leading-relaxed"
        >
          I agree to the{" "}
          <Link
            href="/terms"
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4 transition-colors font-medium"
          >
            Terms and Conditions
          </Link>{" "}
          and{" "}
          <Link
            href="/privacy"
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4 transition-colors font-medium"
          >
            Privacy Policy
          </Link>{" "}
          , and agree to abide by all event rules and guidelines.{" "}
          <span className="text-red-400">*</span>
        </label>
      </div>

      {/* ── Submit ── */}
      <div className="pt-2">
        <button
          type="submit"
          id="reg-submit-btn"
          disabled={loading}
          className="relative w-full group overflow-hidden rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 px-6 py-4 text-sm font-semibold text-white tracking-wide shadow-[0_0_24px_rgba(6,182,212,0.25)] hover:shadow-[0_0_40px_rgba(6,182,212,0.45)] transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {/* Shimmer */}
          <span
            aria-hidden
            className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/10 to-transparent"
          />
          <span className="relative flex items-center justify-center gap-2">
            {loading ? (
              <>
                <svg
                  className="animate-spin w-4 h-4"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                  />
                </svg>
                Submitting…
              </>
            ) : (
              <>
                Confirm Registration
                <svg
                  className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 7l5 5m0 0l-5 5m5-5H6"
                  />
                </svg>
              </>
            )}
          </span>
        </button>
        <p className="text-center text-xs text-slate-500 mt-3">
          By registering, you agree to abide by all event rules and guidelines.
        </p>
      </div>
    </form>
  );
}

// ── Reusable Field Component ───────────────────────────────────────────────

interface FormFieldProps {
  id: string;
  name: string;
  label: string;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  type?: string;
}

function FormField({
  id,
  name,
  label,
  placeholder,
  value,
  onChange,
  required,
  type = "text",
}: FormFieldProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={id}
        className="text-xs font-medium tracking-wide text-slate-400"
      >
        {label}
        {required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      <input
        id={id}
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        required={required}
        className="bg-white/[0.04] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/60 focus:ring-2 focus:ring-cyan-500/20 transition-all duration-200"
      />
    </div>
  );
}

export default WorkshopRegistrationForm;
