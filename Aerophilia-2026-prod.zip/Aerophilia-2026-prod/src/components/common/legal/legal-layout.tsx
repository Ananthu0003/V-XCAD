"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { LegalPageData, LegalSection } from "@/types/legal";
import { LegalHeader } from "./legal-header";
import { PageEntry, PageEntryItem } from "@/components/common";
import {
  ChevronRight,
  ListFilter,
  ArrowUp,
  Mail,
  Shield,
  Info,
  AlertTriangle,
  FileCheck2,
} from "lucide-react";

interface LegalLayoutProps {
  data: LegalPageData;
}

export function LegalLayout({ data }: LegalLayoutProps) {
  const [activeSectionId, setActiveSectionId] = useState<string>(
    data.sections[0]?.id || "",
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Active section tracking via IntersectionObserver
  useEffect(() => {
    const handleObserver: IntersectionObserverCallback = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSectionId(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(handleObserver, {
      root: null,
      rootMargin: "-20% 0px -65% 0px",
      threshold: 0,
    });

    data.sections.forEach((section) => {
      const el = document.getElementById(section.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [data.sections]);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const navOffset = 96; // 6rem / 96px header height buffer
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="relative min-h-screen bg-transparent pb-24 overflow-x-hidden font-sans text-white">
      {/* Ambient background glow spots matching theme */}
      <div
        aria-hidden="true"
        className="absolute top-12 left-1/2 -translate-x-1/2 w-[900px] h-[500px] pointer-events-none opacity-40"
        style={{
          background:
            "radial-gradient(ellipse 50% 50% at 50% 40%, rgba(34,211,238,0.12) 0%, transparent 100%)",
        }}
      />
      <div
        aria-hidden="true"
        className="absolute top-[40%] right-0 w-[500px] h-[500px] bg-indigo-600/[0.04] rounded-full blur-[140px] pointer-events-none"
      />

      <PageEntry className="w-full">
        {/* ── Top Header Section ── */}
        <PageEntryItem>
          <LegalHeader
            title={data.title}
            subtitle={data.subtitle}
            category={data.category}
            lastUpdated={data.lastUpdated}
            description={data.description}
          />
        </PageEntryItem>

        {/* ── Main Layout Container ── */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 mt-2 sm:mt-4">
          {/* Mobile Table of Contents Dropdown Button */}
          <div className="lg:hidden mb-4 sm:mb-6 sticky top-[68px] sm:top-20 z-30">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-full py-2 px-3 sm:py-2.5 sm:px-4 rounded-xl border border-cyan-500/30 bg-[#0c1424]/95 backdrop-blur-xl flex items-center justify-between text-xs sm:text-sm font-semibold text-cyan-300 shadow-lg shadow-cyan-950/40 transition-colors hover:border-cyan-500/50"
              aria-expanded={mobileMenuOpen}
              aria-controls="mobile-toc-list"
            >
              <span className="flex items-center gap-2">
                <ListFilter className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
                <span>Jump to Section</span>
              </span>
              <span className="text-[10px] sm:text-xs font-mono px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
                {data.sections.length} Sections
              </span>
            </button>

            {/* Mobile TOC Dropdown */}
            {mobileMenuOpen && (
              <div
                id="mobile-toc-list"
                className="mt-1.5 p-2 rounded-xl border border-cyan-500/30 bg-[#0a1120]/95 backdrop-blur-2xl max-h-72 overflow-y-auto shadow-2xl space-y-0.5"
              >
                {data.sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => scrollToSection(section.id)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-medium flex items-center gap-2 transition-colors ${
                      activeSectionId === section.id
                        ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                        : "text-zinc-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    <span className="font-mono text-[10px] text-cyan-400/70 shrink-0">
                      {String(section.number).padStart(2, "0")}
                    </span>
                    <span className="truncate">{section.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ── Two-Column Layout (Desktop TOC + Content) ── */}
          <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-8 lg:gap-12 items-start">
            {/* ── Left Sidebar (Sticky Desktop Table of Contents) ── */}
            <aside className="hidden lg:block sticky top-28 space-y-6">
              <div className="rounded-2xl border border-cyan-500/20 bg-[#0b1325]/80 backdrop-blur-xl p-5 shadow-[0_8px_32px_rgba(0,0,0,0.36)]">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10">
                  <span className="text-xs font-mono uppercase tracking-widest text-[#f0c040] font-semibold flex items-center gap-1.5">
                    <ListFilter className="w-3.5 h-3.5 text-[#f0c040]" />
                    <span>Table of Contents</span>
                  </span>
                  <span className="text-[11px] font-mono text-zinc-400 bg-white/5 px-2 py-0.5 rounded-full">
                    {data.sections.length} Sections
                  </span>
                </div>

                <nav
                  aria-label="Table of contents"
                  className="space-y-1 max-h-[calc(100vh-280px)] overflow-y-auto pr-1.5 select-none [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:bg-white/5 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-thumb]:bg-cyan-500/30 [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-cyan-500/60 [scrollbar-width:thin] [scrollbar-color:rgba(6,182,212,0.3)_transparent]"
                >
                  {data.sections.map((section) => {
                    const isActive = activeSectionId === section.id;
                    return (
                      <button
                        key={section.id}
                        onClick={() => scrollToSection(section.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all duration-200 flex items-center gap-2.5 group ${
                          isActive
                            ? "bg-cyan-500/15 text-cyan-200 font-semibold border border-cyan-500/40 shadow-sm shadow-cyan-500/10 translate-x-1"
                            : "text-zinc-400 hover:text-zinc-200 hover:bg-white/5"
                        }`}
                      >
                        <span
                          className={`font-mono text-[11px] shrink-0 transition-colors ${
                            isActive
                              ? "text-cyan-400 font-bold"
                              : "text-zinc-400 group-hover:text-cyan-400/80"
                          }`}
                        >
                          {String(section.number).padStart(2, "0")}
                        </span>
                        <span className="truncate">{section.title}</span>
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Quick Help Box */}
              <div className="rounded-2xl border border-cyan-500/20 bg-[#0c1424]/60 backdrop-blur-md p-4 text-xs space-y-3">
                <div className="flex items-center gap-2 text-cyan-300 font-semibold">
                  <Mail className="w-4 h-4 text-cyan-400" />
                  <span>Need Clarifications?</span>
                </div>
                <p className="text-zinc-400 leading-relaxed text-[11px]">
                  Contact the Team Challengers committee directly for questions
                  regarding rules or guidelines.
                </p>
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-semibold text-[11px] uppercase tracking-wider group"
                >
                  <span>Go to Contact Page</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </aside>

            {/* ── Right Column: Section Content Cards ── */}
            <main className="space-y-4 sm:space-y-6 md:space-y-8 min-w-0">
              {data.sections.map((section) => (
                <PageEntryItem key={section.id}>
                  <SectionCard section={section} />
                </PageEntryItem>
              ))}

              {/* ── Bottom Institutional Clarification & Contact Card ── */}
              <PageEntryItem>
                <div className="rounded-xl sm:rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-[#0c1527] to-[#070d1a] p-5 sm:p-7 md:p-8 backdrop-blur-xl relative overflow-hidden shadow-2xl">
                  <div
                    aria-hidden="true"
                    className="absolute -right-10 -bottom-10 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"
                  />
                  <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5 sm:gap-6">
                    <div className="space-y-1.5 sm:space-y-2">
                      <div className="inline-flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-mono uppercase tracking-widest text-[#f0c040]">
                        <FileCheck2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#f0c040]" />
                        <span>Official Team Challengers Publication</span>
                      </div>
                      <h3 className="text-base sm:text-lg md:text-xl font-bold text-white">
                        Questions Regarding Aerophilia 2026?
                      </h3>
                      <p className="text-zinc-400 text-xs sm:text-sm max-w-xl leading-relaxed">
                        For event inquiries, workshop registrations, or policy
                        questions, you can reach our organizing team via email
                        at{" "}
                        <a
                          href="mailto:challengers@sahyadri.edu.in"
                          className="text-cyan-300 hover:underline font-mono"
                        >
                          challengers@sahyadri.edu.in
                        </a>{" "}
                        or visit the campus help desk during festival days.
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-2.5 sm:gap-3 shrink-0 w-full md:w-auto">
                      <Link
                        href="/contact"
                        className="w-full sm:w-auto text-center px-4 py-2 sm:px-5 sm:py-2.5 rounded-full bg-cyan-500 text-black text-xs font-bold tracking-wider uppercase hover:bg-cyan-400 hover:shadow-lg hover:shadow-cyan-500/25 transition-all"
                      >
                        Contact Crew
                      </Link>
                      <button
                        onClick={scrollToTop}
                        className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-full border border-white/10 hover:border-cyan-500/40 text-zinc-400 hover:text-white text-xs transition-colors"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                        <span>Back to Top</span>
                      </button>
                    </div>
                  </div>
                </div>
              </PageEntryItem>
            </main>
          </div>
        </div>
      </PageEntry>
    </div>
  );
}

/* ── Section Card Component ── */
function SectionCard({ section }: { section: LegalSection }) {
  return (
    <article
      id={section.id}
      className="scroll-mt-24 sm:scroll-mt-28 relative rounded-xl sm:rounded-2xl border border-cyan-500/20 bg-[#0c1424]/85 backdrop-blur-md p-4 sm:p-6 md:p-8 hover:border-cyan-500/40 transition-all duration-300 shadow-[0_4px_24px_rgba(0,0,0,0.4)] group"
    >
      {/* Top Section Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 sm:gap-3 mb-3 sm:mb-4 pb-2.5 sm:pb-3 border-b border-white/5">
        <div className="flex items-center gap-2 sm:gap-3">
          <span className="flex items-center justify-center w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-md sm:rounded-lg bg-cyan-950/60 border border-cyan-500/40 font-mono text-[10px] sm:text-xs font-bold text-cyan-300 shadow-sm">
            {String(section.number).padStart(2, "0")}
          </span>
          <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-zinc-400 uppercase">
            Section {section.number}
          </span>
        </div>

        {section.badge && (
          <span className="text-[9px] sm:text-[10px] md:text-[11px] font-mono uppercase tracking-wider px-2 py-0.5 sm:px-2.5 sm:py-0.5 rounded-full border border-cyan-500/25 bg-cyan-950/30 text-cyan-300">
            {section.badge}
          </span>
        )}
      </div>

      {/* Section Title */}
      <h2 className="text-base sm:text-xl md:text-2xl font-bold sm:font-black text-cyan-300 tracking-wide font-sans mb-2 sm:mb-3 group-hover:text-cyan-200 transition-colors">
        {section.title}
      </h2>

      {/* Lead sentence / Highlight */}
      {section.lead && (
        <p className="text-zinc-200 text-xs sm:text-[14px] md:text-[15px] font-medium leading-relaxed border-l-2 border-cyan-400 pl-3 my-2 sm:my-3 italic">
          {section.lead}
        </p>
      )}

      {/* Body Paragraphs */}
      <div className="space-y-2.5 sm:space-y-3 mt-2.5 sm:mt-3">
        {section.paragraphs.map((p, idx) => (
          <p
            key={idx}
            className="text-zinc-300/95 text-[13px] sm:text-[14px] md:text-[15px] leading-relaxed"
          >
            {p}
          </p>
        ))}
      </div>

      {/* Bullet Points */}
      {section.bullets && section.bullets.length > 0 && (
        <ul className="mt-3 sm:mt-4 space-y-2 sm:space-y-2.5 pl-0.5">
          {section.bullets.map((bullet, idx) => {
            const hasColon = bullet.includes(":");
            let prefix = "";
            let rest = bullet;
            if (hasColon) {
              const parts = bullet.split(":");
              prefix = parts[0] + ":";
              rest = parts.slice(1).join(":");
            }

            return (
              <li
                key={idx}
                className="flex items-start gap-2 sm:gap-2.5 text-zinc-300/95 text-[13px] sm:text-[14px] md:text-[15px] leading-relaxed"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 mt-2 shadow-[0_0_6px_rgba(34,211,238,0.8)]" />
                <span>
                  {hasColon ? (
                    <>
                      <strong className="text-white font-semibold">
                        {prefix}
                      </strong>
                      <span className="text-zinc-300/90">{rest}</span>
                    </>
                  ) : (
                    bullet
                  )}
                </span>
              </li>
            );
          })}
        </ul>
      )}

      {/* Callout Notice Box */}
      {section.callout && (
        <div
          className={`mt-4 sm:mt-5 p-3 sm:p-4 rounded-lg sm:rounded-xl border flex items-start gap-2.5 sm:gap-3.5 ${
            section.callout.type === "warning"
              ? "bg-amber-950/20 border-amber-500/30 text-amber-200"
              : section.callout.type === "note"
                ? "bg-[#0f1d33]/80 border-cyan-500/30 text-cyan-200"
                : "bg-[#0e192c]/80 border-cyan-500/30 text-cyan-200"
          }`}
        >
          {section.callout.type === "warning" ? (
            <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 shrink-0 mt-0.5" />
          ) : section.callout.type === "note" ? (
            <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400 shrink-0 mt-0.5" />
          )}
          <div className="space-y-1 text-[11px] sm:text-xs md:text-sm leading-relaxed">
            {section.callout.title && (
              <div className="font-bold tracking-wide uppercase font-mono text-[10px] sm:text-[11px] text-white">
                {section.callout.title}
              </div>
            )}
            <p className="text-zinc-300/95">{section.callout.text}</p>
          </div>
        </div>
      )}
    </article>
  );
}
