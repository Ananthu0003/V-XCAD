"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ShieldCheck, FileText, Calendar } from "lucide-react";

interface LegalHeaderProps {
  title: string;
  subtitle: string;
  category: string;
  lastUpdated: string;
  description: string;
}

export function LegalHeader({
  title,
  subtitle,
  category,
  lastUpdated,
  description,
}: LegalHeaderProps) {
  const pathname = usePathname();

  const isTerms = pathname === "/terms";
  const isPrivacy = pathname === "/privacy";

  return (
    <div className="relative flex flex-col items-center justify-center text-center pt-6 pb-8 sm:pt-10 sm:pb-12 md:pt-12 md:pb-14 px-3 sm:px-4 z-10">
      {/* Pill Outline Title Capsule matching Team-Header / Contact-Header */}
      <div className="relative z-10 inline-flex flex-col items-center justify-center px-5 py-2.5 sm:px-10 sm:py-4 md:px-14 md:py-5 border sm:border-2 border-cyan-400/80 rounded-full bg-[#0b1329]/80 backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.18)] sm:shadow-[0_0_30px_rgba(34,211,238,0.25)] transition-all duration-300 hover:shadow-[0_0_40px_rgba(34,211,238,0.4)]">
        {/* Category subtitle in amber */}
        <span className="text-[#f0c040] font-semibold text-[10px] sm:text-xs md:text-sm tracking-widest uppercase mb-0.5 sm:mb-1 font-sans">
          {category}
        </span>

        {/* Main Title in bold cyan */}
        <h1 className="text-xl sm:text-2xl md:text-4xl lg:text-5xl font-extrabold sm:font-black text-cyan-300 tracking-wider uppercase font-sans">
          {title}
        </h1>
      </div>

      {/* Subtitle & Description */}
      <p className="mt-3.5 sm:mt-5 text-xs sm:text-sm md:text-base text-zinc-300 max-w-2xl font-medium tracking-wide px-2">
        {subtitle}
      </p>
      <p className="mt-1.5 sm:mt-2 text-[11px] sm:text-xs md:text-sm text-zinc-400/90 max-w-xl leading-relaxed px-3">
        {description}
      </p>

      {/* Metadata Badges (Last Updated & Organization) */}
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mt-4 sm:mt-6">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-full border border-cyan-500/25 bg-cyan-950/30 text-[10px] sm:text-xs font-mono text-cyan-300">
          <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-cyan-400" />
          <span>Last Updated: {lastUpdated}</span>
        </div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-full border border-white/10 bg-[#0c1424]/70 text-[10px] sm:text-xs font-mono text-zinc-400">
          <ShieldCheck className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-cyan-400" />
          <span>Official Team Challengers Notice</span>
        </div>
      </div>

      {/* Tab Switcher: Terms & Conditions <-> Privacy Policy */}
      <div className="inline-flex items-center p-1 sm:p-1.5 mt-5 sm:mt-8 rounded-full border border-cyan-500/30 bg-[#0a1120]/90 backdrop-blur-md shadow-lg shadow-cyan-950/30">
        <Link
          href="/terms"
          className={`flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:px-5 sm:py-2 rounded-full text-[11px] sm:text-xs md:text-sm font-semibold tracking-wider transition-all duration-200 ${
            isTerms
              ? "bg-cyan-500 text-black shadow-md shadow-cyan-500/30 font-bold"
              : "text-zinc-400 hover:text-white hover:bg-white/5"
          }`}
        >
          <FileText
            className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isTerms ? "text-black" : "text-cyan-400"}`}
          />
          <span>Terms & Conditions</span>
        </Link>
        <Link
          href="/privacy"
          className={`flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:px-5 sm:py-2 rounded-full text-[11px] sm:text-xs md:text-sm font-semibold tracking-wider transition-all duration-200 ${
            isPrivacy
              ? "bg-cyan-500 text-black shadow-md shadow-cyan-500/30 font-bold"
              : "text-zinc-400 hover:text-white hover:bg-white/5"
          }`}
        >
          <ShieldCheck
            className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isPrivacy ? "text-black" : "text-cyan-400"}`}
          />
          <span>Privacy Policy</span>
        </Link>
      </div>
    </div>
  );
}
