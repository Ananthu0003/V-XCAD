"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

export function SmoothScroll() {
  useEffect(() => {
    // Check if device is mobile or has touch pointer
    const isTouchOrMobile =
      typeof window !== "undefined" &&
      (window.matchMedia("(max-width: 768px)").matches ||
        window.matchMedia("(pointer: coarse)").matches);

    gsap.registerPlugin(ScrollTrigger);

    // If mobile / touch device, preserve 100% native hardware-accelerated touch momentum
    if (isTouchOrMobile) {
      // Use healthy lag smoothing on mobile so GSAP never stutters on frame drops
      gsap.ticker.lagSmoothing(500, 33);
      return;
    }

    // Initialize Lenis for desktop / mouse devices
    const lenis = new Lenis({
      duration: 1.1,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: "vertical",
      gestureOrientation: "vertical",
      smoothWheel: true,
      wheelMultiplier: 0.9,
      touchMultiplier: 1,
    });

    // Sync Lenis scroll with GSAP ScrollTrigger
    lenis.on("scroll", ScrollTrigger.update);

    // Synchronize Lenis's requestAnimationFrame with GSAP's ticker
    const update = (time: number) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(update);
    // On desktop, keep a responsive lag smoothing buffer
    gsap.ticker.lagSmoothing(500, 33);

    return () => {
      gsap.ticker.remove(update);
      lenis.destroy();
    };
  }, []);

  return null;
}
