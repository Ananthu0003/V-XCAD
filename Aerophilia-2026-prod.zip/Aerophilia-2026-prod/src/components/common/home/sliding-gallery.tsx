"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import "./sliding-gallery.css";

const IMAGES = Array.from({ length: 23 }, (_, i) => i + 1)
  .filter((num) => num !== 17 && num !== 19)
  .map((num) => `/assets/images/carousel/memory-${num}.webp`);

interface GalleryRowProps {
  images: string[];
  direction?: "left" | "right";
  speed?: number;
  className?: string;
}

const GalleryRow = ({
  images,
  direction = "left",
  speed = 40,
  className = "",
}: GalleryRowProps) => {
  return (
    <div
      className={`flex w-full overflow-hidden sliding-gallery-wrapper py-1.5 ${className}`}
    >
      <div
        className={`gallery-track ${direction === "left" ? "slide-left" : "slide-right"}`}
        style={{ animationDuration: `${speed}s` }}
      >
        {/* Set 1 */}
        {images.map((src, i) => (
          <div
            key={`set1-${i}`}
            className="relative w-48 h-32 sm:w-56 sm:h-36 md:w-72 md:h-48 shrink-0 rounded-xl overflow-hidden border border-cyan-500/20 group"
          >
            <Image
              src={src}
              alt="Aerophilia Past Memory"
              fill
              sizes="(max-width: 768px) 192px, 288px"
              className="object-cover transition-transform duration-500 group-hover:scale-110"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-cyan-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
          </div>
        ))}
        {/* Set 2 (Duplicate for infinite marquee effect) */}
        {images.map((src, i) => (
          <div
            key={`set2-${i}`}
            className="relative w-48 h-32 sm:w-56 sm:h-36 md:w-72 md:h-48 shrink-0 rounded-xl overflow-hidden border border-cyan-500/20 group"
            aria-hidden="true"
          >
            <Image
              src={src}
              alt=""
              fill
              sizes="(max-width: 768px) 192px, 288px"
              className="object-cover transition-transform duration-500 group-hover:scale-110"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-cyan-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
          </div>
        ))}
      </div>
    </div>
  );
};

export function SlidingGallery() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isInView, setIsInView] = useState(true);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { rootMargin: "200px 0px" },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const row1Images = IMAGES.slice(0, 8);
  const row2Images = IMAGES.slice(8, 16);
  const row3Images = IMAGES.slice(16, 23);

  return (
    <section
      ref={sectionRef}
      data-in-view={isInView ? "true" : "false"}
      className="sliding-gallery-section relative w-full py-14 sm:py-20 flex flex-col items-center overflow-hidden bg-transparent"
    >
      <div className="text-center mb-8 sm:mb-10 z-10 px-4">
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-400 to-indigo-300 tracking-wider">
          Moments from the Past
        </h2>
        <p className="text-zinc-400 mt-2 text-xs sm:text-sm md:text-base tracking-wide font-medium">
          A glimpse into the spectacular memories of Aerophilia
        </p>
      </div>

      <div className="flex flex-col gap-3 sm:gap-4 w-full max-w-[100vw]">
        <GalleryRow images={row1Images} direction="left" speed={35} />
        <GalleryRow images={row2Images} direction="right" speed={45} />
        <GalleryRow images={row3Images} direction="left" speed={38} />
      </div>
    </section>
  );
}
