"use client";

import { useEffect, useState, useRef } from "react";
import "./flipclock.css";

export function CountdownClock() {
  const [timeLeft, setTimeLeft] = useState({
    days: "00",
    hours: "00",
    minutes: "00",
    seconds: "00",
  });

  useEffect(() => {
    const targetDate = new Date("2026-11-13T00:00:00").getTime();

    const updateTimer = () => {
      const now = new Date().getTime();
      const distance = targetDate - now;

      if (distance < 0) {
        setTimeLeft({ days: "00", hours: "00", minutes: "00", seconds: "00" });
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24))
          .toString()
          .padStart(2, "0"),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
          .toString()
          .padStart(2, "0"),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
          .toString()
          .padStart(2, "0"),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
          .toString()
          .padStart(2, "0"),
      });
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto mb-12 px-2">
      <div className="flex items-center justify-between bg-slate-900/40 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-3 sm:p-6 shadow-2xl">
        <FlipUnit value={timeLeft.days} label="DAYS" />
        <div className="h-8 sm:h-12 w-px bg-linear-to-b from-transparent via-cyan-500/30 to-transparent" />

        <FlipUnit value={timeLeft.hours} label="HOURS" />
        <div className="h-8 sm:h-12 w-px bg-linear-to-b from-transparent via-cyan-500/30 to-transparent" />

        <FlipUnit value={timeLeft.minutes} label="MINS" fullLabel="MINUTES" />
        <div className="h-8 sm:h-12 w-px bg-linear-to-b from-transparent via-cyan-500/30 to-transparent" />

        <FlipUnit value={timeLeft.seconds} label="SECS" fullLabel="SECONDS" />
      </div>
    </div>
  );

  function FlipUnit({
    value,
    label,
    fullLabel,
  }: {
    value: string;
    label: string;
    fullLabel?: string;
  }) {
    return (
      <div className="flex flex-col items-center gap-1.5 sm:gap-3 flex-1">
        <div className="flip-container">
          <FlipDigit digit={value[0]} />
          <FlipDigit digit={value[1]} />
        </div>

        <span className="text-cyan-400/80 text-[10px] sm:text-xs font-semibold tracking-wider uppercase">
          <span className="sm:hidden">{label}</span>
          <span className="hidden sm:inline">{fullLabel || label}</span>
        </span>
      </div>
    );
  }

  function FlipDigit({ digit }: { digit: string }) {
    const [currentValue, setCurrentValue] = useState(digit);
    const [nextValue, setNextValue] = useState(digit);
    const [flipping, setFlipping] = useState(false);
    const prevDigitRef = useRef(digit);

    useEffect(() => {
      if (digit !== prevDigitRef.current) {
        setNextValue(digit);
        setFlipping(true);

        const timeout = setTimeout(() => {
          setFlipping(false);
          setCurrentValue(digit);
          prevDigitRef.current = digit;
        }, 600); // 0.6s to match CSS animation

        return () => clearTimeout(timeout);
      }
    }, [digit]);

    const staticTop = flipping ? nextValue : currentValue;
    const staticBottom = currentValue;

    return (
      <div className="nums" data-val={staticBottom}>
        <div className="top-half">{staticTop}</div>
        {flipping && (
          <div
            className="num-card flipping"
            data-num={currentValue}
            data-num-next={nextValue}
          />
        )}
      </div>
    );
  }
}
