"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ChevronUp,
  ChevronDown,
  Power,
  Volume2,
  VolumeX,
  Tv,
} from "lucide-react";
import { AIRSHOW_FEEDS } from "@/data/showcaseTV-Data";

// Curated high-definition Airshow broadcast feeds / camera angles

export function EventTvShowcase() {
  const [activeFeed, setActiveFeed] = useState<number>(0);
  const [isPoweredOn, setIsPoweredOn] = useState<boolean>(true);
  const [isGlitching, setIsGlitching] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const currentFeed = AIRSHOW_FEEDS[activeFeed] || AIRSHOW_FEEDS[0];

  useEffect(() => {
    if (!isPoweredOn) return;

    const timer = setInterval(() => {
      switchFeed((activeFeed + 1) % AIRSHOW_FEEDS.length);
    }, 6000);

    return () => clearInterval(timer);
  }, [isPoweredOn, activeFeed]);

  const switchFeed = (index: number) => {
    if (!isPoweredOn || index === activeFeed) return;
    setIsGlitching(true);
    setActiveFeed(index);
    setTimeout(() => {
      setIsGlitching(false);
    }, 200);
  };

  const channelUp = () => {
    if (!isPoweredOn) return;
    switchFeed((activeFeed + 1) % AIRSHOW_FEEDS.length);
  };

  const channelDown = () => {
    if (!isPoweredOn) return;
    switchFeed((activeFeed - 1 + AIRSHOW_FEEDS.length) % AIRSHOW_FEEDS.length);
  };

  const togglePower = () => {
    setIsGlitching(true);
    setIsPoweredOn(!isPoweredOn);
    setTimeout(() => setIsGlitching(false), 200);
  };

  return (
    <section
      id="featured-events"
      className="relative py-1 sm:py-16 px-3 sm:px-6 max-w-5xl mx-auto w-full z-10 select-none"
    >
      {/* ── Section Title (Minimal Airshow Broadcast) ───────────────── */}
      <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-10">
        {/* <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-cyan-500/30 bg-[#081224]/80 backdrop-blur-md text-cyan-300 text-xs font-mono tracking-widest uppercase mb-2.5">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span>AERO-TV • AIRSHOW BROADCAST</span>
        </div> */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight uppercase">
          Aerophilia Glimpses
        </h2>
      </div>

      {/* ── Realistic Retro-Futuristic Television Set ───────────────── */}
      <div className="relative mx-auto w-full max-w-3xl">
        {/* TV Top Dual Antenna */}
        <div className="flex justify-center items-end h-7 sm:h-9 -mb-1 relative z-0 pointer-events-none">
          <div className="relative w-36 sm:w-44 h-full flex justify-center">
            {/* Left Antenna Rod */}
            <div className="absolute bottom-0 left-6 sm:left-8 w-[2px] h-7 sm:h-9 bg-gradient-to-t from-zinc-600 via-zinc-400 to-cyan-300 origin-bottom transform -rotate-[22deg]">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 absolute -top-1 -left-[2px] shadow-[0_0_8px_#38bdf8]" />
            </div>
            {/* Right Antenna Rod */}
            <div className="absolute bottom-0 right-6 sm:right-8 w-[2px] h-7 sm:h-9 bg-gradient-to-t from-zinc-600 via-zinc-400 to-cyan-300 origin-bottom transform rotate-[22deg]">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 absolute -top-1 -left-[2px] shadow-[0_0_8px_#38bdf8]" />
            </div>
            {/* Antenna Swivel Mount */}
            <div className="absolute bottom-0 w-12 sm:w-14 h-2 sm:h-2.5 rounded-t-md bg-[#101726] border-t border-x border-zinc-700" />
          </div>
        </div>

        {/* TV Outer Cabinet / Chassis */}
        <div className="relative rounded-2xl sm:rounded-3xl bg-[#0c121e] border-4 border-[#1c283c] p-3 sm:p-5 md:p-6 shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_30px_rgba(6,182,212,0.12)]">
          {/* Main Layout: Screen on Left, Controls on Right (Stacked on Mobile) */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4 items-center">
            {/* ── CRT Television Screen (Crystal Clear - No Scanline Lines) ─── */}
            <div className="md:col-span-9 relative rounded-xl sm:rounded-2xl overflow-hidden border-4 border-[#070b12] bg-[#020408] aspect-[16/10] sm:aspect-[16/9] shadow-[inset_0_0_30px_rgba(0,0,0,0.95)]">
              {isPoweredOn ? (
                <>
                  {/* Airshow Background Image Feed */}
                  <div className="absolute inset-0 z-0">
                    <Image
                      src={currentFeed.image}
                      alt={currentFeed.label || "Aerophilia Showcase"}
                      fill
                      sizes="(max-width: 768px) 100vw, 700px"
                      className={`object-cover object-center transition-all duration-300 ${
                        isGlitching
                          ? "filter blur-xs brightness-150 contrast-150"
                          : "brightness-95"
                      }`}
                      priority
                    />
                    {/* Atmospheric Dark Gradient for Crisp Text Readability */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/50 pointer-events-none" />
                  </div>

                  {/* Glass Reflection & Vignette (Clean Glass Curve - No Line Effect) */}
                  <div className="absolute inset-0 pointer-events-none z-10 shadow-[inset_0_0_35px_rgba(0,0,0,0.85)] rounded-xl" />

                  {/* Channel Switch Glitch Flash */}
                  {isGlitching && (
                    <div className="absolute inset-0 z-20 pointer-events-none bg-cyan-400/20 backdrop-invert-20 flex items-center justify-center animate-pulse">
                      <div className="text-cyan-200 font-mono text-sm sm:text-base font-bold tracking-widest">
                        AIRSHOW CAM-0{activeFeed + 1}...
                      </div>
                    </div>
                  )}

                  {/* Top Broadcast Overlay: Channel & Live Tag */}
                  <div className="absolute top-2.5 sm:top-4 left-3 sm:left-4 right-3 sm:right-4 z-20 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/70 border border-white/10 backdrop-blur-xs text-[10px] sm:text-xs font-mono font-bold text-white">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                      <span>LIVE</span>
                      <span className="text-zinc-500">|</span>
                      <span className="text-cyan-400">
                        CH 0{activeFeed + 1}
                      </span>
                    </div>

                    <div className="text-[10px] sm:text-xs font-mono font-bold text-amber-300 px-2 py-0.5 rounded bg-black/70 border border-white/10 backdrop-blur-xs">
                      BACKGROUND • AIRSHOW
                    </div>
                  </div>

                  {/* Bottom Broadcast Banner / Showcase Info */}
                  <div className="absolute bottom-2.5 sm:bottom-4 left-3 sm:left-4 right-3 sm:right-4 z-20">
                    <Link href="/events" className="block group">
                      <h3 className="text-lg sm:text-2xl md:text-3xl font-black text-white uppercase tracking-tight drop-shadow-md group-hover:text-cyan-300 transition-colors">
                        AEROPHILIA 2026
                      </h3>
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 mt-1 text-[10px] sm:text-xs text-zinc-300 font-mono">
                        <span className="text-cyan-300 font-semibold">
                          {currentFeed.label}
                        </span>
                        <span>•</span>
                        <span>{currentFeed.channelName}</span>
                        <span>•</span>
                        <span className="text-zinc-400">Sahyadri Campus</span>
                      </div>
                    </Link>
                  </div>
                </>
              ) : (
                /* Screen Off State */
                <div className="absolute inset-0 z-10 bg-[#05080f] flex flex-col items-center justify-center text-zinc-700">
                  <div className="w-8 h-8 rounded-full border border-zinc-800 flex items-center justify-center mb-2">
                    <Tv className="w-4 h-4 text-zinc-700" />
                  </div>
                  <p className="text-[11px] font-mono tracking-wider">
                    STANDBY MODE
                  </p>
                </div>
              )}
            </div>

            {/* ── TV Physical Control Panel ───────────────────────── */}
            <div className="md:col-span-3 flex flex-col justify-between h-full bg-[#080d16] rounded-xl p-3 border border-[#162234] gap-2.5 sm:gap-4">
              {/* TV Branding & Power Button */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[9px] font-mono font-black tracking-widest text-zinc-400 uppercase">
                    AERO-VISION
                  </p>
                  <p className="text-[7px] font-mono text-zinc-600 uppercase">
                    Events Broadcast
                  </p>
                </div>

                {/* Power Toggle Button with LED */}
                <button
                  type="button"
                  onClick={togglePower}
                  className={`p-1.5 rounded-full border transition-all cursor-pointer ${
                    isPoweredOn
                      ? "bg-emerald-950 border-emerald-500/50 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.4)]"
                      : "bg-zinc-900 border-zinc-700 text-zinc-600"
                  }`}
                  title={isPoweredOn ? "Turn TV Off" : "Turn TV On"}
                  aria-label="Power Button"
                >
                  <Power className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Channel Up / Down Rocker Switch */}
              <div className="flex flex-col items-center gap-1.5 bg-[#04070d] p-2 rounded-lg border border-zinc-800/80">
                <span className="text-[8px] font-mono font-bold text-zinc-500 uppercase tracking-widest">
                  View Channels
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={channelDown}
                    disabled={!isPoweredOn}
                    className="p-2 rounded bg-[#101724] hover:bg-[#182338] disabled:opacity-40 border border-zinc-700 text-cyan-400 text-xs font-mono font-bold transition-all active:scale-95 cursor-pointer"
                    aria-label="Previous Channel"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>

                  <div className="w-9 h-7 rounded bg-black border border-cyan-500/40 flex items-center justify-center font-mono font-black text-xs text-cyan-300 shadow-[inset_0_0_6px_rgba(6,182,212,0.3)]">
                    {isPoweredOn ? `0${activeFeed + 1}` : "--"}
                  </div>

                  <button
                    type="button"
                    onClick={channelUp}
                    disabled={!isPoweredOn}
                    className="p-2 rounded bg-[#101724] hover:bg-[#182338] disabled:opacity-40 border border-zinc-700 text-cyan-400 text-xs font-mono font-bold transition-all active:scale-95 cursor-pointer"
                    aria-label="Next Channel"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Station Push Buttons — Desktop Only (Hidden on Mobile) */}
              <div className="hidden md:block">
                <div className="flex items-center justify-between text-[8px] font-mono text-zinc-500 uppercase mb-1">
                  <span>CAM PRESETS</span>
                  <button
                    type="button"
                    onClick={() => setIsMuted(!isMuted)}
                    className="hover:text-zinc-300 cursor-pointer"
                    title={isMuted ? "Unmute" : "Mute"}
                  >
                    {isMuted ? (
                      <VolumeX className="w-2.5 h-2.5" />
                    ) : (
                      <Volume2 className="w-2.5 h-2.5" />
                    )}
                  </button>
                </div>
                <div className="grid grid-cols-5 gap-1">
                  {AIRSHOW_FEEDS.map((_, idx) => {
                    const isActive = idx === activeFeed && isPoweredOn;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => switchFeed(idx)}
                        disabled={!isPoweredOn}
                        className={`py-1 rounded text-center font-mono text-[10px] font-bold transition-all cursor-pointer ${
                          isActive
                            ? "bg-cyan-500 text-black shadow-[0_0_8px_#38bdf8] font-black"
                            : "bg-[#0b1018] hover:bg-[#121a28] disabled:opacity-40 text-zinc-400 border border-zinc-800"
                        }`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Built-in Speaker Grill Slats */}
              <div className="flex flex-col gap-1 py-0.5">
                <div className="h-[2px] w-full bg-zinc-800/80 rounded-full" />
                <div className="h-[2px] w-full bg-zinc-800/80 rounded-full" />
                <div className="h-[2px] w-full bg-zinc-800/80 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default EventTvShowcase;
