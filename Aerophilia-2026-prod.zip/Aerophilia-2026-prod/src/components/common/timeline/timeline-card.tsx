"use client";

import React from "react";
import {
  Clock,
  MapPin,
  Trophy,
  Sparkles,
  ChevronDown,
  Calendar,
} from "lucide-react";
import { TimelineEvent } from "@/types/timeline";
import { formatTimeSpan } from "@/utils/format-date";

/**
 * Props for the individual TimelineCard component.
 */
interface TimelineCardProps {
  event: TimelineEvent;
  isExpanded: boolean;
  onToggleExpand: () => void;
  index: number;
}

/**
 * Aerophilia 2026 — Shared Timeline Card Component (Vanilla CSS & Pure TypeScript)
 *
 * Renders individual event details with glassmorphism styling, glowing status badges,
 * expandable drawer with placeholder registration text, without framer-motion.
 */
export function TimelineCard({
  event,
  isExpanded,
  onToggleExpand,
}: TimelineCardProps) {
  // Category aesthetic color maps
  const categoryBadgeStyles = {
    flagship:
      "bg-amber-500/10 text-amber-400 border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.15)]",
    technical:
      "bg-cyan-500/10 text-cyan-400 border-cyan-500/30 shadow-[0_0_15px_rgba(34,211,238,0.15)]",
    "non-technical": "bg-purple-500/10 text-purple-400 border-purple-500/30",
    workshop: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    keynote: "bg-rose-500/10 text-rose-400 border-rose-500/30",
  };

  const badgeStyle =
    categoryBadgeStyles[event.category] || categoryBadgeStyles.technical;

  return (
    <article
      className={`group relative rounded-2xl border transition-all duration-300 backdrop-blur-md overflow-hidden ${
        isExpanded
          ? "border-cyan-500/60 bg-[#0F172A]/90 shadow-[0_0_30px_rgba(34,211,238,0.2)]"
          : "border-slate-800 bg-[#0F172A]/60 hover:border-cyan-500/40 hover:bg-[#0F172A]/80 hover:shadow-[0_0_20px_rgba(34,211,238,0.1)]"
      }`}
    >
      {/* Featured Accent Border Glow */}
      {event.isFeatured && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-cyan-400 to-purple-500" />
      )}

      {/* Main Header & Summary Area */}
      <div className="p-5 sm:p-6">
        {/* Top Meta Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full border ${badgeStyle}`}
            >
              {event.category}
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-400 bg-slate-900/60 border border-slate-800 rounded-full">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              Day {event.dayNumber}
            </span>
          </div>

          <div className="flex items-center gap-1 text-xs font-medium text-cyan-400/90 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-500/20">
            <Clock className="w-3.5 h-3.5" />
            <span>{formatTimeSpan(event.startTime, event.endTime)}</span>
          </div>
        </div>

        {/* Title & Subtitle */}
        <div className="mb-4">
          <h3 className="text-lg sm:text-xl font-bold text-slate-100 group-hover:text-cyan-300 transition-colors flex items-center gap-2">
            {event.title}
            {event.isFeatured && (
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0 inline animate-pulse" />
            )}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">
            {event.subtitle}
          </p>
        </div>

        {/* Highlights Row (Location & Prize Pool) */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800/80">
          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
            <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{event.location}</span>
          </div>

          {event.prizePool && (
            <div className="flex items-center gap-1.5 px-3 py-1 text-xs font-bold text-amber-300 bg-amber-500/10 rounded-full border border-amber-500/30">
              <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>Prize Pool: {event.prizePool}</span>
            </div>
          )}

          <button
            onClick={onToggleExpand}
            aria-expanded={isExpanded}
            className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-cyan-400 hover:text-cyan-300 focus:outline-none transition-colors cursor-pointer"
          >
            <span>{isExpanded ? "Less Details" : "More Details"}</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-300 ${
                isExpanded ? "rotate-180" : ""
              }`}
            />
          </button>
        </div>
      </div>

      {/* Expandable Details Drawer (Pure Vanilla CSS transition) */}
      <div
        className={`grid transition-[grid-template-rows,opacity] duration-300 ease-in-out ${
          isExpanded
            ? "grid-rows-[1fr] opacity-100 border-t border-slate-800/80 bg-slate-950/40"
            : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="overflow-hidden">
          <div className="px-5 pb-6 pt-3">
            {/* Detailed Description */}
            <p className="text-sm text-slate-300 leading-relaxed mb-4">
              {event.description}
            </p>

            {/* Speaker / Host Info (if available) */}
            {event.speakerOrHost && (
              <div className="mb-4 p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-bold text-sm shrink-0">
                  {event.speakerOrHost.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">
                    {event.speakerOrHost.name}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {event.speakerOrHost.role}{" "}
                    {event.speakerOrHost.organization
                      ? `• ${event.speakerOrHost.organization}`
                      : ""}
                  </p>
                </div>
              </div>
            )}

            {/* Event Tags */}
            {event.tags && event.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-4">
                {event.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-0.5 text-[11px] font-medium text-slate-400 bg-slate-900 border border-slate-800 rounded-md"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}

            {/* Placeholder Text for Registration */}
            <div className="pt-2">
              <p className="text-xs text-cyan-400/80 italic font-mono flex items-center gap-1">
                <span>✦</span> Registration opening soon • Slots announced
                shortly
              </p>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}
