"use client";

import React from "react";
import { Search, X, Calendar, Filter } from "lucide-react";
import { useTimelineFilter } from "@/hooks/use-timeline-filter";
import { EventTimeline } from "@/components/common/events/EventTimeline";
import { TIMELINE_EVENTS } from "@/data/timeline-events";
import { MobileLayout } from "./mobile-layout";
import { TimelineEventCategory } from "@/types/timeline";

/**
 * Aerophilia 2026 — Main Timeline Entry Component
 *
 * Combines business state, category tabs, search input, day filters, and dynamic layout
 * selection (DesktopLayout vs MobileLayout) into a composable production-ready section.
 * Built with pure TypeScript and Vanilla CSS.
 */
export function Timeline() {
  const isDesktop = React.useSyncExternalStore(
    (callback) => {
      const mq = window.matchMedia("(min-width: 1024px)");
      mq.addEventListener("change", callback);
      return () => mq.removeEventListener("change", callback);
    },
    () =>
      typeof window !== "undefined"
        ? window.matchMedia("(min-width: 1024px)").matches
        : true,
    () => true,
  );

  const {
    categories,
    activeCategory,
    setActiveCategory,
    selectedDay,
    setSelectedDay,
    searchQuery,
    setSearchQuery,
    filteredEvents,
    activeEventId,
    setActiveEventId,
    filteredCount,
    totalCount,
  } = useTimelineFilter();

  const resetFilters = () => {
    setActiveCategory("all");
    setSelectedDay("all");
    setSearchQuery("");
  };

  return (
    <section
      id="timeline"
      className="relative pt-14 sm:pt-20 pb-0 bg-transparent text-slate-100 min-h-screen overflow-hidden"
    >
      <div className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        {/* Section Header — Matches Contact Section pill capsule style */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
          <div className="inline-flex flex-col items-center px-12 py-3 sm:px-16 sm:py-4 rounded-full border border-cyan-400 bg-transparent shadow-[0_0_20px_rgba(34,211,238,0.12)] mb-4 sm:mb-6 transition-all duration-300 hover:shadow-[0_0_30px_rgba(34,211,238,0.25)]">
            <p className="text-[#f0c040] font-sans italic font-medium tracking-widest text-[11px] sm:text-xs">
              Official Schedule • Nov 13 - 14, 2026
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-cyan-300 tracking-widest font-sans uppercase">
              EVENT TIMELINE
            </h2>
          </div>
          <p className="text-xl sm:text-2xl font-bold text-cyan-300 tracking-wider font-sans">
            Aerophilia 2026
          </p>
        </div>

        {/* Filter & Search Toolbar — Mobile/Tablet */}
        <div className="mb-6 space-y-4 lg:hidden">
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4 bg-[#0A101C]/80 border border-slate-800 p-3.5 sm:p-4 rounded-2xl backdrop-blur-xl">
            <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 shrink-0 pr-2">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" /> Day:
              </span>
              {(["all", 1, 2, 3] as const).map((day) => (
                <button
                  key={`day-btn-${day}`}
                  onClick={() => setSelectedDay(day)}
                  className={`px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs font-bold rounded-xl transition-all shrink-0 cursor-pointer ${
                    selectedDay === day
                      ? "bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.4)]"
                      : "bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800"
                  }`}
                >
                  {day === "all" ? "All Days" : `Day ${day}`}
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-72">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search events, tags, locations..."
                className="w-full bg-slate-900/90 border border-slate-800 rounded-xl pl-10 pr-9 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50 transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                  aria-label="Clear Search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-slate-800/80">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() =>
                    setActiveCategory(cat.id as TimelineEventCategory)
                  }
                  className={`relative px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
                    isActive
                      ? "text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 shadow-[0_0_12px_rgba(34,211,238,0.15)]"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
                  }`}
                >
                  <span>{cat.label}</span>
                  <span
                    className={`px-1.5 py-0.5 text-[10px] rounded-md ${
                      isActive
                        ? "bg-cyan-500 text-slate-950 font-black"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-between mb-4 px-1 lg:hidden">
          <p className="text-xs text-slate-400 font-medium">
            Showing{" "}
            <span className="text-cyan-400 font-bold">{filteredCount}</span> of{" "}
            {totalCount} events
          </p>
          {(activeCategory !== "all" ||
            selectedDay !== "all" ||
            searchQuery) && (
            <button
              onClick={resetFilters}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 underline underline-offset-4 cursor-pointer"
            >
              <Filter className="w-3 h-3" /> Reset Filters
            </button>
          )}
        </div>

        {filteredEvents.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-3xl border border-dashed border-slate-800 bg-slate-950/40 max-w-lg mx-auto transition-all duration-300">
            <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-500 shadow-inner">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-200">
              No Events Found
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              No timeline items matched your current filter criteria. Try
              adjusting your search query or selecting another category.
            </p>
            <button
              onClick={resetFilters}
              className="mt-5 px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold uppercase tracking-wider hover:bg-cyan-400 transition-colors cursor-pointer shadow-lg shadow-cyan-500/20"
            >
              Clear All Filters
            </button>
          </div>
        ) : isDesktop ? (
          <div className="hidden lg:block">
            <EventTimeline events={TIMELINE_EVENTS} />
          </div>
        ) : (
          <div className="block lg:hidden -mx-3 sm:-mx-6 lg:-mx-8">
            <MobileLayout
              events={filteredEvents}
              activeEventId={activeEventId}
              onSelectEvent={setActiveEventId}
            />
          </div>
        )}
      </div>
    </section>
  );
}
