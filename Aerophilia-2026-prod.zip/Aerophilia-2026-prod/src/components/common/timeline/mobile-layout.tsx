"use client";

import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import Image from "next/image";
import { useScroll, useMotionValueEvent } from "framer-motion";
import { Clock, MapPin, Trophy, ChevronDown } from "lucide-react";
import { TimelineEvent } from "@/types/timeline";
import { formatTimeSpan } from "@/utils/format-date";
import "./timeline-mobile.css";

/**
 * Props for MobileLayout
 */
interface MobileLayoutProps {
  events: TimelineEvent[];
  activeEventId: string | null;
  onSelectEvent: (id: string | null) => void;
}

/**
 * Aerophilia 2026 — Production-Grade Mobile Timeline
 *
 * Features:
 * - Upward-facing rocket gliding smoothly along milestone points without sticking
 * - Real-time hardware-accelerated scroll tracking with Framer-Motion useScroll
 * - Continuous illuminated flight path line connecting milestone dots to the Moon
 * - Dynamic Day grouping with WCAG Keyboard Accessibility
 */
export function MobileLayout({
  events,
  activeEventId,
  onSelectEvent,
}: MobileLayoutProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rocketRef = useRef<HTMLDivElement>(null);
  const flightTrailRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const moonNodeRef = useRef<HTMLDivElement>(null);
  const [currentActiveIndex, setCurrentActiveIndex] = useState<number>(0);

  // Scroll progress for the timeline container
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start 65%", "end 60%"],
  });

  // Dynamically derive all unique days from incoming events
  const days = useMemo(() => {
    const uniqueDays = Array.from(
      new Set(events.map((e) => e.dayNumber || 1)),
    ).sort((a, b) => a - b);
    return uniqueDays.length > 0 ? uniqueDays : [1];
  }, [events]);

  // Group events by day in a single O(N) pass
  const eventsByDay = useMemo(() => {
    const map = new Map<number, TimelineEvent[]>();
    for (const evt of events) {
      const day = evt.dayNumber || 1;
      if (!map.has(day)) map.set(day, []);
      map.get(day)!.push(evt);
    }
    return map;
  }, [events]);

  // Update rocket position based on progress
  const updateRocketPosition = useCallback(
    (progress: number) => {
      if (!containerRef.current || !rocketRef.current || events.length === 0)
        return;

      const containerRect = containerRef.current.getBoundingClientRect();
      let minY = 20;
      let maxY = containerRect.height - 80;

      // Calculate minY from first event node
      const firstNode = nodeRefs.current.get(events[0].id);
      if (firstNode) {
        const firstRect = firstNode.getBoundingClientRect();
        minY = firstRect.top - containerRect.top + firstRect.height / 2 - 30;
      }

      // Calculate maxY from moon node
      if (moonNodeRef.current) {
        const moonRect = moonNodeRef.current.getBoundingClientRect();
        maxY = moonRect.top - containerRect.top + moonRect.height / 2 - 20;
      }

      const p = Math.max(0, Math.min(1, progress));
      const targetY = minY + p * (maxY - minY);

      // Apply hardware-accelerated transform
      rocketRef.current.style.transform = `translate3d(-50%, ${targetY}px, 0)`;

      // Update active trail height
      if (flightTrailRef.current) {
        flightTrailRef.current.style.height = `${Math.max(0, targetY - minY)}px`;
      }

      // Determine active milestone index
      let closestIdx = 0;
      let minDistance = Infinity;

      for (let i = 0; i < events.length; i++) {
        const el = nodeRefs.current.get(events[i].id);
        if (el) {
          const nodeY =
            el.getBoundingClientRect().top -
            containerRect.top +
            el.offsetHeight / 2 -
            30;
          const dist = Math.abs(nodeY - targetY);
          if (dist < minDistance) {
            minDistance = dist;
            closestIdx = i;
          }
        }
      }

      if (p >= 0.95) {
        closestIdx = events.length;
      }

      setCurrentActiveIndex(closestIdx);
    },
    [events],
  );

  // Listen to framer-motion scroll value changes (smooth on all touch/desktop platforms)
  useMotionValueEvent(scrollYProgress, "change", (latest) => {
    updateRocketPosition(latest);
  });

  // Re-sync on mount, resize, and accordion expand
  useEffect(() => {
    const handleResizeOrMount = () => {
      updateRocketPosition(scrollYProgress.get());
    };

    handleResizeOrMount();
    window.addEventListener("resize", handleResizeOrMount, { passive: true });

    const timer = setTimeout(handleResizeOrMount, 360);

    return () => {
      window.removeEventListener("resize", handleResizeOrMount);
      clearTimeout(timer);
    };
  }, [activeEventId, scrollYProgress, updateRocketPosition]);

  return (
    <div className="relative w-full min-h-screen bg-transparent text-slate-100 pt-0 pb-0 overflow-hidden -mt-4">
      <style>{`
        .flame { transform-box: fill-box; transform-origin: top center; }
        .flame-outer { animation: pulse-outer 0.15s ease-in-out infinite alternate; }
        .flame-inner { animation: pulse-inner 0.12s ease-in-out infinite alternate; }
        .flame-core { animation: pulse-core 0.1s ease-in-out infinite alternate; }
        @keyframes pulse-outer {
            from { transform: scaleY(0.95); filter: drop-shadow(0 5px 15px rgba(255, 69, 0, 0.6)); opacity: 0.8; }
            to { transform: scaleY(1.05); filter: drop-shadow(0 20px 40px rgba(255, 69, 0, 1)) drop-shadow(0 0 20px rgba(255, 69, 0, 0.8)); opacity: 1; }
        }
        @keyframes pulse-inner {
            from { transform: scaleY(0.9); filter: drop-shadow(0 0 10px rgba(255, 215, 0, 0.6)); }
            to { transform: scaleY(1.1); filter: drop-shadow(0 15px 30px rgba(255, 215, 0, 1)); }
        }
        @keyframes pulse-core {
            from { transform: scaleY(0.9); filter: drop-shadow(0 0 5px rgba(224, 255, 255, 0.6)); }
            to { transform: scaleY(1.05); filter: drop-shadow(0 5px 15px rgba(224, 255, 255, 1)); }
        }
      `}</style>

      {/* Main Content Area */}
      <div
        ref={containerRef}
        className="relative max-w-lg mx-auto px-2 sm:px-4"
      >
        {/* Smooth Gliding Rocket */}
        <div
          ref={rocketRef}
          className="absolute z-30 pointer-events-none rocket-glider"
          style={{ left: "45.8333%", transform: "translate3d(-50%, 20px, 0)" }}
          aria-hidden="true"
        >
          <div className="relative w-12 sm:w-14 h-auto flex flex-col items-center justify-center filter drop-shadow-[0_0_15px_rgba(0,216,255,0.4)]">
            <svg viewBox="0 0 400 650" className="w-full h-auto">
              <path
                className="flame flame-outer"
                d="M170 440 Q200 600 200 600 Q200 600 230 440 Q200 540 170 440"
                fill="#FF4500"
                opacity="0.9"
              />
              <path
                className="flame flame-inner"
                d="M180 440 Q200 550 200 550 Q200 550 220 440 Q200 510 180 440"
                fill="#FFD700"
              />
              <path
                className="flame flame-core"
                d="M190 440 Q200 490 200 490 Q200 490 210 440 Q200 470 190 440"
                fill="#E0FFFF"
              />
              <polygon
                points="170,420 230,420 235,445 165,445"
                fill="#B0B0B0"
              />
              <polygon
                points="175,420 225,420 228,445 172,445"
                fill="#666666"
              />
              <path
                d="M200 40 C210 100 225 150 225 220 L225 425 L175 425 L175 220 C175 150 190 100 200 40 Z"
                fill="#FFFFFF"
              />
              <polygon
                points="225,200 255,220 255,290 225,270"
                fill="#F0F0F0"
              />
              <polygon
                points="225,205 248,222 248,235 225,220"
                fill="#1A1A1A"
              />
              <polygon
                points="175,200 145,220 145,290 175,270"
                fill="#F0F0F0"
              />
              <polygon
                points="175,205 152,222 152,235 175,220"
                fill="#1A1A1A"
              />
              <polygon
                points="225,270 355,360 355,405 225,385"
                fill="#FFFFFF"
              />
              <polygon points="175,270 45,360 45,405 175,385" fill="#FFFFFF" />
              <line
                x1="225"
                y1="365"
                x2="345"
                y2="395"
                stroke="#E0E0E0"
                strokeWidth="2"
              />
              <line
                x1="175"
                y1="365"
                x2="55"
                y2="395"
                stroke="#E0E0E0"
                strokeWidth="2"
              />
              <polygon
                points="215,370 275,455 250,465 220,425"
                fill="#F8F8F8"
              />
              <polygon
                points="185,370 125,455 150,465 180,425"
                fill="#F8F8F8"
              />
              <path
                d="M200 110 L213 155 C213 165 208 175 200 175 C192 175 187 165 187 155 Z"
                fill="#1A1A1A"
              />
              <path
                d="M200 112 L211 155 C211 163 207 172 200 172 Z"
                fill="#87CEFA"
                opacity="0.8"
              />
              <line
                x1="200"
                y1="110"
                x2="200"
                y2="175"
                stroke="#FFFFFF"
                strokeWidth="1.5"
              />
              <line
                x1="200"
                y1="40"
                x2="200"
                y2="110"
                stroke="#E0E0E0"
                strokeWidth="1"
              />
              <line
                x1="200"
                y1="175"
                x2="200"
                y2="425"
                stroke="#E0E0E0"
                strokeWidth="1"
              />
              <path
                d="M175 220 L225 220"
                stroke="#E0E0E0"
                strokeWidth="1.5"
                fill="none"
              />
              <path
                d="M175 320 L225 320"
                stroke="#E0E0E0"
                strokeWidth="1.5"
                fill="none"
              />
              <polygon
                points="200,250 205,260 215,260 207,266 210,276 200,270 190,276 193,266 185,260 195,260"
                fill="#CCCCCC"
              />
            </svg>
          </div>
        </div>

        {/* Dynamic Days Iteration */}
        {days.map((dayNum) => {
          const dayEvents = eventsByDay.get(dayNum) || [];
          if (dayEvents.length === 0) return null;

          const dateLabel = dayEvents[0]?.dateString || `Day ${dayNum}`;

          return (
            <div
              key={`mobile-timeline-day-${dayNum}`}
              className={`relative z-20 ${dayNum === 1 ? "mb-10 mt-1" : "mb-14 mt-8"}`}
            >
              {/* Day Header Badge */}
              <div className="flex justify-center mb-6 z-20">
                <span className="px-5 py-1.5 text-xs font-extrabold uppercase tracking-widest text-amber-300 bg-[#070E1E] border border-amber-400/60 rounded-full shadow-[0_0_15px_rgba(245,158,11,0.25)] flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  Day {dayNum} • {dateLabel}
                </span>
              </div>

              {/* Event List */}
              <div className="space-y-6">
                {dayEvents.map((evt) => {
                  const isExpanded = activeEventId === evt.id;
                  const isCurrentPoint =
                    events[currentActiveIndex]?.id === evt.id;
                  const displayDate = evt.dateString
                    ? evt.dateString.split(",")[0].trim()
                    : "TBD";
                  const speakerInitial = evt.speakerOrHost?.name
                    ? evt.speakerOrHost.name.trim().slice(0, 1).toUpperCase()
                    : "A";

                  return (
                    <div
                      key={evt.id}
                      className="relative grid grid-cols-12 items-center gap-1.5 sm:gap-2.5"
                    >
                      {/* Left Column: Date & Time Card */}
                      <div className="col-span-5 flex justify-end pr-1 select-none">
                        <div className="w-full max-w-[130px] rounded-xl border border-amber-500/30 bg-[#081224] p-2.5 shadow-[0_0_12px_rgba(245,158,11,0.08)] flex flex-col items-end text-right transition-all hover:border-amber-400/60">
                          <div className="text-xs font-extrabold text-amber-400 tracking-wide break-words">
                            {displayDate}
                          </div>
                          <div className="text-[11px] font-mono font-bold text-amber-300/90 tracking-tighter flex items-center gap-1 mt-1">
                            <Clock className="w-3 h-3 text-amber-400/80 shrink-0" />
                            <span>{evt.startTime}</span>
                          </div>
                        </div>
                      </div>

                      {/* Center Point / Milestone Node Dot */}
                      <div
                        ref={(el) => {
                          if (el) {
                            nodeRefs.current.set(evt.id, el);
                          } else {
                            nodeRefs.current.delete(evt.id);
                          }
                        }}
                        className="col-span-1 flex justify-center items-center relative z-20"
                      >
                        <button
                          type="button"
                          onClick={() =>
                            onSelectEvent(isExpanded ? null : evt.id)
                          }
                          aria-label={`Select ${evt.title}`}
                          className={`w-4 h-4 rounded-full border-2 transition-all duration-300 flex items-center justify-center focus-visible:outline-2 focus-visible:outline-amber-400 cursor-pointer ${
                            isCurrentPoint
                              ? "bg-cyan-400 border-white scale-125 shadow-[0_0_12px_rgba(34,211,238,0.9)]"
                              : "bg-amber-400 border-white hover:scale-110 shadow-[0_0_8px_rgba(245,158,11,0.7)]"
                          }`}
                        >
                          <div
                            className={`w-1.5 h-1.5 rounded-full ${isCurrentPoint ? "bg-cyan-950" : "bg-slate-950"}`}
                          />
                        </button>
                      </div>

                      {/* Right Column: Event Card */}
                      <div className="col-span-6 pl-1 min-w-0">
                        <div
                          className={`group rounded-xl border transition-all duration-300 p-3 sm:p-3.5 bg-[#091325] ${
                            isExpanded
                              ? "border-cyan-400 shadow-[0_0_20px_rgba(0,216,255,0.25)] bg-[#0C1A33]"
                              : "border-cyan-500/40 hover:border-cyan-300 hover:shadow-[0_0_15px_rgba(0,216,255,0.15)] hover:bg-[#0A162D]"
                          }`}
                        >
                          {/* Interactive Card Header Button */}
                          <button
                            type="button"
                            onClick={() =>
                              onSelectEvent(isExpanded ? null : evt.id)
                            }
                            aria-expanded={isExpanded}
                            aria-controls={`event-details-${evt.id}`}
                            id={`event-header-${evt.id}`}
                            className="w-full text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-400 rounded-lg"
                          >
                            <div className="flex items-start justify-between gap-1.5">
                              <h4 className="text-xs sm:text-sm font-extrabold text-cyan-300 uppercase tracking-wider leading-snug transition-colors group-hover:text-cyan-200 break-words">
                                {evt.title}
                              </h4>
                              <ChevronDown
                                className={`w-4 h-4 text-cyan-400 shrink-0 mt-0.5 transition-transform duration-300 ${
                                  isExpanded ? "rotate-180 text-cyan-200" : ""
                                }`}
                              />
                            </div>

                            {/* Category Badge & Prize Pool Info */}
                            <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
                              <span className="px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-400 font-semibold border border-cyan-500/30 uppercase tracking-wider">
                                {evt.category}
                              </span>
                              {Boolean(evt.prizePool) && (
                                <span className="text-amber-400 font-bold flex items-center gap-0.5 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/25">
                                  <Trophy className="w-3 h-3" />
                                  {evt.prizePool}
                                </span>
                              )}
                            </div>
                          </button>

                          {/* Expandable Details Drawer */}
                          <div
                            id={`event-details-${evt.id}`}
                            role="region"
                            aria-labelledby={`event-header-${evt.id}`}
                            className={`timeline-accordion-wrapper ${
                              isExpanded ? "is-open" : ""
                            }`}
                          >
                            <div className="timeline-accordion-inner">
                              <div className="mt-2.5 pt-2.5 border-t border-cyan-500/20 text-xs text-slate-300 space-y-2.5">
                                {evt.description && (
                                  <p className="leading-relaxed text-slate-300 font-normal normal-case break-words">
                                    {evt.description}
                                  </p>
                                )}

                                {evt.location && (
                                  <div className="flex items-center gap-1.5 text-cyan-300 font-medium break-words">
                                    <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                    <span>{evt.location}</span>
                                  </div>
                                )}

                                {evt.startTime && (
                                  <div className="flex items-center gap-1.5 text-slate-400 font-medium">
                                    <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                    <span>
                                      {formatTimeSpan(
                                        evt.startTime,
                                        evt.endTime,
                                      )}
                                    </span>
                                  </div>
                                )}

                                {/* Speaker / Host Info */}
                                {evt.speakerOrHost && (
                                  <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2.5 mt-1.5">
                                    <div className="w-7 h-7 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-bold text-xs shrink-0">
                                      {speakerInitial}
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <h5 className="text-xs font-bold text-slate-200 truncate">
                                        {evt.speakerOrHost.name}
                                      </h5>
                                      <p className="text-[11px] text-slate-400 truncate">
                                        {evt.speakerOrHost.role}{" "}
                                        {evt.speakerOrHost.organization
                                          ? `• ${evt.speakerOrHost.organization}`
                                          : ""}
                                      </p>
                                    </div>
                                  </div>
                                )}

                                {/* Event Tags */}
                                {evt.tags && evt.tags.length > 0 && (
                                  <div className="flex flex-wrap gap-1 pt-1">
                                    {evt.tags.map((tag, tagIdx) => (
                                      <span
                                        key={`${tag}-${tagIdx}`}
                                        className="px-1.5 py-0.5 text-[10px] font-medium text-slate-400 bg-slate-900/80 border border-slate-800 rounded"
                                      >
                                        #{tag}
                                      </span>
                                    ))}
                                  </div>
                                )}

                                {/* Registration Status */}
                                <div className="pt-2">
                                  <p className="text-[11px] text-cyan-400/85 italic font-mono flex items-center gap-1">
                                    <span>✦</span> Registration opening soon •
                                    Slots announced shortly
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* Anchor point for Rocket Touchdown on Moon Surface */}
        <div
          ref={moonNodeRef}
          className="relative mt-8 h-12 pointer-events-none"
          aria-hidden="true"
        />
      </div>

      {/* Moon Surface Background Image - Stretched End-to-End edge to edge with zero bottom gap */}
      <div className="relative -mt-10 w-full pointer-events-none z-10 overflow-hidden leading-none">
        <div className="relative w-full h-56 sm:h-72 md:h-80">
          <Image
            src="/assets/images/moon.png"
            alt="Moon Surface"
            fill
            className="object-cover object-top w-full"
            sizes="100vw"
            aria-hidden="true"
          />
          {/* Top Gradient Fade to seamlessly blend with cosmic background */}
          <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-[#030712] via-[#070b14]/60 to-transparent pointer-events-none" />
        </div>
      </div>
    </div>
  );
}
