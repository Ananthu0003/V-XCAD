"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export function GalleryHeader() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.94]);

  return (
    <motion.div
      ref={ref}
      style={{ y, opacity, scale }}
      className="relative flex flex-col items-center text-center mb-14 select-none"
    >
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white"
      >
        THE{" "}
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">
          GALLERY
        </span>
      </motion.h1>
      {/* 
      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="mt-4 text-zinc-400 text-sm sm:text-base max-w-lg"
      >
        Every frame captures a moment where passion took flight. Browse through
        the highlights of Aerophilia.
      </motion.p> */}
    </motion.div>
  );
}
