"use client";

import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { GalleryCard } from "./Gallery-Card";
import { GalleryLightbox } from "./Gallery-Lightbox";
import { GALLERY_IMAGES } from "@/data/gallery-data";
import type { GalleryImage } from "@/data/gallery-data";

export function GalleryGrid() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const openLightbox = useCallback((image: GalleryImage) => {
    const idx = GALLERY_IMAGES.findIndex((img) => img.id === image.id);
    if (idx !== -1) setLightboxIndex(idx);
  }, []);

  const closeLightbox = useCallback(() => setLightboxIndex(null), []);

  const prevImage = useCallback(() => {
    setLightboxIndex((prev) =>
      prev !== null
        ? (prev - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length
        : null,
    );
  }, []);

  const nextImage = useCallback(() => {
    setLightboxIndex((prev) =>
      prev !== null ? (prev + 1) % GALLERY_IMAGES.length : null,
    );
  }, []);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-3 space-y-3"
      >
        {GALLERY_IMAGES.map((image, index) => (
          <div key={image.id} className="break-inside-avoid">
            <GalleryCard image={image} index={index} onOpen={openLightbox} />
          </div>
        ))}
      </motion.div>

      <GalleryLightbox
        images={GALLERY_IMAGES}
        currentIndex={lightboxIndex}
        onClose={closeLightbox}
        onPrev={prevImage}
        onNext={nextImage}
      />
    </>
  );
}
