"use client";

import Image from "next/image";
import type { GalleryImage } from "@/data/gallery-data";

interface GalleryCardProps {
  image: GalleryImage;
  index: number;
  onOpen: (image: GalleryImage) => void;
}

export function GalleryCard({ image, index, onOpen }: GalleryCardProps) {
  const aspectClass =
    image.span === "tall"
      ? "aspect-[3/4]"
      : image.span === "wide"
        ? "aspect-[4/3]"
        : "aspect-square";

  return (
    <div
      onClick={() => onOpen(image)}
      className={`group relative overflow-hidden rounded-xl cursor-pointer ${aspectClass} bg-[#0a1120] border border-white/5 hover:border-cyan-500/40 transition-colors duration-300 transform-gpu`}
    >
      <Image
        src={image.src}
        alt={image.alt}
        fill
        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 25vw"
        loading={index < 6 ? "eager" : "lazy"}
        priority={index < 3}
        className="object-cover transition-transform duration-500 ease-out group-hover:scale-105 will-change-transform"
      />

      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

      <div className="absolute inset-x-0 bottom-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 ease-out pointer-events-none">
        <span className="inline-block text-[10px] font-mono font-bold tracking-[0.18em] uppercase text-cyan-400 mb-1">
          {image.category}
        </span>
        <p className="text-white text-sm font-semibold leading-snug drop-shadow-md">
          {image.title}
        </p>
      </div>
    </div>
  );
}
