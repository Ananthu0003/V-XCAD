"use client";

import {
  useEffect,
  useCallback,
  useState,
  useRef,
  useSyncExternalStore,
} from "react";
import { createPortal } from "react-dom";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import type { GalleryImage } from "@/data/gallery-data";

interface GalleryLightboxProps {
  images: GalleryImage[];
  currentIndex: number | null;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

const emptySubscribe = () => () => {};

export function GalleryLightbox({
  images,
  currentIndex,
  onClose,
  onPrev,
  onNext,
}: GalleryLightboxProps) {
  const isMounted = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  );
  const [loadedSrc, setLoadedSrc] = useState<string | null>(null);
  const touchStartX = useRef<number | null>(null);

  const isOpen = currentIndex !== null;
  const image = currentIndex !== null ? images[currentIndex] : null;
  const isImageLoading = image ? loadedSrc !== image.src : false;

  // Preload adjacent images for fast transitions
  useEffect(() => {
    if (currentIndex !== null && typeof window !== "undefined") {
      const nextIdx = (currentIndex + 1) % images.length;
      const prevIdx = (currentIndex - 1 + images.length) % images.length;
      const preloadNext = new window.Image();
      preloadNext.src = images[nextIdx].src;
      const preloadPrev = new window.Image();
      preloadPrev.src = images[prevIdx].src;
    }
  }, [currentIndex, images]);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    },
    [onClose, onPrev, onNext],
  );

  useEffect(() => {
    if (isOpen) {
      window.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, handleKeyDown]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diffX = touchStartX.current - e.changedTouches[0].clientX;
    if (Math.abs(diffX) > 50) {
      if (diffX > 0) onNext();
      else onPrev();
    }
    touchStartX.current = null;
  };

  if (!isMounted) return null;

  const content = (
    <AnimatePresence>
      {isOpen && image && (
        <motion.div
          key="lightbox-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[99999] bg-black/95 backdrop-blur-md flex flex-col items-center justify-between pt-6 pb-6 px-4 sm:px-8"
          onClick={onClose}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Top bar: category, counter & close button */}
          <div
            className="w-full max-w-6xl flex items-center justify-between z-20"
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className={`flex items-center gap-2 transition-opacity duration-300 ${isImageLoading ? "opacity-50" : "opacity-100"}`}
            >
              <span className="text-[11px] sm:text-xs font-mono tracking-widest text-cyan-400 bg-cyan-950/80 border border-cyan-500/40 px-3 py-1 rounded-full uppercase">
                {image.category}
              </span>
              <span className="text-xs font-mono text-zinc-400">
                {String((currentIndex ?? 0) + 1).padStart(2, "0")} /{" "}
                {String(images.length).padStart(2, "0")}
              </span>
            </div>

            {/* X Close Button with high contrast and touch-friendly size */}
            <button
              onClick={onClose}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-[#131d2e] hover:bg-[#1e2d48] border border-white/20 text-zinc-100 hover:text-white transition-all duration-200 cursor-pointer shadow-2xl active:scale-90"
              aria-label="Close image"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Center: Enlarged Image, Loader & Nav arrows */}
          <div
            className="relative w-full max-w-6xl flex-1 flex items-center justify-center my-3 min-h-0"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Loading Indicator */}
            {isImageLoading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 z-30 pointer-events-none">
                <div className="relative w-12 h-12 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                  <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
                </div>
                <span className="text-[11px] font-mono text-cyan-400/80 tracking-widest uppercase animate-pulse">
                  Loading...
                </span>
              </div>
            )}

            {/* Previous Arrow */}
            <button
              onClick={onPrev}
              className="absolute left-0 sm:left-2 z-20 w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center rounded-full bg-[#0d1522]/80 hover:bg-cyan-500/20 border border-white/15 hover:border-cyan-400/50 text-white hover:text-cyan-300 transition-all duration-200 backdrop-blur-sm -translate-x-1 sm:translate-x-0 active:scale-95 cursor-pointer shadow-lg"
              aria-label="Previous image"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Image */}
            <div className="relative w-full h-full max-h-[72vh] sm:max-h-[78vh] flex items-center justify-center">
              <Image
                key={image.src}
                src={image.src}
                alt={image.alt}
                fill
                unoptimized
                className={`object-contain select-none transition-all duration-300 ease-out ${
                  isImageLoading
                    ? "opacity-0 scale-[0.98]"
                    : "opacity-100 scale-100"
                }`}
                priority
                sizes="(max-width: 1280px) 95vw, 1200px"
                onLoad={() => setLoadedSrc(image.src)}
              />
            </div>

            {/* Next Arrow */}
            <button
              onClick={onNext}
              className="absolute right-0 sm:right-2 z-20 w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center rounded-full bg-[#0d1522]/80 hover:bg-cyan-500/20 border border-white/15 hover:border-cyan-400/50 text-white hover:text-cyan-300 transition-all duration-200 backdrop-blur-sm translate-x-1 sm:translate-x-0 active:scale-95 cursor-pointer shadow-lg"
              aria-label="Next image"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Bottom bar: Title */}
          <div
            className="w-full max-w-6xl text-center py-1 z-10"
            onClick={(e) => e.stopPropagation()}
          >
            <h3
              className={`text-sm sm:text-base font-semibold text-white tracking-wide transition-opacity duration-300 ${isImageLoading ? "opacity-40" : "opacity-100"}`}
            >
              {image.title}
            </h3>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  return createPortal(content, document.body);
}
