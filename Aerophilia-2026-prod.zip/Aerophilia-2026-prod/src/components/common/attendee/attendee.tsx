"use client";

import { useState, useRef, useEffect, ChangeEvent } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Download, User, X } from "lucide-react";
import { toPng } from "html-to-image";
import Image from "next/image";

const CARD_W = 480;
const CARD_H = 640;

const STARS = Array.from({ length: 55 }, (_, i) => ({
  id: i,
  top: ((i * 137.5) % 100).toFixed(2),
  left: ((i * 97.3) % 100).toFixed(2),
  size: ((i % 3) * 0.6 + 0.6).toFixed(1),
  opacity: ((i % 5) * 0.12 + 0.2).toFixed(2),
}));

function RocketDiagram() {
  return (
    <svg width="90" height="130" viewBox="0 0 90 130" fill="none">
      <path
        d="M45 10 C30 10 22 30 22 55 L22 85 L45 95 L68 85 L68 55 C68 30 60 10 45 10Z"
        fill="none"
        stroke="rgba(6,182,212,0.55)"
        strokeWidth="1.2"
      />
      <path
        d="M45 10 C38 10 34 4 45 0 C56 4 52 10 45 10Z"
        fill="rgba(6,182,212,0.18)"
        stroke="rgba(6,182,212,0.5)"
        strokeWidth="1"
      />
      <circle
        cx="45"
        cy="45"
        r="9"
        fill="none"
        stroke="rgba(6,182,212,0.45)"
        strokeWidth="1.2"
      />
      <circle
        cx="45"
        cy="45"
        r="5"
        fill="rgba(6,182,212,0.12)"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="0.8"
      />
      <path
        d="M22 75 L8 92 L22 88Z"
        fill="rgba(99,102,241,0.2)"
        stroke="rgba(99,102,241,0.5)"
        strokeWidth="1"
      />
      <path
        d="M68 75 L82 92 L68 88Z"
        fill="rgba(99,102,241,0.2)"
        stroke="rgba(99,102,241,0.5)"
        strokeWidth="1"
      />
      <path
        d="M33 85 L28 100 L45 96 L62 100 L57 85Z"
        fill="none"
        stroke="rgba(6,182,212,0.35)"
        strokeWidth="1"
      />
      <path
        d="M38 100 C38 115 45 122 45 122 C45 122 52 115 52 100Z"
        fill="rgba(99,102,241,0.25)"
        stroke="rgba(139,92,246,0.5)"
        strokeWidth="0.8"
      />
      <path
        d="M41 100 C41 112 45 118 45 118 C45 118 49 112 49 100Z"
        fill="rgba(6,182,212,0.2)"
      />
      <line
        x1="22"
        y1="65"
        x2="68"
        y2="65"
        stroke="rgba(6,182,212,0.2)"
        strokeWidth="0.8"
        strokeDasharray="3 2"
      />
      <line
        x1="28"
        y1="75"
        x2="62"
        y2="75"
        stroke="rgba(6,182,212,0.15)"
        strokeWidth="0.8"
        strokeDasharray="3 2"
      />
    </svg>
  );
}

function CodeDiagram() {
  return (
    <svg width="120" height="90" viewBox="0 0 120 90" fill="none">
      <rect
        x="2"
        y="2"
        width="116"
        height="86"
        rx="6"
        fill="none"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="1"
      />
      <rect
        x="2"
        y="2"
        width="116"
        height="16"
        rx="6"
        fill="rgba(6,182,212,0.07)"
      />
      <rect x="2" y="12" width="116" height="6" fill="rgba(6,182,212,0.07)" />
      <circle cx="12" cy="10" r="3" fill="rgba(239,68,68,0.5)" />
      <circle cx="22" cy="10" r="3" fill="rgba(234,179,8,0.5)" />
      <circle cx="32" cy="10" r="3" fill="rgba(34,197,94,0.5)" />
      <text
        x="10"
        y="33"
        fontFamily="monospace"
        fontSize="7"
        fill="rgba(139,92,246,0.7)"
      >
        &gt;_
      </text>
      <rect
        x="22"
        y="26"
        width="40"
        height="5"
        rx="1"
        fill="rgba(6,182,212,0.2)"
      />
      <rect
        x="65"
        y="26"
        width="20"
        height="5"
        rx="1"
        fill="rgba(99,102,241,0.2)"
      />
      <text
        x="10"
        y="47"
        fontFamily="monospace"
        fontSize="7"
        fill="rgba(6,182,212,0.5)"
      >
        if
      </text>
      <rect
        x="22"
        y="40"
        width="28"
        height="5"
        rx="1"
        fill="rgba(6,182,212,0.15)"
      />
      <rect
        x="53"
        y="40"
        width="15"
        height="5"
        rx="1"
        fill="rgba(139,92,246,0.2)"
      />
      <rect
        x="22"
        y="49"
        width="50"
        height="5"
        rx="1"
        fill="rgba(99,102,241,0.15)"
      />
      <rect
        x="10"
        y="58"
        width="30"
        height="5"
        rx="1"
        fill="rgba(6,182,212,0.1)"
      />
      <rect
        x="43"
        y="58"
        width="22"
        height="5"
        rx="1"
        fill="rgba(99,102,241,0.15)"
      />
      <rect
        x="10"
        y="67"
        width="55"
        height="5"
        rx="1"
        fill="rgba(139,92,246,0.12)"
      />
      <rect
        x="68"
        y="67"
        width="5"
        height="5"
        rx="1"
        fill="rgba(6,182,212,0.55)"
      />
      <text
        x="88"
        y="55"
        fontFamily="monospace"
        fontSize="18"
        fill="rgba(6,182,212,0.2)"
        fontWeight="bold"
      >
        &#123;
      </text>
      <text
        x="98"
        y="80"
        fontFamily="monospace"
        fontSize="18"
        fill="rgba(99,102,241,0.2)"
        fontWeight="bold"
      >
        &#125;
      </text>
    </svg>
  );
}

function RobotDiagram() {
  return (
    <svg width="80" height="110" viewBox="0 0 80 110" fill="none">
      <line
        x1="40"
        y1="8"
        x2="40"
        y2="18"
        stroke="rgba(6,182,212,0.5)"
        strokeWidth="1.2"
      />
      <circle
        cx="40"
        cy="6"
        r="3"
        fill="none"
        stroke="rgba(6,182,212,0.6)"
        strokeWidth="1"
      />
      <rect
        x="22"
        y="18"
        width="36"
        height="28"
        rx="6"
        fill="none"
        stroke="rgba(6,182,212,0.5)"
        strokeWidth="1.2"
      />
      <rect
        x="28"
        y="26"
        width="8"
        height="6"
        rx="2"
        fill="rgba(6,182,212,0.25)"
        stroke="rgba(6,182,212,0.6)"
        strokeWidth="0.8"
      />
      <rect
        x="44"
        y="26"
        width="8"
        height="6"
        rx="2"
        fill="rgba(6,182,212,0.25)"
        stroke="rgba(6,182,212,0.6)"
        strokeWidth="0.8"
      />
      <rect
        x="30"
        y="28"
        width="4"
        height="2"
        rx="1"
        fill="rgba(6,182,212,0.7)"
      />
      <rect
        x="46"
        y="28"
        width="4"
        height="2"
        rx="1"
        fill="rgba(6,182,212,0.7)"
      />
      <rect
        x="30"
        y="37"
        width="20"
        height="4"
        rx="2"
        fill="none"
        stroke="rgba(99,102,241,0.4)"
        strokeWidth="0.8"
      />
      <rect
        x="33"
        y="38"
        width="4"
        height="2"
        rx="1"
        fill="rgba(99,102,241,0.4)"
      />
      <rect
        x="39"
        y="38"
        width="4"
        height="2"
        rx="1"
        fill="rgba(99,102,241,0.4)"
      />
      <rect
        x="36"
        y="46"
        width="8"
        height="6"
        rx="1"
        fill="none"
        stroke="rgba(6,182,212,0.35)"
        strokeWidth="1"
      />
      <rect
        x="18"
        y="52"
        width="44"
        height="32"
        rx="5"
        fill="none"
        stroke="rgba(99,102,241,0.5)"
        strokeWidth="1.2"
      />
      <rect
        x="26"
        y="58"
        width="28"
        height="18"
        rx="3"
        fill="none"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="0.8"
      />
      <circle
        cx="32"
        cy="65"
        r="3"
        fill="none"
        stroke="rgba(6,182,212,0.5)"
        strokeWidth="0.8"
      />
      <circle
        cx="40"
        cy="65"
        r="3"
        fill="rgba(6,182,212,0.2)"
        stroke="rgba(6,182,212,0.5)"
        strokeWidth="0.8"
      />
      <circle
        cx="48"
        cy="65"
        r="3"
        fill="none"
        stroke="rgba(99,102,241,0.5)"
        strokeWidth="0.8"
      />
      <rect
        x="4"
        y="54"
        width="14"
        height="8"
        rx="3"
        fill="none"
        stroke="rgba(6,182,212,0.35)"
        strokeWidth="1"
      />
      <rect
        x="2"
        y="62"
        width="12"
        height="14"
        rx="3"
        fill="none"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="1"
      />
      <rect
        x="62"
        y="54"
        width="14"
        height="8"
        rx="3"
        fill="none"
        stroke="rgba(6,182,212,0.35)"
        strokeWidth="1"
      />
      <rect
        x="66"
        y="62"
        width="12"
        height="14"
        rx="3"
        fill="none"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="1"
      />
      <rect
        x="24"
        y="84"
        width="12"
        height="20"
        rx="3"
        fill="none"
        stroke="rgba(99,102,241,0.4)"
        strokeWidth="1"
      />
      <rect
        x="44"
        y="84"
        width="12"
        height="20"
        rx="3"
        fill="none"
        stroke="rgba(99,102,241,0.4)"
        strokeWidth="1"
      />
      <rect
        x="22"
        y="100"
        width="16"
        height="8"
        rx="2"
        fill="none"
        stroke="rgba(99,102,241,0.3)"
        strokeWidth="0.8"
      />
      <rect
        x="42"
        y="100"
        width="16"
        height="8"
        rx="2"
        fill="none"
        stroke="rgba(99,102,241,0.3)"
        strokeWidth="0.8"
      />
    </svg>
  );
}

function CircuitTraceSVG() {
  return (
    <svg width="180" height="180" viewBox="0 0 180 180" fill="none">
      <line
        x1="0"
        y1="40"
        x2="50"
        y2="40"
        stroke="rgba(6,182,212,0.22)"
        strokeWidth="1"
      />
      <line
        x1="50"
        y1="40"
        x2="50"
        y2="80"
        stroke="rgba(6,182,212,0.22)"
        strokeWidth="1"
      />
      <line
        x1="50"
        y1="80"
        x2="110"
        y2="80"
        stroke="rgba(6,182,212,0.22)"
        strokeWidth="1"
      />
      <line
        x1="110"
        y1="80"
        x2="110"
        y2="40"
        stroke="rgba(6,182,212,0.18)"
        strokeWidth="1"
      />
      <line
        x1="110"
        y1="40"
        x2="180"
        y2="40"
        stroke="rgba(6,182,212,0.18)"
        strokeWidth="1"
      />
      <line
        x1="25"
        y1="0"
        x2="25"
        y2="40"
        stroke="rgba(99,102,241,0.2)"
        strokeWidth="1"
      />
      <line
        x1="80"
        y1="80"
        x2="80"
        y2="130"
        stroke="rgba(99,102,241,0.18)"
        strokeWidth="1"
      />
      <line
        x1="80"
        y1="130"
        x2="150"
        y2="130"
        stroke="rgba(99,102,241,0.18)"
        strokeWidth="1"
      />
      <line
        x1="150"
        y1="130"
        x2="150"
        y2="180"
        stroke="rgba(99,102,241,0.15)"
        strokeWidth="1"
      />
      <circle cx="50" cy="40" r="3" fill="rgba(6,182,212,0.4)" />
      <circle cx="110" cy="80" r="3" fill="rgba(6,182,212,0.4)" />
      <circle cx="25" cy="40" r="2" fill="rgba(99,102,241,0.45)" />
      <circle cx="80" cy="130" r="3" fill="rgba(99,102,241,0.4)" />
      <circle cx="150" cy="130" r="2" fill="rgba(139,92,246,0.4)" />
      <rect
        x="46"
        y="36"
        width="8"
        height="8"
        rx="1"
        fill="none"
        stroke="rgba(6,182,212,0.3)"
        strokeWidth="0.8"
      />
      <rect
        x="106"
        y="76"
        width="8"
        height="8"
        rx="1"
        fill="none"
        stroke="rgba(6,182,212,0.28)"
        strokeWidth="0.8"
      />
      <rect
        x="76"
        y="126"
        width="8"
        height="8"
        rx="1"
        fill="none"
        stroke="rgba(99,102,241,0.3)"
        strokeWidth="0.8"
      />
    </svg>
  );
}

export default function AttendeeCard() {
  const [name, setName] = useState<string>("");
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [cardScale, setCardScale] = useState<number>(1);

  const cardRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function updateScale() {
      if (!wrapperRef.current) return;
      const available = wrapperRef.current.clientWidth;
      const scale = Math.min(1, available / CARD_W);
      setCardScale(scale);
    }
    updateScale();
    window.addEventListener("resize", updateScale);
    return () => window.removeEventListener("resize", updateScale);
  }, []);

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImageSrc(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImageSrc(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleDownload = async () => {
    if (!cardRef.current || !name.trim()) return;
    try {
      const dataUrl = await toPng(cardRef.current, {
        cacheBust: true,
        includeQueryParams: true,
        skipFonts: true,
        pixelRatio: 3,
        width: CARD_W,
        height: CARD_H,
        backgroundColor: "#020c1b",
        style: { borderRadius: "0", transform: "none" },
      });
      const link = document.createElement("a");
      link.download = `${name.trim().replaceAll(" ", "-").toLowerCase()}-aerophilia-2026-pass.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error("Failed to generate image:", err);
    }
  };

  const getInitials = (fullName: string): string => {
    const trimmed = fullName.trim();
    if (!trimmed) return "A";
    return trimmed
      .split(" ")
      .filter(Boolean)
      .map((n) => n[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();
  };

  const bgOpacity = imageSrc ? 0.35 : 1;

  return (
    <div className="w-full max-w-5xl mx-auto px-4 flex flex-col md:grid md:grid-cols-2 gap-8 md:gap-10 items-start">
      {/* Form panel */}
      <div className="w-full rounded-2xl border border-cyan-500/20 bg-[#050d1a]/80 backdrop-blur-md p-6 sm:p-7 shadow-[0_0_40px_rgba(6,182,212,0.08)] space-y-5 sm:space-y-6 mt-8">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <User className="h-4 w-4 text-cyan-400" />
          </div>
          <h2 className="text-xs sm:text-sm font-bold tracking-widest uppercase text-cyan-400">
            Attendee Information
          </h2>
        </div>

        <div className="space-y-2">
          <Label
            htmlFor="attendee-name"
            className="text-xs tracking-widest uppercase text-zinc-400 font-semibold"
          >
            Full Name
          </Label>
          <Input
            id="attendee-name"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="bg-[#0a1628] border-cyan-500/20 text-white placeholder:text-zinc-600 focus-visible:ring-cyan-500/40 focus-visible:border-cyan-500/50"
          />
        </div>

        <div className="space-y-2">
          <Label
            htmlFor="attendee-photo"
            className="text-xs tracking-widest uppercase text-zinc-400 font-semibold"
          >
            Profile Picture
          </Label>
          <div className="flex gap-2">
            <label
              htmlFor="attendee-photo"
              className="flex-1 flex items-center gap-2 sm:gap-3 cursor-pointer rounded-lg border border-cyan-500/20 bg-[#0a1628] px-3 sm:px-4 py-2.5 text-sm text-zinc-400 hover:border-cyan-500/40 transition-colors min-w-0"
            >
              <span className="text-xs font-bold tracking-widest uppercase text-cyan-400 border border-cyan-500/40 rounded px-2 py-0.5 shrink-0">
                Choose File
              </span>
              <span className="truncate text-xs">
                {imageSrc ? "Photo selected" : "No file chosen"}
              </span>
              <input
                id="attendee-photo"
                type="file"
                accept="image/*"
                ref={fileInputRef}
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
            {imageSrc && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleRemoveImage}
                className="border-red-500/30 hover:border-red-500/50 hover:bg-red-500/10 text-red-400 shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        <Button
          onClick={handleDownload}
          disabled={!name.trim() || !imageSrc}
          className="w-full gap-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold tracking-widest uppercase text-xs h-11 shadow-[0_0_20px_rgba(6,182,212,0.25)] disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          <Download className="h-4 w-4" />
          Download Pass
        </Button>

        <div className="mt-2 text-center text-xs font-medium text-slate-400">
          {!name.trim() && !imageSrc && (
            <span className="text-amber-400">
              Please provide a name and upload an image
            </span>
          )}
          {!name.trim() && imageSrc && (
            <span className="text-amber-400">Please enter a valid name</span>
          )}
          {name.trim() && !imageSrc && (
            <span className="text-amber-400">
              Please upload an image for the pass
            </span>
          )}
          {name.trim() && imageSrc && (
            <span className="text-green-400">
              Download the attendee pass and share it across socials
            </span>
          )}
        </div>
      </div>

      {/* Card preview */}
      <div className="w-full flex flex-col items-center gap-3 sm:gap-4">
        <Label className="self-start font-bold text-zinc-500 uppercase tracking-widest text-xs">
          Live Card Preview
        </Label>

        {/* Scaling wrapper — reserves exact scaled height so page doesn't collapse */}
        <div
          ref={wrapperRef}
          className="w-full"
          style={{ height: CARD_H * cardScale }}
        >
          <div
            style={{
              width: CARD_W,
              height: CARD_H,
              transformOrigin: "top left",
              transform: `scale(${cardScale})`,
            }}
          >
            <div
              ref={cardRef}
              style={{
                width: CARD_W,
                height: CARD_H,
                background: "#020c1b",
                position: "relative",
                overflow: "hidden",
                borderRadius: "24px",
              }}
              className="shadow-[0_0_80px_rgba(6,182,212,0.3),0_0_160px_rgba(99,102,241,0.2)] border border-cyan-500/30"
            >
              {/* Base gradient */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "linear-gradient(155deg, #010a18 0%, #030e24 35%, #05091a 65%, #010710 100%)",
                  zIndex: 0,
                }}
              />

              {/* Ambient blobs */}
              <div
                style={{
                  position: "absolute",
                  top: "-60px",
                  left: "-60px",
                  width: "280px",
                  height: "280px",
                  borderRadius: "50%",
                  background:
                    "radial-gradient(circle, rgba(6,182,212,0.13) 0%, transparent 70%)",
                  filter: "blur(40px)",
                  zIndex: 1,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  bottom: "-40px",
                  right: "-40px",
                  width: "260px",
                  height: "260px",
                  borderRadius: "50%",
                  background:
                    "radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%)",
                  filter: "blur(40px)",
                  zIndex: 1,
                }}
              />

              {/* Stars */}
              {!imageSrc && (
                <div style={{ position: "absolute", inset: 0, zIndex: 2 }}>
                  {STARS.map((s) => (
                    <div
                      key={s.id}
                      style={{
                        position: "absolute",
                        top: `${s.top}%`,
                        left: `${s.left}%`,
                        width: `${s.size}px`,
                        height: `${s.size}px`,
                        borderRadius: "50%",
                        background: "#fff",
                        opacity: Number(s.opacity),
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Moon — full width rising from bottom */}
              <div
                style={{
                  position: "absolute",
                  bottom: "-60px",
                  left: "50%",
                  transform: "translateX(-50%)",
                  width: "520px",
                  height: "520px",
                  opacity: imageSrc ? 0.12 : 0.28,
                  zIndex: 3,
                }}
              >
                <Image
                  src="/assets/images/moon.png"
                  alt=""
                  fill
                  className="object-contain"
                  sizes="520px"
                  priority
                />
              </div>

              {/* Rocket — left side */}
              <div
                style={{
                  position: "absolute",
                  left: "-10px",
                  top: "120px",
                  zIndex: 3,
                  opacity: bgOpacity * 0.65,
                }}
              >
                <RocketDiagram />
              </div>

              {/* Code terminal — right side */}
              <div
                style={{
                  position: "absolute",
                  right: "-8px",
                  top: "140px",
                  zIndex: 3,
                  opacity: bgOpacity * 0.6,
                }}
              >
                <CodeDiagram />
              </div>

              {/* Robot — center bottom background */}
              <div
                style={{
                  position: "absolute",
                  left: "50%",
                  transform: "translateX(-50%)",
                  bottom: "120px",
                  zIndex: 3,
                  opacity: bgOpacity * 0.55,
                }}
              >
                <RobotDiagram />
              </div>

              {/* Circuit traces — bottom-left */}
              <div
                style={{
                  position: "absolute",
                  bottom: "60px",
                  left: "-8px",
                  zIndex: 3,
                  opacity: bgOpacity * 0.7,
                }}
              >
                <CircuitTraceSVG />
              </div>

              {/* Circuit traces — top-right, flipped */}
              <div
                style={{
                  position: "absolute",
                  top: "50px",
                  right: "-8px",
                  zIndex: 3,
                  transform: "rotate(180deg)",
                  opacity: bgOpacity * 0.6,
                }}
              >
                <CircuitTraceSVG />
              </div>

              {/* Photo layer */}
              {imageSrc && (
                <div style={{ position: "absolute", inset: 0, zIndex: 4 }}>
                  <img
                    src={imageSrc}
                    alt={name || "Attendee"}
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      objectPosition: "center top",
                      display: "block",
                    }}
                    crossOrigin="anonymous"
                  />
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      background:
                        "linear-gradient(to bottom, rgba(1,8,18,0.42) 0%, rgba(1,8,18,0.08) 18%, rgba(1,8,18,0.04) 38%, rgba(1,8,18,0.18) 55%, rgba(1,8,18,0.78) 72%, rgba(1,8,18,0.97) 88%, rgba(1,8,18,1) 100%)",
                    }}
                  />
                </div>
              )}

              {/* Initials fallback */}
              {!imageSrc && (
                <div
                  style={{
                    position: "absolute",
                    inset: 0,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 5,
                  }}
                >
                  <div
                    style={{
                      width: "88px",
                      height: "88px",
                      borderRadius: "50%",
                      background:
                        "linear-gradient(135deg, rgba(6,182,212,0.12), rgba(99,102,241,0.14))",
                      border: "1.5px solid rgba(6,182,212,0.3)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      boxShadow: "0 0 24px rgba(6,182,212,0.2)",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "30px",
                        fontWeight: 800,
                        color: "#67e8f9",
                        fontFamily: "sans-serif",
                      }}
                    >
                      {getInitials(name)}
                    </span>
                  </div>
                </div>
              )}

              {/* Bottom fade */}
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: "200px",
                  background:
                    "linear-gradient(to top, rgba(1,8,18,0.98) 0%, rgba(2,10,22,0.88) 50%, transparent 100%)",
                  zIndex: 5,
                }}
              />

              {/* Border accents */}
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "2px",
                  background:
                    "linear-gradient(90deg, transparent, rgba(6,182,212,0.9) 30%, rgba(139,92,246,0.9) 70%, transparent)",
                  zIndex: 10,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: "1px",
                  background:
                    "linear-gradient(90deg, transparent, rgba(99,102,241,0.5), transparent)",
                  zIndex: 10,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  bottom: 0,
                  width: "1px",
                  background:
                    "linear-gradient(to bottom, rgba(6,182,212,0.4), transparent 40%, transparent 60%, rgba(99,102,241,0.3))",
                  zIndex: 10,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  right: 0,
                  bottom: 0,
                  width: "1px",
                  background:
                    "linear-gradient(to bottom, rgba(99,102,241,0.4), transparent 40%, transparent 60%, rgba(6,182,212,0.3))",
                  zIndex: 10,
                }}
              />

              {/* UI content */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  flexDirection: "column",
                  padding: "24px",
                  zIndex: 10,
                }}
              >
                {/* Header */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    <div
                      style={{
                        width: "30px",
                        height: "30px",
                        position: "relative",
                      }}
                    >
                      <Image
                        src="/assets/logos/alogo.svg"
                        alt="Aerophilia"
                        fill
                        className="object-contain"
                        sizes="30px"
                      />
                    </div>
                    <div
                      style={{
                        width: "88px",
                        height: "20px",
                        position: "relative",
                      }}
                    >
                      <Image
                        src="/assets/logos/aerophilia-logo.svg"
                        alt="Aerophilia 2026"
                        fill
                        className="object-contain object-left"
                        sizes="88px"
                      />
                    </div>
                  </div>
                  <div
                    style={{
                      padding: "4px 10px",
                      borderRadius: "20px",
                      border: "1px solid rgba(6,182,212,0.4)",
                      background: "rgba(6,182,212,0.1)",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "8px",
                        fontWeight: 700,
                        letterSpacing: "2.5px",
                        color: "#67e8f9",
                        fontFamily: "monospace",
                      }}
                    >
                      ATTENDEE PASS
                    </span>
                  </div>
                </div>

                <div style={{ flex: 1 }} />

                {/* Name block */}
                <div
                  style={{
                    textAlign: "center",
                    lineHeight: 1,
                    paddingBottom: "16px",
                  }}
                >
                  <p
                    style={{
                      fontSize: "10px",
                      fontWeight: 700,
                      letterSpacing: "3px",
                      color: "#06b6d4",
                      textTransform: "uppercase",
                      fontFamily: "sans-serif",
                      marginBottom: "8px",
                    }}
                  >
                    I AM ATTENDING
                  </p>
                  <h3
                    style={{
                      fontSize:
                        name.trim().length > 18
                          ? "20px"
                          : name.trim().length > 12
                            ? "24px"
                            : "28px",
                      fontWeight: 800,
                      color: "#ffffff",
                      fontFamily: "sans-serif",
                      letterSpacing: "-0.5px",
                      textShadow: "0 0 20px rgba(6,182,212,0.5)",
                      marginBottom: "6px",
                    }}
                  >
                    {name.trim() || "Attendee Name"}
                  </h3>
                  <p
                    style={{
                      fontSize: "11px",
                      color: "#94a3b8",
                      fontWeight: 600,
                      letterSpacing: "2px",
                      textTransform: "uppercase",
                      fontFamily: "sans-serif",
                    }}
                  >
                    Participant
                  </p>
                </div>

                {/* Footer */}
                <div
                  style={{
                    borderTop: "1px solid rgba(6,182,212,0.15)",
                    paddingTop: "14px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                    }}
                  >
                    <div
                      style={{
                        width: "34px",
                        height: "18px",
                        position: "relative",
                        opacity: 0.85,
                      }}
                    >
                      <Image
                        src="/assets/logos/sahyadri-logo.webp"
                        alt="Sahyadri"
                        fill
                        className="object-contain object-left"
                        sizes="34px"
                      />
                    </div>
                    <div
                      style={{
                        width: "1px",
                        height: "16px",
                        background: "rgba(6,182,212,0.2)",
                      }}
                    />
                    <div
                      style={{
                        width: "38px",
                        height: "18px",
                        position: "relative",
                        opacity: 0.85,
                      }}
                    >
                      <Image
                        src="/assets/logos/synergia-logo.webp"
                        alt="Synergia"
                        fill
                        className="object-contain object-left"
                        sizes="38px"
                      />
                    </div>
                    <div
                      style={{
                        width: "1px",
                        height: "16px",
                        background: "rgba(6,182,212,0.2)",
                      }}
                    />
                    <div
                      style={{
                        width: "50px",
                        height: "18px",
                        position: "relative",
                        opacity: 0.85,
                      }}
                    >
                      <Image
                        src="/assets/logos/challengers-logo.webp"
                        alt="Challengers"
                        fill
                        className="object-contain object-left"
                        sizes="50px"
                      />
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <p
                      className="uppercase"
                      style={{
                        fontSize: "7.5px",
                        color: "#475569",
                        letterSpacing: "1.5px",
                        textTransform: "uppercase",
                        fontFamily: "monospace",
                      }}
                    >
                      Aerophilia 2026
                    </p>
                    <p
                      className="uppercase"
                      style={{
                        fontSize: "7px",
                        color: "#334155",
                        letterSpacing: "1px",
                        fontFamily: "monospace",
                        marginTop: "2px",
                      }}
                    >
                      Team Challengers
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
