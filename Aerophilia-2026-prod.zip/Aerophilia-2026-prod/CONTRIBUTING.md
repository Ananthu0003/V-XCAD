# Official Repository - Aerophilia 2026

## Basic Instructions

## Project Contribution & Style Guide

Welcome to the project! To keep our codebase maintainable, scalable, and readable, please adhere to the following guidelines when contributing to this Next.js project.

---

## Note:

1. Please place all the ts-interfaces in the types folder
2. Please add all the static data in the data folder with the folder of the page
3. Add all the images or media in `webp format`

## Folder Structure

We follow a **component/feature-based** modular structure. High-level organization is as follows:

```text
public/
├── assets
    ├── Folder wise images
src/
├── app/              # Next.js App Router (Pages, Layouts, APIs)
├── components/       # Shared UI components - Footer, Navbar etc
│   ├── ui/           # Shadcn/ Other library Components
│   └── common/       # Project-specific reusable components
├── hooks/            # Custom React hooks
├── lib/
├── services/         # API fetching logic and business layer
├── store/            # State management (Redux/Zustand/Tanstack)
├── types/            # TypeScript interfaces and types
└── utils/            # Helper functions like formatting , etc to be reused
```

## Proposed Website Design for the website

```bash
https://www.figma.com/design/WQTD6X4U78mJsYpPmDIrza/Aerophilia-26?node-id=0-1&p=f&t=nkI2Jd3RLhmlctLY-0
```

`Note: This is just a initial design, further improvements can be made while developing the website`

## General Instructions

1. Please follow the folder structure correctly
2. Each piece of code has to be written to maximise its usage in other places - i.e reusable code
3. Please follow the naming conventions for files and folders - `Kebab Case`(Ex: `Team-Profile.tsx`).`Avoid` usage of `snake case(team_profile.tsx)` or `camel case(teamProfile.tsx)`
4. Create a fork in to your github account commit changes and create a PR with the changes made with proper explaination about it to the `beta` banch
5. Also be updated with the current main branch code to avoid merge conflicts. Also `pull your code from main branch` before pushing or a raising a PR.
6. Also maintain readable code with proper comments and also proper variable names like team_memebers unlike x,y or z as variable names

## Tech Stack Used

1. React 19.0 With TypeScript
2. We are using `pnpm` as the `primary package manager` for the project
3. Tailwind CSS and Shadcn Components
4. App-Router and Src Directory is also used
5. All the Shadcn components can be added using command
6. ThreeJS, HeroIcons ,or material UI, Spline , Framer Motion can be used for components or 3D Behaviour

```
pnpm dlx shadcn@latest add component-name
```

5. It will be added to the components/ui folder and also it can be customised - variants, props etc

6. Finally the figma link to the project is attached below. You can refer to it for design and also modify it as per needed.
7. Keep the `mobile-first approach` in mind
8. For any doubts or help you can reach out to [Tharun](https://github.com/tharunrai), [Naren](https://github.com/Naren1520) or [me](https://github.com/Pranava-Pai-N) anytime
9. Never push .env to production
10. Project Deadline is `15-08-2026` to `25-08-2026`
11. All Images and logos will be provided by the `media team`
12. You can view the previous years website here

```bash
https://aerophilia.space
```

## Note : `PNPM Basics`

1. Installing a package or library

- Normal Package

```bash
pnpm add package-name
```

- As a Dev-Dependency

```bash
pnpm add -D package-name
```

2. Uninstalling a package or library

```bash
pnpm remove package-name
```

3. Adding Shadcn Components

```bash
pnpm dlx shadcn@latest add component-name
```

4. Downgrading a package or library due to dependency hell

```bash
pnpm add package-name@~version
```

`or`

```bash
pnpm add -D package-name@~version
```

## Contribution Guidelines

1. This is the beta branch - Please PR to this branch only
2. `Fork` the repository to your account and keep it `private`
3. Go to the folder

````
cd aerophilia
```bash
4. Install All Dependencies
```bash
pnpm install
````

5. Run the local development server

```bash
pnpm dev
```

6. Open the website in the browser via

```bash
http://localhost:3000
```

7. Add changes to the project,check for existing changes in main branch keep your code updated with main branch
8. Please pass all the type safety check and linting before pushing code to your branch

- Typecheck

```bash
pnpm typecheck
```

- Linting

```bash
pnpm lint
```

8. Create a PR with the proper feature name and changes to the beta branch `only after passing` the `linting` and `typecheck stages`. Add `suitable images` or `screen-recordings` to highlight the changes done in the `comment of the PR Raised`
9. Please strictly follow the `PR Request Template` while raising the PR available at [PR Template](./.github/pull_request_template.md)
10. Your PR will be checked and merged (`if no errors`) to prod within 24-36 hours

### Thank You
