# Aerophilia 2026

> The official website for Sahyadri's national aerospace and technology fest.

Aerophilia 2026 is a student-led festival experience by **Team Challengers, Sahyadri College of Engineering & Management**. The website brings the event programme, registration flows, gallery, timeline, FAQs, attendee pass generator, and contact information together in one responsive experience.

## Highlights

- Explore and search technical, aerospace, drone, workshop, and non-technical events.
- View event details, schedules, venues, team-size requirements, and coordinators.
- Register participants for supported workshops and events.
- Browse the Aerophilia gallery and event timeline.
- Generate a shareable attendee pass.
- Find the organising team, venue, FAQs, contact details, privacy policy, and terms.
- Responsive, mobile-first interface with animated interactions and a futuristic visual system.

## Technology Stack

| Area                      | Technology                                            |
| ------------------------- | ----------------------------------------------------- |
| Framework                 | Next.js 16 with the App Router and `src` directory    |
| Language                  | TypeScript                                            |
| UI                        | React 19, Tailwind CSS 4, shadcn/ui patterns, Base UI |
| Animation and interaction | Framer Motion, GSAP, Lenis                            |
| Visual effects            | tsParticles, Next Image                               |
| Icons and notifications   | Lucide React, Sonner                                  |
| Data and validation       | Zod                                                   |
| Backend services          | Firebase Admin SDK and Firestore                      |
| Package manager           | pnpm                                                  |
| Code quality              | ESLint, TypeScript, Prettier, Husky                   |

## Main Frontend Routes

| Route                          | Purpose                                           |
| ------------------------------ | ------------------------------------------------- |
| `/`                            | Festival overview, highlights, FAQs, and timeline |
| `/about`                       | About Aerophilia and the organising community     |
| `/events`                      | Searchable and filterable event catalogue         |
| `/events/[eventName]`          | Event details and participation information       |
| `/events/[eventName]/register` | Workshop registration form                        |
| `/gallery`                     | Event media gallery                               |
| `/timeline`                    | Festival timeline and milestones                  |
| `/participant`                 | Attendee pass generator                           |
| `/team`                        | Team Challengers members                          |
| `/contact`                     | Contact information, FAQs, and location           |
| `/privacy`                     | Privacy policy                                    |
| `/terms`                       | Terms and conditions                              |

## Getting Started

### Prerequisites

- Node.js 20 or later
- pnpm 10 or later
- Access to the Firebase project used by the deployment, when working on registration or server-side data features

### Installation

1. Clone the repository and install the required dependencies

```bash
git clone https://github.com/Pranava-Pai-N/Aerophilia-2026.git
cd Aerophilia-2026
pnpm install
```

2. Create a local environment file from the supplied template:

```bash
cp .env.example .env
```

Add the required Firebase and application values to `.env.local`:

Keep `.env.local` or `.env` private. Never commit credentials, service-account keys, or production secrets.

### Run locally

```bash
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Available Scripts

| Command          | Description                                     |
| ---------------- | ----------------------------------------------- |
| `pnpm dev`       | Start the Next.js development server            |
| `pnpm build`     | Create a production build                       |
| `pnpm start`     | Serve the production build                      |
| `pnpm lint`      | Run ESLint                                      |
| `pnpm typecheck` | Run TypeScript without emitting files           |
| `pnpm pretty`    | Format supported source and documentation files |
| `pnpm sweep`     | Run the repository cleanup utility              |
| `pnpm prepare`   | Initialise Husky hooks                          |

Before opening a pull request, run:

```bash
pnpm lint
pnpm typecheck
pnpm build
```

## Contribution Workflow

1. Fork the private repository and create a focused feature branch.
2. Keep your branch up to date with `prod` before opening a pull request.
3. Follow the project conventions in [`CONTRIBUTING.md`](./CONTRIBUTING.md).
4. Keep shared interfaces in `src/types`, static page data in `src/data`, and media in `public/assets`.
5. Use reusable components and preserve the mobile-first responsive behaviour.
6. Do not commit `.env` files or any secrets.
7. Run linting, typechecking, and the production build locally.
8. Open the pull request against the `beta` branch and describe the change as given by the [PR Template](./.github/pull_request_template.md), validation performed, and any relevant screenshots or recordings.

## Ownership

| Responsibility       | Owner                                                                                                                                  |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Repository           | [Team Challengers - Aerophilia 2026](https://github.com/Pranava-Pai-N/Aerophilia-2026)                                                 |
| Copyright holder     | Team Challengers Sahyadri                                                                                                              |
| Project maintainer   | [Pranava Pai](https://github.com/Pranava-Pai-N)                                                                                        |
| Development contacts | [Tharun Rai](https://github.com/tharunrai), [Naren](https://github.com/Naren1520), and [Pranava Pai](https://github.com/Pranava-Pai-N) |
| Institution          | Sahyadri College of Engineering & Management                                                                                           |

For project questions, use the repository discussions or contact the maintainers listed above. For contribution-specific requirements, read [`CONTRIBUTING.md`](./CONTRIBUTING.md) first.

## Design and Media

The initial product direction is documented in the [Aerophilia 2026 Figma design](https://www.figma.com/design/WQTD6X4U78mJsYpPmDIrza/Aerophilia-26?node-id=0-1&p=f&t=nkI2Jd3RLhmlctLY-0). Event media and logos are maintained under [`public/assets`](./public/assets).

## License

This project is licensed under the MIT License. See [`LICENSE`](./LICENSE) for the full terms.

Copyright &copy; 2026 Team Challengers Sahyadri.
